/*
 * PersonBean.java
 *
 * Created on ����������, 2006, ������� 20, 15:26
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.cosmos.test;

import com.cosmos.bean.table.BeanTableModel;
import com.cosmos.bean.table.ColumnType;
import com.cosmos.util.data.ComparableBean;
import com.cosmos.util.data.IndexKey;

/**
 *
 * @author miro
 */
public class PersonBean
    implements ComparableBean
{
    
    /** Creates a new instance of PersonBean */
    public PersonBean()
    {
    }

    public PersonBean(int personId, String firstName, String lastName, String globalUniqueId)
    {
        this.personId = personId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.globalUniqueId = globalUniqueId;
    }

    /**
     * Holds value of property personId.
     */
    private int personId;

    /**
     * Getter for property personId.
     * @return Value of property personId.
     */
    public int getPersonId()
    {
        return this.personId;
    }

    /**
     * Setter for property personId.
     * @param personId New value of property personId.
     */
    public void setPersonId(int personId)
    {
        this.personId = personId;
    }

    /**
     * Holds value of property firstName.
     */
    private String firstName;

    /**
     * Getter for property firstName.
     * @return Value of property firstName.
     */
    public String getFirstName()
    {
        return this.firstName;
    }

    /**
     * Setter for property firstName.
     * @param firstName New value of property firstName.
     */
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    /**
     * Holds value of property lastName.
     */
    private String lastName;

    /**
     * Utility field used by bound properties.
     */
    private java.beans.PropertyChangeSupport propertyChangeSupport =  new java.beans.PropertyChangeSupport(this);

    /**
     * Utility field used by constrained properties.
     */
    private java.beans.VetoableChangeSupport vetoableChangeSupport =  new java.beans.VetoableChangeSupport(this);

    /**
     * Adds a PropertyChangeListener to the listener list.
     * @param l The listener to add.
     */
    public void addPropertyChangeListener(java.beans.PropertyChangeListener l)
    {
        propertyChangeSupport.addPropertyChangeListener(l);
    }

    /**
     * Removes a PropertyChangeListener from the listener list.
     * @param l The listener to remove.
     */
    public void removePropertyChangeListener(java.beans.PropertyChangeListener l)
    {
        propertyChangeSupport.removePropertyChangeListener(l);
    }

    /**
     * Adds a VetoableChangeListener to the listener list.
     * @param l The listener to add.
     */
    public void addVetoableChangeListener(java.beans.VetoableChangeListener l)
    {
        vetoableChangeSupport.addVetoableChangeListener (l);
    }

    /**
     * Removes a VetoableChangeListener from the listener list.
     * @param l The listener to remove.
     */
    public void removeVetoableChangeListener(java.beans.VetoableChangeListener l)
    {
        vetoableChangeSupport.removeVetoableChangeListener (l);
    }

    /**
     * Getter for property lastName.
     * @return Value of property lastName.
     */
    public String getLastName()
    {
        return this.lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    /**
     * Holds value of property globalUniqueId.
     */
    private String globalUniqueId;

    public String getGlobalUniqueId()
    {
        return this.globalUniqueId;
    }

    public void setGlobalUniqueId(String globalUniqueId)
    {
        this.globalUniqueId = globalUniqueId;
    }

    public IndexKey getIndexKey()
    {
        return null;
    }

    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("id: ").append(personId);
        sb.append(", fn: ").append(firstName);
        sb.append(", ln: ").append(lastName);
        sb.append(", guid: ").append(globalUniqueId);
        return sb.toString();
    }

    public static BeanTableModel<PersonBean> getTableModel()
    {
        BeanTableModel<PersonBean> tableModel = new BeanTableModel<PersonBean>();
        tableModel.addColumn(
                "PersonId",
                "personId",
                "Person Id",
                ColumnType.INT,
                true,
                true
            );
        tableModel.addColumn(
                "FirstName",
                "firstName",
                "First name",
                ColumnType.STRING
            );
        tableModel.addColumn(
                "LastName",
                "lastName",
                "Last name",
                ColumnType.STRING
            );
        tableModel.addColumn(
                "GlobalUniqueId",
                "globalUniqueId",
                "Global Unique Id",
                ColumnType.STRING
            );
        return tableModel;
    }

 }
