package com.cosmos.test;

import com.cosmos.util.UIResourceManager;
import java.util.TreeMap;

/**
 *
 * @author miro
 */
public class UIRMTest
{
    
    /** Creates a new instance of UIRMTest */
    public UIRMTest()
    {
    }
    

    public static void main(String[] args)
    {
        System.out.println("UIResourceManager.getResourceString(\"myKey\"): " + UIResourceManager.getResourceString("myKey"));
    }

}
