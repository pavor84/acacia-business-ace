/*
 * AddressBean.java
 *
 * Created on ����������, 2006, ������� 20, 15:27
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.cosmos.test;

import com.cosmos.bean.table.BeanTableColumn;
import com.cosmos.bean.table.BeanTableModel;
import com.cosmos.bean.table.ColumnType;
import com.cosmos.util.data.ComparableBean;
import com.cosmos.util.data.IndexKey;

/**
 *
 * @author miro
 */
public class AddressBean
    implements ComparableBean
{
    private int addressId;
    private int ownerId;
    private String city;
    private String country;
    private String address;


    /** Creates a new instance of AddressBean */
    public AddressBean()
    {
    }

    public int getAddressId()
    {
        return addressId;
    }

    public void setAddressId(int addressId)
    {
        this.addressId = addressId;
    }

    public int getOwnerId()
    {
        return ownerId;
    }

    public void setOwnerId(int ownerId)
    {
        this.ownerId = ownerId;
    }

    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    public String getCountry()
    {
        return country;
    }

    public void setCountry(String country)
    {
        this.country = country;
    }

    public String getAddress()
    {
        return address;
    }

    public void setAddress(String address)
    {
        this.address = address;
    }

    public IndexKey getIndexKey()
    {
        return null;
    }

    public static BeanTableModel<AddressBean> getTableModel()
    {
        BeanTableModel<AddressBean> tableModel = new BeanTableModel<AddressBean>();
        tableModel.addColumn(
                "AddressId",
                "addressId",
                "Address Id",
                ColumnType.INT,
                true,
                true
            );
        tableModel.addColumn(
                "OwnerId",
                "ownerId",
                "Owner Id",
                ColumnType.INT
            );
        tableModel.addColumn(
                "City",
                "city",
                "City",
                ColumnType.STRING
            );
        tableModel.addColumn(
                "Country",
                "country",
                "Country",
                ColumnType.STRING
            );
        tableModel.addColumn(
                "Address",
                "address",
                "Address",
                ColumnType.STRING
            );
        return tableModel;
    }

}
