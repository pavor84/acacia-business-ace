package com.cosmos.test;

import java.security.cert.CertStore;

/**
 *
 * @author miro
 */
public class SecurityTest
{
    
    public SecurityTest()
    {
    }

    public static void main(String[] args)
    {
//        CertStore certStore = CertStore.getInstance(arg0, arg1);
    }
}
