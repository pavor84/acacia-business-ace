package com.cosmos.mail;

import javax.mail.internet.AddressException;
import org.apache.commons.validator.EmailValidator;
import org.apache.oro.text.perl.Perl5Util;

/**
 *
 * @author miro
 */
public class EmailAddressValidator
    extends EmailValidator
{
    protected static final String SPECIAL_CHARS = "\\000-\\037\\(\\)<>@,;:'\\\\\\\"\\.\\[\\]\\177";
    protected static final String VALID_CHARS = "[^\\s" + SPECIAL_CHARS + "]";
    protected static final String QUOTED_USER = "(\"[^\"]*\")";
    protected static final String ATOM = VALID_CHARS + '+';
    protected static final String WORD = "((" + VALID_CHARS + "|')+|" + QUOTED_USER + ")";

    // Each pattern must be surrounded by /
    protected static final String LEGAL_ASCII_PATTERN = "/^[\\000-\\177]+$/";
    protected static final String EMAIL_PATTERN = "/^(.+)@(.+)$/";
    protected static final String IP_DOMAIN_PATTERN =
            "/^\\[(\\d{1,3})[.](\\d{1,3})[.](\\d{1,3})[.](\\d{1,3})\\]$/";
    protected static final String TLD_PATTERN = "/^([a-zA-Z]+)$/";
            
    protected static final String USER_PATTERN = "/^\\s*" + WORD + "(\\." + WORD + ")*$/";
    protected static final String DOMAIN_PATTERN = "/^" + ATOM + "(\\." + ATOM + ")*\\s*$/";
    protected static final String ATOM_PATTERN = "/(" + ATOM + ")/";

    private static final EmailAddressValidator instance = new EmailAddressValidator();

    protected EmailAddressValidator()
    {
        super();
    }

    public static EmailAddressValidator getInstance()
    {
        return instance;
    }

    public void validate(String email)
        throws AddressException
    {
        StringBuilder sb = new StringBuilder();
        if(isValid(email))
            return;

        sb.append("Invalid Email address:");
        if(email == null)
        {
            sb.append(" The address can not be NULL.");
            throw new AddressException(sb.toString());
        }

        Perl5Util matchAsciiPat = new Perl5Util();
        if(!matchAsciiPat.match(LEGAL_ASCII_PATTERN, email))
        {
            sb.append(" Illegal ASCII character(s).");
        }

        email = stripComments(email);

        // Check the whole email address structure
        Perl5Util emailMatcher = new Perl5Util();
        if(!emailMatcher.match(EMAIL_PATTERN, email))
        {
            sb.append(" Wrong email structure.");
        }

        if(email.endsWith("."))
        {
            sb.append(" The email address can not ends with dot.");
        }

        try
        {
            String str = emailMatcher.group(1);
            if(str == null || !isValidUser(str))
            {
                sb.append(" Invalid user part.");
            }

            str = emailMatcher.group(2);
            if(str == null || !isValidDomain(str))
            {
                sb.append(" Invalid domain part.");
            }
        }
        catch(Exception ex)
        {
            sb.append(" Invalid user or/and domain part(s).");
        }

        throw new AddressException(sb.toString());
    }

}
