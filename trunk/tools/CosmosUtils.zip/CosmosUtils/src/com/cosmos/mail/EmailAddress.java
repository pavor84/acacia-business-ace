package com.cosmos.mail;

import java.io.UnsupportedEncodingException;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

/**
 *
 * @author miro
 */
public class EmailAddress
    extends InternetAddress
{
    private String organization;
    private String replyToAddress;
    
    public EmailAddress()
    {
        super();
    }

    public EmailAddress(String address)
        throws AddressException
    {
        super(address);
    }

    public EmailAddress(String address, boolean strict)
        throws AddressException
    {
        super(address, strict);
    }

    public EmailAddress(String address, String personal)
        throws AddressException,
        UnsupportedEncodingException
    {
        super(address, personal);
    }

    public EmailAddress(String address, String personal, String charset)
        throws AddressException,
        UnsupportedEncodingException
    {
        super(address, personal, charset);
    }

    public String getOrganization()
    {
        return organization;
    }

    public void setOrganization(String organization)
    {
        this.organization = organization;
    }

    public String getReplyToAddress()
    {
        return replyToAddress;
    }

    public void setReplyToAddress(String replyToAddress)
    {
        this.replyToAddress = replyToAddress;
    }

    @Override
    public String toString()
    {
        String emailAddress = super.toString();
        String organization = getOrganization();
        if(organization != null && (organization = organization.trim()).length() > 0)
        {
            StringBuilder sb = new StringBuilder(emailAddress.length() + organization.length() + 3);
            sb.append(emailAddress).append(" (").append(organization).append(")");
            return sb.toString();
        }
        else
            return emailAddress;
    }

}
