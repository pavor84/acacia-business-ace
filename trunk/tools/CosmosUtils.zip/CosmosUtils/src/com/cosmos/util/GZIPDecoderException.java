package com.cosmos.util;

import com.cosmos.util.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class GZIPDecoderException
	extends Exception
{
	public GZIPDecoderException(Throwable cause)
	{
		super("GZIPDecoder exception", cause);
	}
}
