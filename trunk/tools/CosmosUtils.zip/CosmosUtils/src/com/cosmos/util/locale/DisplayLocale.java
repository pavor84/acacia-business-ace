package com.cosmos.util.locale;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 *
 * @author miro
 */
public abstract class DisplayLocale
{
    private String displayValue;
    protected Locale locale;

    public DisplayLocale(Locale locale)
    {
        this.locale = locale;
    }

    public String toString()
    {
        if(displayValue == null)
        {
            StringBuilder sb = new StringBuilder();

            String id = getId();
            if(id != null && (id = id.trim()).length() > 0)
            {
                sb.append(id);
            }

            String value = getValue();
            if(value != null && (value = value.trim()).length() > 0)
            {
                sb.append("-").append(value);
            }


            displayValue = sb.toString();
        }
        return displayValue;
    }

    public Locale getLocale()
    {
        return locale;
    }

    public abstract String getId();
    public abstract String getValue();
}
