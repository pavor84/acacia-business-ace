/*
 * IndexKey.java
 *
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.cosmos.util.data;

/**
 *
 * @author miro
 */
public interface IndexKey<T>
    extends Comparable<T>
{
    
}
