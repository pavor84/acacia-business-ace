package com.cosmos.util;

import com.cosmos.util.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class Base64EncoderException
	extends Exception
{
	public Base64EncoderException(Throwable cause)
	{
		super("Base64Encoder exception", cause);
	}

}
