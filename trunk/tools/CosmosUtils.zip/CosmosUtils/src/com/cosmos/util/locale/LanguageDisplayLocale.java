package com.cosmos.util.locale;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 *
 * @author miro
 */
public class LanguageDisplayLocale
    extends DisplayLocale
{
    public LanguageDisplayLocale(Locale locale)
    {
        super(locale);
    }

    public String getId()
    {
        return locale.getLanguage();
    }

    public String getValue()
    {
        return locale.getDisplayLanguage();
    }

    public static List<DisplayLocale> toDisplayLocale(Locale ... locales)
    {
        if(locales != null && locales.length > 0)
            return toDisplayLocale(Arrays.<Locale>asList(locales));
        else
            return Collections.<DisplayLocale>emptyList();
    }

    public static List<DisplayLocale> toDisplayLocale(Collection<Locale> locales)
    {
        if(locales != null && locales.size() > 0)
            return toDisplayLocale(new ArrayList<Locale>(locales));
        else
            return Collections.<DisplayLocale>emptyList();
    }

    public static List<DisplayLocale> toDisplayLocale(List<Locale> locales)
    {
        int size;
        if(locales != null && (size = locales.size()) > 0)
        {
            ArrayList<DisplayLocale> list = new ArrayList<DisplayLocale>(size);
            for(Locale locale : locales)
            {
                list.add(new LanguageDisplayLocale(locale));
            }
            return list;
        }
        else
            return Collections.<DisplayLocale>emptyList();
    }
}
