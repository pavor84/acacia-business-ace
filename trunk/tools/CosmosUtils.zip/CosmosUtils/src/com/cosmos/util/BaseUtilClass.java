package com.cosmos.util;

import com.cosmos.util.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class BaseUtilClass
{
	private LoggerHelper loggerHelper;

	public BaseUtilClass()
	{
	}

	public LoggerHelper getLoggerHelper()
	{
		return getLoggerHelper(this.getClass().getName());
	}

	public LoggerHelper getLoggerHelper(String applicationName)
	{
		if(loggerHelper == null)
		{
			loggerHelper = LoggerHelper.getLoggerHelper(applicationName);
		}
		return loggerHelper;
	}

	public void setLoggerHelper(LoggerHelper loggerHelper)
	{
		this.loggerHelper = loggerHelper;
	}
}
