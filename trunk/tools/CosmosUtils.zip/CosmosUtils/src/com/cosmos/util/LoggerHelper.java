package com.cosmos.util;

import com.cosmos.util.*;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.logging.FileHandler;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.logging.SimpleFormatter;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class LoggerHelper
{
	private String applicationName;
	private Logger errorLogger;
	private Logger infoLogger;
	private Logger debugLogger;

	private static Hashtable<String,LoggerHelper> loggerHelpers = new Hashtable<String,LoggerHelper>();

	private LoggerHelper(String applicationName)
	{
		this.applicationName = applicationName;
		errorLogger = Logger.getLogger(applicationName.concat(".error"));
		infoLogger = Logger.getLogger(applicationName.concat(".info"));
		debugLogger = Logger.getLogger(applicationName.concat(".debug"));
	}

	public static synchronized LoggerHelper getLoggerHelper(String applicationName)
	{
		LoggerHelper loggerHelper = loggerHelpers.get(applicationName);
		if(loggerHelper == null)
		{
			loggerHelper = new LoggerHelper(applicationName);
			loggerHelper.init();
			loggerHelpers.put(applicationName, loggerHelper);
		}

		return loggerHelper;
	}

	public void init()
	{
		infoLogger.setParent(errorLogger);
		debugLogger.setParent(infoLogger);

		errorLogger.setLevel(Level.SEVERE);
		infoLogger.setLevel(Level.CONFIG);
		debugLogger.setLevel(Level.FINEST);

		errorLogger.addHandler(getLogFileHandler("error", false));
		infoLogger.addHandler(getLogFileHandler("info", false));
		debugLogger.addHandler(getLogFileHandler("debug", true));
	}

	FileHandler getLogFileHandler(String extensionName, boolean isForDebug)
	{
		String path;
		if(isForDebug)
			path = SystemUtils.getIOTempDir();
		else
			path = SystemUtils.getUserHome();

		StringBuilder sb = new StringBuilder();
		sb.append(path);
		if(!path.endsWith(File.separator))
			sb.append(File.separator);
		sb.append(".").append(getApplicationName());
		File dir = new File(sb.toString());
		if(!dir.exists())
			dir.mkdirs();

		FileHandler fileHandler = null;
		sb.append(File.separator).append(getApplicationName()).append("-").append(extensionName);
		try
		{
			if(isForDebug)
			{
				sb.append(".log");
				fileHandler = new FileHandler(sb.toString());
			}
			else
			{
				sb.append("-%g.log");
				fileHandler = new FileHandler(sb.toString(), 0x100000, 3, true);
			}
			fileHandler.setEncoding("UTF-8");
		}
		catch(IOException ex)
		{
			Logger logger = Logger.getLogger(this.getClass().getName());
			FileHandler fh = null;
			try
			{
				fh = new FileHandler("LoggerHelper-Error-%g.log", 0x100000, 3, true);
				fh.setEncoding("UTF-8");
			}
			catch(IOException ex1)
			{
				ex1.printStackTrace();
			}
			if(fh != null)
				logger.addHandler(fh);

			ex.printStackTrace();
			logger.logp(Level.SEVERE, this.getClass().getName(), "getLogFileHandler()", "Log File Name: " + sb.toString(), ex);
		}

		fileHandler.setFormatter(new SimpleFormatter());

		return fileHandler;
	}

	public String getApplicationName()
	{
		return applicationName;
	}

	public Logger getErrorLogger()
	{
		return errorLogger;
	}

	public Logger getInfoLogger()
	{
		return infoLogger;
	}

	public Logger getDebugLogger()
	{
		return debugLogger;
	}


	public static void main(String[] args)
	{
		try
		{
			LoggerHelper loggerHelper = LoggerHelper.getLoggerHelper("MyTestApp");

			Logger errorLogger = loggerHelper.getErrorLogger();
			Logger infoLogger = loggerHelper.getInfoLogger(); ;
			Logger debugLogger = loggerHelper.getDebugLogger();

			errorLogger.severe("This is error logger with SEVERE out. Мирослав Начев.");
			infoLogger.severe("This is info logger with SEVERE out. Мирослав Начев.");
			debugLogger.severe("This is debug logger with SEVERE out. Мирослав Начев.");

			errorLogger.info("This is error logger with INFO out. Мирослав Начев.");
			infoLogger.info("This is info logger with INFO out. Мирослав Начев.");
			debugLogger.info("This is debug logger with INFO out. Мирослав Начев.");

			errorLogger.fine("This is error logger with FINE out. Мирослав Начев.");
			infoLogger.fine("This is info logger with FINE out. Мирослав Начев.");
			debugLogger.fine("This is debug logger with FINE out. Мирослав Начев.");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
