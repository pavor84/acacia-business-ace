package com.cosmos.util;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.nio.channels.FileChannel;
import java.text.DateFormat;
import java.io.LineNumberReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.Writer;
import java.net.JarURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.security.AccessController;
import java.text.DecimalFormat;
import java.text.Normalizer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;


/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class SystemUtils
{
    private static final String KEY_PREFIX = "com.cosmos";
    public static final String KEY_APPLICATION_NAME = KEY_PREFIX + ".apps.name";
    public static final String KEY_CLIENT_CONFIG_FOLDER = KEY_PREFIX + ".apps.client.config.folder";
    public static final String KEY_KEYSTORE_FOLDER = KEY_PREFIX + ".key.store.folder";
    private static final char[] HEX_DIGITS = "0123456789ABCDEF".toCharArray();
    private static final char[] EMPTY_CHAR_ARRAY = new char[0];

    private static DateFormat dateFormat;
    private static DateFormat alternativeDateFormat;
    private static DecimalFormat decimalFormat;
    public static String charsetName = "UTF-8";
    private static OperatingSystem operatingSystem;



    public static final Process executeProcess(URI targetURI)
        throws IOException
    {
        String osName = getOSName();
        System.out.println("OS: " + osName);
        if(osName != null && osName.startsWith("Windows"))
        {
            String uriScheme = targetURI.getScheme();
            if("file".equalsIgnoreCase(uriScheme))
            {
                File srcFile = new File(targetURI);
                File folder = srcFile.getParentFile();
                String fileName = srcFile.toURI().toASCIIString();
                int index = fileName.lastIndexOf("/");
                if(index >= 0)
                    fileName = fileName.substring(index + 1);
                File dstFile = new File(folder, fileName);

                if(!srcFile.equals(dstFile))
                {
                    System.out.println("Source file name: " + srcFile.getName());
                    copyFile(srcFile, dstFile);
                    dstFile.deleteOnExit();
                }
                else
                    System.out.println("The file/process/command doesn't need to be escaped.");

                System.out.println("Directory = \"" + folder + "\"");
                System.out.println("File Name = \"" + fileName + "\"");

                ProcessBuilder pb = new ProcessBuilder("cmd", "/c", "start", fileName);
                pb.directory(folder);
                return pb.start();
            }
            else
            {
                ProcessBuilder pb = new ProcessBuilder("cmd", "/c", "start", targetURI.toString());
                return pb.start();
            }
        }

        return null;
    }

    // Alternative_Date_Formatter
    public static DateFormat getAlternativeDateFormatter()
    {
        if(alternativeDateFormat == null)
        {
            String dateFormatString = UIResourceManager.getResourceString("Alternative_Date_Formatter",
                "yyyy.MM.dd HH:mm:ss z");
            //String dateFormatString = ResourceBundleManager.getString("Alternative_Date_Formatter",
            //    "yyyy.MM.dd HH:mm:ss z");
            alternativeDateFormat = new SimpleDateFormat(dateFormatString);
        }
        return alternativeDateFormat;
    }

    private static DateFormat getDateFormatter()
    {
        if(dateFormat == null)
        {
            //String dateFormatString = ResourceBundleManager.getString("Default_Date_Formatter",
            //    "yyyy-MM-dd'T'HH:mm:ssZ");
            //dateFormat = new SimpleDateFormat(dateFormatString);
            dateFormat = new ISO8601DateFormat();
        }
        return dateFormat;
    }

    public static String formatDate(Object date)
    {
        return getDateFormatter().format(date);
    }

    public static String formatDate(Date date)
    {
        return getDateFormatter().format(date);
    }

    public static Date parseDate(String dateString)
        throws ParseException
    {
        DateFormat dateFormat = getDateFormatter();
        try
        {
            return dateFormat.parse(dateString);
        }
        catch(ParseException ex)
        {
            dateFormat = getAlternativeDateFormatter();
            return dateFormat.parse(dateString);
        }
    }

    public static DecimalFormat getDecimalFormatter()
    {
        if(decimalFormat == null)
        {
            decimalFormat = new DecimalFormat("#,##0.##");
        }
        return decimalFormat;
    }

    public static String getCauseMessages(Throwable ex)
    {
        if(ex == null)
            return null;

        StringBuilder sb = new StringBuilder();
        sb.append(getErrorMessage(ex)).append("; \n");

        Throwable cause = ex.getCause();
        while(cause != null)
        {
            String message = getErrorMessage(cause);
            if(message != null)
            {
                sb.append(message).append("; \n");
            }
            cause = cause.getCause();
        }

        return sb.toString();
    }

    public static String getStringAsHTML(String source)
    {
        StringBuilder sb = new StringBuilder();
        sb.append("<html>");

        if(source != null)
        {
            BufferedReader reader = new BufferedReader(new StringReader(source));
            String line;
            try
            {
                while((line = reader.readLine()) != null)
                {
                    sb.append(line).append("<br />");
                }
            }
            catch(IOException ex) {}
        }

        sb.append("</html>");
        return sb.toString();
    }

    public static String getErrorMessage(Throwable ex)
    {
        if(ex != null)
        {
            String message = ex.getMessage();
            if(message == null)
                message = ex.getClass().getName();
            return message;
        }
        else
            return null;
    }

    public static boolean deleteFiles(File fileOrDir)
    {
        return deleteFiles(fileOrDir, false);
    }

    public static boolean deleteFiles(File fileOrDir, boolean deleteRoot)
    {
        if(fileOrDir.isDirectory())
        {
            File[] children = fileOrDir.listFiles();
            for(File child : children)
            {
                if(!deleteFiles(child, true))
                    return false;
            }

            if(deleteRoot)
                return fileOrDir.delete();
            else
                return true;
        }
        else
        {
            return fileOrDir.delete();
        }
    }

    public static boolean deleteFile(File fileOrDir)
    {
        return deleteFiles(fileOrDir, true);
    }

    public static String getFileExtension(String fileName)
    {
        if(fileName != null)
        {
            int dotIndex;
            if((dotIndex = fileName.lastIndexOf(".")) >= 0)
            {
                return fileName.substring(dotIndex).trim().toLowerCase();
            }
        }

        return null;
    }

    public static String replaceFileExtension(String filePath, String newExt)
    {
        int dotIndex = filePath.lastIndexOf('.');
        if(dotIndex >= 0)
        {
                filePath = filePath.substring(0, dotIndex) + newExt;
        }
        else
        {
                filePath = filePath + newExt;
        }
        return filePath;
    }

    public static byte[] toByteArray(InputStream inStream)
        throws IOException
    {
        if(inStream == null)
            return null;

        ByteArrayOutputStream os = new ByteArrayOutputStream();
        copy(inStream, os);

        return os.toByteArray();
    }

    public static void copy(URI srcURI, URI dstURI)
        throws IOException
    {
        copy(srcURI.toURL(), dstURI.toURL());
    }

    public static void copy(URL srcURL, URL dstURL)
        throws IOException
    {
        copy(srcURL.openConnection().getInputStream(),
             dstURL.openConnection().getOutputStream());
    }

    public static void copy(InputStream inStream, OutputStream outStream)
        throws IOException
    {
        if(inStream == null)
            throw new IllegalArgumentException("InputStream can not be NULL in copy method.");
        if(outStream == null)
            throw new IllegalArgumentException("OutputStream can not be NULL in copy method.");

        byte[] buffer = new byte[1024];
        int read = 0;

        try
        {
            while((read = inStream.read(buffer)) >= 0)
            {
                outStream.write(buffer, 0, read);
            }
            outStream.flush();
        }
        finally
        {
            buffer = null;
            inStream.close();
            inStream = null;
            outStream.close();
        }
    }

    public static void copyFile(File sourceFile, File destinationFile)
        throws IOException
    {
        if(sourceFile.isDirectory())
        {
            if(!destinationFile.exists())
                destinationFile.mkdirs();

            for(File srcFile : sourceFile.listFiles())
            {
                copyFile(srcFile, new File(destinationFile, srcFile.getName()));
            }
        }
        else
        {
            FileChannel sourceChannel = null;
            FileInputStream inStream = null;
            FileChannel destinationChannel = null;
            FileOutputStream outStream = null;

            try
            {
                inStream = new FileInputStream(sourceFile);
                sourceChannel = inStream.getChannel();
                outStream = new FileOutputStream(destinationFile);
                destinationChannel = outStream.getChannel();
                // sourceChannel.transferTo(0, sourceChannel.size(), destinationChannel);
                destinationChannel.transferFrom(sourceChannel, 0, sourceChannel.size());
            }
            finally
            {
                if(sourceChannel != null)
                {
                    try
                    {
                        sourceChannel.close();
                        sourceChannel = null;
                    }
                    catch(Exception ex) {}
                }
                if(inStream != null)
                {
                    try
                    {
                        inStream.close();
                        inStream = null;
                    }
                    catch(Exception ex) {}
                }
                if(destinationChannel != null)
                {
                    try
                    {
                        destinationChannel.close();
                        destinationChannel = null;
                    }
                    catch(Exception ex) {}
                }
                if(outStream != null)
                {
                    try
                    {
                        outStream.close();
                        outStream = null;
                    }
                    catch(Exception ex) {}
                }
            }
        }
    }

    public static String readTextFile(String fileName)
        throws IOException
    {
        return readTextFile(new File(fileName));
    }

    public static String readTextFile(File file)
        throws IOException
    {
        return readTextFile(new FileInputStream(file));
    }

    public static String readTextFile(InputStream inStream)
        throws IOException
    {
        InputStreamReader reader = new InputStreamReader(inStream, charsetName);
        LineNumberReader textReader = new LineNumberReader(reader);
        String line;
        StringBuilder sb = new StringBuilder();
        while((line = textReader.readLine()) != null)
        {
            if(sb.length() > 0)
                sb.append("\n");
            sb.append(line);
        }

        return sb.toString();
    }

    public static Properties getProperties(String filePathName)
        throws IOException
    {
        return getProperties(getResourceAsStream(filePathName));
    }

    public static Properties getProperties(InputStream inStream)
        throws IOException
    {
        return getProperties(new InputStreamReader(inStream, charsetName));
    }

    public static Properties getProperties(Reader reader)
        throws IOException
    {
        Properties properties = new Properties();
        properties.load(reader);
        reader.close();
        reader = null;
        return properties;
    }

    public static InputStream getPropertiesAsStream(String filePathName)
        throws IOException
    {
        Properties properties = getProperties(filePathName);
        StringBuilder sb = new StringBuilder();
        for(Enumeration e = properties.keys(); e.hasMoreElements();)
        {
            String key = (String)e.nextElement();
            String val = (String)properties.get(key);
            sb.append(key).append('=').append(val).append('\n');
        }
        return new ByteArrayInputStream(sb.toString().getBytes());
    }

    public static void storeProperties(Properties properties,
                                       String filePathName)
        throws IOException
    {
        String comments = null;
        try
        {
            comments = getComments(filePathName);
        }
        catch(Exception ex) {}
        storeProperties(properties, filePathName, comments);
    }

    public static void storeProperties(Properties properties,
                                       String filePathName,
                                       String comments)
        throws IOException
    {
        if(comments == null || (comments = comments.trim()).length() <= 0)
        {
            StringBuilder sb = new StringBuilder();
            sb.append("File path name: ").append(filePathName);
            sb.append("\n\t ").append("Created on ").append(getDateFormatter().format(new Date()));
            sb.append("\n");
            comments = sb.toString();
        }

        Writer writer = null;
        try
        {
            writer = getWriter(filePathName);
            properties.store(writer, comments);
        }
        finally
        {
            if(writer != null)
            {
                try
                {
                    writer.close();
                }
                catch(Exception ex) {}
                writer = null;
            }
        }
    }

    public static Writer getWriter(String filePathName)
        throws IOException
    {
        return getWriter(new FileOutputStream(filePathName));
    }

    public static Writer getWriter(OutputStream outStream)
        throws IOException
    {
        return new OutputStreamWriter(outStream, charsetName);
    }

    public static InputStream getResourceAsStream(String resourceName)
        throws IOException
    {
        return getResourceAsStream(SystemUtils.class, resourceName);
    }

    public static InputStream getResourceAsStream(Object invoker, String resourceName)
        throws IOException
    {
        Class baseClass;
        if(invoker != null)
            baseClass = invoker.getClass();
        else
            baseClass = SystemUtils.class;
        return getResourceAsStream(baseClass, resourceName);
    }

    public static InputStream getResourceAsStream(Class baseClass, String resourceName)
        throws IOException
    {
        InputStream is = baseClass.getResourceAsStream(resourceName);
        if(is == null)
        {
            is = baseClass.getClassLoader().getResourceAsStream(resourceName);
        }
        if(is == null)
        {
            is = new FileInputStream(resourceName);
        }
        if(is == null)
        {
            is = ClassLoader.getSystemResourceAsStream(resourceName);
        }
        if(is != null)
        {
            return is;
        }
        throw new IOException("Can't load resource '" + resourceName + "'.");
    }

    public static String trimFileName(String filePathName)
    {
        if(filePathName == null)
            return filePathName;

        StringBuilder sb = new StringBuilder(filePathName);
        int size = sb.length();
        char ch;
        while(size > 0 && ((ch = sb.charAt(size - 1)) == '.' || ch == File.separatorChar))
        {
            size--;
            sb.setLength(size);
        }
        return sb.toString();
    }

    public static String getOSName()
    {
        return System.getProperty("os.name");
    }

    public static OperatingSystem getOperatingSystem()
    {
        if(operatingSystem == null)
        {
            String osName = getOSName().toLowerCase();
            if(osName.indexOf("windows") >= 0)
                operatingSystem = OperatingSystem.WINDOWS;
            else if(osName.indexOf("linux") >= 0)
                operatingSystem = OperatingSystem.LINUX;
            else if(osName.indexOf("solaris") >= 0)
                operatingSystem = OperatingSystem.SOLARIS;
            else
                operatingSystem = OperatingSystem.UNKNOWN_OS;
        }
        return operatingSystem;
    }

    public static String getIOTempDir()
    {
        return System.getProperty("java.io.tmpdir");
    }

    public static String getUserHome()
    {
	return System.getProperty("user.home");
    }

    public static String getFileName(File folder, String fileName)
    {
        return getFileName(folder.getAbsolutePath(), fileName);
    }

    public static String getFileName(String folderName, String fileName)
    {
        if(folderName == null)
            return fileName;
        if(fileName == null)
            return null;

        StringBuilder sb = new StringBuilder(folderName.length() + fileName.length() + 1);
        sb.append(folderName);
        if(!folderName.endsWith(File.separator))
            sb.append(File.separator);
        sb.append(fileName);

        return sb.toString();
    }

    public static String getComments(String filePathName)
        throws IOException
    {
        return getComments(getResourceAsStream(filePathName));
    }

    public static String getComments(InputStream inStream)
        throws IOException
    {
        try
        {
            String comments = getComments(new InputStreamReader(inStream, charsetName));
            return comments;
        }
        finally
        {
            if(inStream != null)
            {
                try
                {
                    inStream.close();
                }
                catch(Exception ex) {}
                inStream = null;
            }
        }
    }

    public static String getComments(Reader reader)
    {
        StringBuilder sb = new StringBuilder();
        BufferedReader lineReader = new BufferedReader(reader);

        try
        {
            String line;
            String lastLine = null;
            while((line = lineReader.readLine()) != null)
            {
                if(line.startsWith("#"))
                {
                    if(lastLine != null)
                        sb.append("\n");
                    sb.append(line);
                    lastLine = line;
                }
                else
                    break;
            }
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
        finally
        {
            if(reader != null)
            {
                try
                {
                    reader.close();
                }
                catch(Exception ex) {}
                reader = null;
            }
        }

        if(sb.length() > 0)
            return sb.toString();
        else
            return null;
    }

    public static String toHexString(byte[] data)
    {
        return new String(toHexChars(data));
    }

    public static char[] toHexChars(byte[] data)
    {
        if(data == null || data.length <= 0)
            return EMPTY_CHAR_ARRAY;

        int size = data.length;
        char[] result = new char[size << 1];

        for (int i = 0, j = 0; i < size; i++)
        {
            int ch = data[i];
            result[j++] = HEX_DIGITS[(ch & 0xF0) >>> 4];
            result[j++] = HEX_DIGITS[ch & 0x0F];
        }

        return result;
    }

    public static void downloadURI(URI uri, OutputStream outStream)
        throws IOException
    {
        InputStream in = null;
        try
        {
            URL url = uri.toURL();
            URLConnection connection = url.openConnection();
            in = connection.getInputStream();
            byte[] buffer = new byte[1024];
            int read;
            while((read = in.read(buffer)) >= 0)
            {
                outStream.write(buffer, 0, read);
            }
            outStream.flush();
        }
	finally
        {
            if(in != null)
            {
                try
                {
                    in.close();
                }
                catch(IOException ex) {}
            }
            if(outStream != null)
            {
                try
                {
                    outStream.close();
                }
                catch(IOException ex) {}
            }
        }
    }

    public static File getFileFromURIString(String uriString)
    {
        File file = null;
        if(uriString != null && (uriString = uriString.trim()).length() > 0)
        {
            try
            {
                URI uri = new URI(uriString);
                file = new File(uri);
                if(!file.exists())
                    file = null;
            }
            catch(Exception ex)
            {
                file = new File(uriString);
                if(!file.exists())
                    file = null;
            }
        }

        return file;
    }

    public static File openFileChooser(Component parent,
                                       FileExtension fileExt,
                                       File currentFolder,
                                       String title)
    {
        FileFilter defaultFileFilter = FileFilters.getSwingFileFilter(fileExt);
        ArrayList<FileFilter> choosableFileFilters = null;
        List<FileExtension> fileExts = fileExt.getExtensions();
        int size;
        if(fileExts != null && (size = fileExts.size()) > 0)
        {
            choosableFileFilters = new ArrayList<FileFilter>(size);
            for(FileExtension ext : fileExts)
            {
                choosableFileFilters.add(FileFilters.getSwingFileFilter(ext));
            }
        }

        return openFileChooser(parent,
                               defaultFileFilter,
                               choosableFileFilters,
                               currentFolder,
                               title);
    }

    public static File openFileChooser(Component parent,
                                       FileFilter defaultFileFilter)
    {
        return openFileChooser(parent, defaultFileFilter, null);
    }

    public static File openFileChooser(Component parent,
                                       FileFilter defaultFileFilter,
                                       File currentFolder)
    {
        return openFileChooser(parent, defaultFileFilter, null, currentFolder);
    }

    public static File openFileChooser(Component parent,
                                       FileFilter defaultFileFilter,
                                       List<FileFilter> choosableFileFilters,
                                       File currentFolder)
    {
        return openFileChooser(parent, defaultFileFilter, choosableFileFilters, currentFolder, "Open");
    }

    public static File openFileChooser(Component parent,
                                       FileFilter defaultFileFilter,
                                       List<FileFilter> choosableFileFilters,
                                       File currentFolder,
                                       String title)
    {
        JFileChooser fileChooser = new JFileChooser();
        if(title != null)
            fileChooser.setDialogTitle(title);
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fileChooser.setMultiSelectionEnabled(false);
        if(currentFolder != null)
        {
            if(currentFolder.isDirectory())
                fileChooser.setCurrentDirectory(currentFolder);
            else
            {
                fileChooser.setCurrentDirectory(currentFolder.getParentFile());
                fileChooser.setSelectedFile(currentFolder);
            }
        }

        fileChooser.setAcceptAllFileFilterUsed(false);
        fileChooser.addChoosableFileFilter(defaultFileFilter);
        if(choosableFileFilters != null && choosableFileFilters.size() > 0)
        {
            for(FileFilter ff : choosableFileFilters)
            {
                fileChooser.addChoosableFileFilter(ff);
            }
        }
        fileChooser.setFileFilter(defaultFileFilter);

        int response = fileChooser.showOpenDialog(parent);
        if(response == JFileChooser.APPROVE_OPTION)
        {
            return fileChooser.getSelectedFile();
        }

        return null;
    }

    public static File folderChooser(Component parent,
                                     String title,
                                     String currentFolderName)
    {
        return folderChooser(parent, title, new File(currentFolderName));
    }

    public static File folderChooser(Component parent,
                                     String title,
                                     File currentFolder)
    {
        JFileChooser fileChooser = new JFileChooser();
        if(title != null)
            fileChooser.setDialogTitle(title);
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        fileChooser.setMultiSelectionEnabled(false);
        if(currentFolder != null)
        {
            if(currentFolder.isDirectory())
                fileChooser.setCurrentDirectory(currentFolder);
            else
                fileChooser.setCurrentDirectory(currentFolder.getParentFile());
        }

        int response = fileChooser.showOpenDialog(parent);
        if(response == JFileChooser.APPROVE_OPTION)
        {
            return fileChooser.getSelectedFile();
        }

        return null;
    }

    public static File saveFileChooser(Component parent, String title, File currentFolder)
    {
        JFileChooser fileChooser = new JFileChooser();
        if(title != null)
            fileChooser.setDialogTitle(title);
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fileChooser.setMultiSelectionEnabled(false);

        if(currentFolder != null)
        {
            if(currentFolder.isDirectory())
                fileChooser.setCurrentDirectory(currentFolder);
            else
            {
                fileChooser.setCurrentDirectory(currentFolder.getParentFile());
                fileChooser.setSelectedFile(currentFolder);

                String ext = SystemUtils.getFileExtension(currentFolder.getName());
                while(ext != null && ext.length() > 0 && ext.startsWith("."))
                {
                    ext = ext.substring(1);
                }
                if(ext != null && (ext = ext.trim()).length() > 0)
                {
                    FileFilter ff = new SaveFileFilter(ext);
                    fileChooser.addChoosableFileFilter(ff);
                    fileChooser.setFileFilter(ff);
                }
            }
        }

        int response = fileChooser.showSaveDialog(parent);
        if(response == JFileChooser.APPROVE_OPTION)
        {
            File file = fileChooser.getSelectedFile();
            if(file != null)
            {
                FileFilter ff = fileChooser.getFileFilter();
                if(ff != fileChooser.getAcceptAllFileFilter())
                {
                    String fileExt = SystemUtils.getFileExtension(file.getName());
                    if(fileExt != null && !fileExt.startsWith("."))
                        fileExt = "." + fileExt;
                    String ext = ((SaveFileFilter)ff).getFileExtension();
                    if(ext != null && !ext.startsWith("."))
                        ext = "." + ext;
                    if(!ext.equalsIgnoreCase(fileExt))
                    {
                        StringBuilder sb = new StringBuilder(file.getAbsolutePath());
                        int size = sb.length();
                        while(size > 0 && sb.charAt(size - 1) == '.')
                            size--;
                        if(size < sb.length())
                            sb.setLength(size);
                        String fileName = sb.toString() + ext;
                        file = new File(fileName);
                    }
                }
            }
            return file;
        }

        return null;
    }

    private static class SaveFileFilter
        extends FileFilter
    {
        private String fileDescription;
        private String fileExt;

        public SaveFileFilter(String fileExt)
        {
            int dotIndex = 0;
            while(fileExt.charAt(dotIndex) == '.')
                dotIndex++;
            if(dotIndex > 0)
                fileExt = fileExt.substring(dotIndex);

            this.fileExt = fileExt;
            fileDescription = fileExt.toUpperCase() + " files";
        }

        public boolean accept(File file)
        {
            if(file != null)
            {
                if(file.isDirectory())
                    return true;

                String fileName = file.getName();
                String ext = SystemUtils.getFileExtension(fileName);
                if(ext != null)
                {
                    int dotIndex = 0;
                    while(ext.charAt(dotIndex) == '.')
                        dotIndex++;
                    if(dotIndex > 0)
                        ext = ext.substring(dotIndex);
                    return fileExt.equalsIgnoreCase(ext);
                }

                return false;
            }

            return false;
        }

        public String getDescription()
        {
            return fileDescription;
        }

        public String getFileExtension()
        {
            return fileExt;
        }
    }

    // Can be JarFile or Folder with files and subfolders.
    public static Object getResourceObject(Class clazz, String resourceFolderName)
        throws IOException
    {
        String classFileName = clazz.getName().replace('.', '/') + ".class";
        ClassLoader classLoader = clazz.getClassLoader();
        URL url = classLoader.getSystemResource(classFileName);
        if(url == null)
        {
            url = classLoader.getResource(classFileName);
        }
        if(url == null)
            return null;

        String protocol = url.getProtocol();

        if("file".equals(protocol))
        {
            String path = url.getPath();
            int pos = path.length() - classFileName.length();
            String basePath = path.substring(0, pos);
            File baseFolder = new File(basePath);
            return new File(baseFolder, resourceFolderName);
        }
        else if("jar".equals(protocol))
        {
            JarURLConnection conn = (JarURLConnection)url.openConnection();
            return conn.getJarFile();
        }

        return null;
    }

    public static void extractJarFiles(JarFile jarFile, File targetFolder, String resourceFolderName)
        throws IOException
    {
        byte[] buffer = new byte[4096];
        InputStream in = null;
        OutputStream out = null;

        try
        {
            Enumeration<JarEntry> entries = jarFile.entries();
            while(entries.hasMoreElements())
            {
                ZipEntry entry = (ZipEntry)entries.nextElement();

                if(entry.isDirectory())
                    continue;

                String pathname = entry.getName();
                if(resourceFolderName != null && !pathname.startsWith(resourceFolderName))
                    continue;

                in = jarFile.getInputStream(entry);

                File outFile = new File(targetFolder, pathname);
                File parent = outFile.getParentFile();
                if(parent != null && !parent.exists())
                    parent.mkdirs();

                out = new BufferedOutputStream(new FileOutputStream(outFile));

                int read;
                while((read = in.read(buffer)) >= 0)
                    out.write(buffer, 0, read);

                out.close();
            }
        }
        finally
        {
            try
            {
                if(jarFile != null)
                    jarFile.close();
            }
            catch(IOException ex) {}
            if(out != null)
            {
                try
                {
                    out.close();
                }
                catch(IOException ex) {}
            }
            if(in != null)
            {
                try
                {
                    in.close();
                }
                catch(IOException ex) {}
            }
        }
    }

    public static Font getFont(String str)
    {
        return getFont(str, new Font(Font.DIALOG, Font.PLAIN, 12));
    }

    public static Font getFont(String str, Font defaultFont)
    {
        String fontName = str;
        int fontSize = 12;
        int fontStyle = Font.PLAIN;

        if(str == null)
        {
            return defaultFont;
        }

        StringTokenizer strToken = new StringTokenizer(str, ",;");
        int pos = 0;
        while(strToken.hasMoreTokens() && pos <= 2)
        {
            String strValue = strToken.nextToken().trim();
            switch(pos)
            {
                case 0:
                    fontName = strValue;
                    break;

                case 1:
                    try
                    {
                        fontSize = Integer.parseInt(strValue);
                    }
                    catch(Exception ex) {}
                    break;

                case 2:
                    try
                    {
                        Integer value = (Integer)BeanUtil.getStaticFieldValue(Font.class, strValue);
                        if(value != null)
                            fontStyle = value.intValue();
                    }
                    catch(Exception ex) {}
                    break;
            }

            pos++;
        }

        Font font = new Font(fontName, fontStyle, fontSize);
        if(font != null)
            return font;
        else
            return defaultFont;
    }

    public static Color getColor(String str)
    {
        return getColor(str, null);
    }

    public static Color getColor(String str, Color defaultColor)
    {
        if(str != null && (str = str.trim()).length() > 0)
        {
            try
            {
                return Color.decode(str);
            }
            catch(Exception ex) {}

            try
            {
                Color value = (Color)BeanUtil.getStaticFieldValue(Color.class, str);
                if(value != null)
                    return value;
            }
            catch(Exception ex) {}
        }

        return defaultColor;
    }

    /**
     * Return the value of the boolean System property propName.
     */
    public static boolean getBooleanProperty(String propName,
                                             boolean defaultValue)
    {
        // if set, require value of either true or false
        String b = (String)AccessController.doPrivileged(
            new sun.security.action.GetPropertyAction(propName));
        if(b == null)
            return defaultValue;

        return Boolean.parseBoolean(b);
    }

}
