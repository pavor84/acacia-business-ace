package com.cosmos.util;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author miro
 */
public class SystemInfo
{
    private static TreeMap<String, String> systemInfo = new TreeMap<String, String>();
    private static boolean wait = false;
    private static boolean isInitialized = false;

    static 
    {
        try
        {
            String osName = System.getProperty("os.name");
            if(osName != null)
            {
                if(osName.indexOf("Windows") >= 0)
                {
                    wait = true;
                    new WindowsSystemInfo().start();
                }
                else if(osName.indexOf("Linux") >= 0)
                {
                    wait = true;
                    new LinuxSystemInfo().start();
                }
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }

    public static String getSystemInfoAsString()
    {
        Map properties = getSystemInfo();
        StringBuilder sb = new StringBuilder();
        Set keys = getSystemInfo().keySet();
        for(Object key : keys)
        {
            sb.append(key).append(" :=> ").append(properties.get(key)).append("\n");
        }

        return sb.toString();
    }

    public static Map<String, String> getSystemInfo()
    {
        if(!isInitialized)
        {
            while(wait)
                Thread.currentThread().yield();

            try
            {
                Runtime rt = Runtime.getRuntime();
                put("java.memory.free", Long.toString(rt.freeMemory()));
                put("java.memory.max", Long.toString(rt.maxMemory()));
                put("java.memory.total", Long.toString(rt.totalMemory()));

                OperatingSystemMXBean os = ManagementFactory.getOperatingSystemMXBean();
                put("os.processors.total", Integer.toString(os.getAvailableProcessors()));

                put("java.runtime.name", System.getProperty("java.runtime.name"));
                put("java.runtime.version", System.getProperty("java.runtime.version"));
                put("java.vendor.url", System.getProperty("java.vendor.url"));
                put("java.vm.vendor", System.getProperty("java.vm.vendor"));
                put("java.vm.version", System.getProperty("java.vm.version"));
                put("os.arch", System.getProperty("os.arch"));
                put("os.name", System.getProperty("os.name"));
                put("os.version", System.getProperty("os.version"));
                put("sun.arch.data.model", System.getProperty("sun.arch.data.model"));
                put("sun.cpu.endian", System.getProperty("sun.cpu.endian"));
                put("sun.cpu.isalist", System.getProperty("sun.cpu.isalist"));
                put("sun.desktop", System.getProperty("sun.desktop"));
                put("sun.os.patch.level", System.getProperty("sun.os.patch.level"));
                put("user.country", System.getProperty("user.country"));
                put("user.language", System.getProperty("user.language"));
                put("user.name", System.getProperty("user.name"));
                put("user.timezone", System.getProperty("user.timezone"));

                Enumeration<NetworkInterface> niEnum = NetworkInterface.getNetworkInterfaces();
                int ifNumber = 0;
                while(niEnum.hasMoreElements())
                {
                    NetworkInterface ni = niEnum.nextElement();
                    if(ni.isLoopback())
                        continue;

                    String prefix = "network.interface." + ifNumber + ".";

                    put(prefix + "display.name", ni.getDisplayName());
                    put(prefix + "name", ni.getName());
                    put(prefix + "mac", macToString(ni.getHardwareAddress()));
                    put(prefix + "parent.network.interface", ni.getParent());

                    int i = 0;
                    Enumeration<InetAddress> iaEnum = ni.getInetAddresses();
                    while(iaEnum.hasMoreElements())
                    {
                        String p = prefix + "ip.address." + i;
                        put(p, iaEnum.nextElement());
                        i++;
                    }

                    List<InterfaceAddress> ifaList = ni.getInterfaceAddresses();
                    int size = ifaList.size();
                    for(i = 0; i < size; i++)
                    {
                        String p = prefix + "interface.address." + i;
                        put(p, ifaList.get(i));
                        i++;
                    }

                    i = 0;
                    Enumeration<NetworkInterface> sniEnum = ni.getSubInterfaces();
                    while(sniEnum.hasMoreElements())
                    {
                        String p = prefix + "virtual.network.interface." + i;
                        put(p, sniEnum.nextElement());
                        i++;
                    }

                    put(prefix + "is.point.to.point", ni.isPointToPoint());
                    put(prefix + "is.up", ni.isUp());
                    put(prefix + "is.virtual", ni.isVirtual());
                    put(prefix + "supports.multicast", ni.supportsMulticast());

                    ifNumber++;
                }
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
            finally
            {
                isInitialized = true;
            }
        }

        return systemInfo;
    }

    private static void put(String key, Object value)
    {
        if(value != null)
            put(key, value.toString());
    }

    private static void put(String key, String value)
    {
        if(value != null && (value = value.trim()).length() > 0)
            systemInfo.put(key, value);
    }

    private static String macToString(byte[] mac)
    {
        int size;
        if(mac == null || (size = mac.length) <= 0)
            return null;

        StringBuilder sb = new StringBuilder(size * 3);
        for(int i = 0; i < size; i++)
        {
            if(i > 0)
                sb.append(":");
            sb.append(Integer.toHexString(mac[i]));
        }

        return sb.toString();
    }

    private static Map<String, String> getSystemInfoMap(BufferedReader in)
    {
        TreeMap<String, String> map = new TreeMap<String, String>();
        try
        {
            String line = null;
            String key = null;
            StringBuilder sb = new StringBuilder();
            while((line = in.readLine()) != null)
            {
                if(line.length() == 0 || line.trim().length() == 0)
                    continue;
                if(line.startsWith(" "))
                {
                    if((line = line.trim()).length() > 0)
                    {
                        sb.append("; ").append(line);
                    }
                }
                else
                {
                    if(key != null && sb.length() > 0)
                    {
                        key = key.toLowerCase().replace(' ', '_');
                        put(key, sb.toString());
                        sb.setLength(0);
                        key = null;
                    }
                    int index = line.indexOf(":");
                    if(index < 0)
                        continue;
                    key = line.substring(0, index).trim();
                    sb.append(line.substring(index + 1).trim());
                }
            }
            if(key != null && sb.length() > 0)
            {
                key = key.toLowerCase().replace(' ', '_');
                put(key, sb.toString());
                sb.setLength(0);
                key = null;
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }

        return map;
    }

    private static class WindowsSystemInfo
        extends Thread
    {
        public void run()
        {
            try
            {
                ProcessBuilder pb = new ProcessBuilder("systeminfo");
                Process process = pb.start();

                BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
                systemInfo.putAll(getSystemInfoMap(in));
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
            finally
            {
                wait = false;
            }
        }
    }

    private static class LinuxSystemInfo
        extends Thread
    {
        public void run()
        {
            try
            {
//                ProcessBuilder pb = new ProcessBuilder("cat /proc/cpuinfo");
//                Process process = pb.start();
//                InputStream inStream = process.getInputStream();
                InputStream inStream = new FileInputStream("/proc/cpuinfo");
                BufferedReader in = new BufferedReader(new InputStreamReader(inStream));
                systemInfo.putAll(getSystemInfoMap(in));

//                pb = new ProcessBuilder("cat /proc/meminfo");
//                process = pb.start();
//                inStream = process.getInputStream();
                inStream = new FileInputStream("/proc/meminfo");
                in = new BufferedReader(new InputStreamReader(inStream));
                systemInfo.putAll(getSystemInfoMap(in));
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
            finally
            {
                wait = false;
            }
        }
    }

    

    public static void main(String[] args)
    {
        Map properties = getSystemInfo();

        StringBuilder sb = new StringBuilder();
//        TreeSet keys = new TreeSet(properties.keySet());
        Set keys = properties.keySet();
        for(Object key : keys)
        {
            sb.append(key).append(" :=> ").append(properties.get(key)).append("\n");
        }

        System.out.println(sb.toString());
        System.out.flush();

        System.out.println(getSystemInfoAsString());
        System.out.flush();

    }
}

