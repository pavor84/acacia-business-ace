package com.cosmos.util.data;

public class StringIgnoreCaseKey
    implements IndexKey<StringIgnoreCaseKey>
{
    private String stringValue;

    public StringIgnoreCaseKey(String stringValue)
    {
        this.stringValue = stringValue;
    }

    public int compareTo(StringIgnoreCaseKey other)
    {
        if(other == null)
        {
            throw new NullPointerException();
        }

        if(stringValue != null && other.stringValue != null)
        {
            return stringValue.compareToIgnoreCase(other.stringValue);
        }

        if(stringValue == null && other.stringValue == null)
        {
            return 0;
        }

        if(stringValue != null)
        {
            return 1;
        }

        return -1;
    }

    public boolean equals(Object otherObject)
    {
        if(otherObject == null || !(otherObject instanceof StringIgnoreCaseKey))
        {
            return false;
        }

        StringIgnoreCaseKey other = (StringIgnoreCaseKey)otherObject;

        if(stringValue == null && other.stringValue == null)
        {
            return true;
        }

        if(stringValue != null && other.stringValue != null)
        {
            return stringValue.equalsIgnoreCase(other.stringValue);
        }

        return false;
    }
}
