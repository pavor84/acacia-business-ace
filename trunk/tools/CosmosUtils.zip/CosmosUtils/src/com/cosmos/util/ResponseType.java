/*
 * ResponseType.java
 *
 * Created on Вторник, 2006, Декември 5, 11:51
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.cosmos.util;

/**
 *
 * @author miro
 */
public enum ResponseType
{
    YES("Yes"),
    OK("OK"),
    NO("No"),
    CANCEL("Cancel"),
    CLOSE("Close"),
    LOGIN("Login"),
    USERNAME("Username"),
    PASSWORD("Password"),
    ADD_FILE("AddFile"),
    REMOVE_FILE("RemoveFile"),
    PREVIEW_FILE("PreviewFile"),
    VALIDATE("Validate");


    private ResponseType(String actionName)
    {
        this.actionName = actionName;
    }

    public int getValue()
    {
        return super.ordinal();
    }

    public String getActionName()
    {
        return actionName;
    }

    private String actionName;
}
