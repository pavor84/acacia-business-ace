package com.cosmos.util;

import com.cosmos.util.filesystem.FileBean;
import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class BeanUtil
{
	private static final Object[] ARGS_NO_PARAMETERS = new Object[] {};

    public static Object getPropertyValue(Object bean, String property)
	{
        if(bean == null)
            return null;

        if(property == null || property.trim().length() <= 0)
            throw new IllegalArgumentException("It is not possible the property to be NULL or empty.");
        
        ArrayList<String> properties = new ArrayList<String>();
        StringTokenizer propToks = new StringTokenizer(property, ".");
        while(propToks.hasMoreTokens())
        {
            properties.add(propToks.nextToken());
        }

        return getPropertyValue(bean, properties);
    }
    
    protected static Object getPropertyValue(Object bean, List<String> properties)
	{
        int propSize = properties.size();
        if(properties == null || propSize <= 0)
            return null;

        String property = properties.get(0);

        Method method = getGetterMethod(bean, property);
        if(method != null)
        {
            try
            {
                Object value = method.invoke(bean, ARGS_NO_PARAMETERS);
                if(propSize > 1 && value != null)
                {
                    properties.remove(0);
                    value = getPropertyValue(value, properties);
                }

                return value;
            }
            catch(Exception ex)
            {
//                ex.printStackTrace();
            }
        }

        Field field = getField(bean, property);
        if(field != null)
        {
            try
            {
                Object value = field.get(bean);
                if(propSize > 1 && value != null)
                {
                    properties.remove(0);
                    value = getPropertyValue(value, properties);
                }
                return value;
            }
            catch(Exception ex)
            {
//                ex.printStackTrace();
            }
        }

        throw new RuntimeException("No such property(is/get/set method or field): '" + property + "' in " + bean.getClass().getName());
    }

    public static void setPropertyValue(Object bean, String property, Object value)
	{
        if(bean == null)
            throw new IllegalArgumentException("It is not possible the bean to be NULL.");

        if(property == null || property.trim().length() <= 0)
            throw new IllegalArgumentException("It is not possible the property to be NULL or empty.");

        ArrayList<String> properties = new ArrayList<String>();
        StringTokenizer propToks = new StringTokenizer(property, ".");
        while(propToks.hasMoreTokens())
        {
            properties.add(propToks.nextToken());
        }

        int propSize = properties.size();
        if(properties == null || propSize <= 0)
            return;
        if(propSize > 1)
        {
            property = properties.get(propSize - 1);
            properties.remove(propSize - 1);
            bean = getPropertyValue(bean, properties);
            if(bean == null)
                return;
        }

        Method method = getSetterMethod(bean, property, value);
        if(method != null)
        {
            try
            {
                method.invoke(bean, value);
                return;
            }
            catch(Exception ex)
            {
//                ex.printStackTrace();
            }
        }

        Field field = getField(bean, property);
        if(field != null)
        {
            try
            {
                field.set(bean, value);
            }
            catch(Exception ex)
            {
//                ex.printStackTrace();
            }
        }

        throw new RuntimeException("No such property(is/get/set method or field): " + property + " in " + bean.getClass().getName());
    }

    protected static Method getGetterMethod(Object bean, String property)
    {
        String propertyName = toTitleCase(property);

        Method method = getMethod(bean, "is" + propertyName);
        if(method != null)
            return method;
        
        method = getMethod(bean, "get" + propertyName);
        if(method != null)
            return method;

        return getMethod(bean, property);
    }

    protected static Method getSetterMethod(Object bean, String property, Object value)
    {
        Class[] parameterTypes = getParameterTypes(value);
        String propertyName = toTitleCase(property);

        Method method = getMethod(bean, "set" + propertyName, parameterTypes);
        if(method != null)
            return method;

        return getMethod(bean, property, parameterTypes);
    }

    protected static Class<?>[] getParameterTypes(Object value)
    {
        Class<?>[] parameterTypes = null;
        if(value != null)
        {
            if(value instanceof Object[])
            {
                Object[] arrayParameter = (Object[])value;
                int size = arrayParameter.length;
                parameterTypes = new Class[size];
                for(int i = 0; i < size; i++)
                {
                    Object parameter = arrayParameter[i];
                    if(parameter != null)
                    {
                        parameterTypes[i] = parameter.getClass();
                    }
                    else
                    {
                        parameterTypes[i] = null;
                    }
                }
            }
            else
            {
                parameterTypes = new Class[] {value.getClass()};
            }
        }
        return parameterTypes;
    }
    
    protected static Method getMethod(Object bean, String property)
    {
        return getMethod(bean, property, null);
    }

    protected static Method getMethod(Object bean, String property, Class<?>[] parameterTypes)
    {
        if(bean != null && property != null)
        {
            Class beanClass = bean.getClass();
            try
            {
                return beanClass.getMethod(property, parameterTypes);
            }
            catch (NoSuchMethodException ex)
            {
//                ex.printStackTrace();
                Method[] methods = beanClass.getMethods();
                for(Method method : methods)
                {
                    if(property.equals(method.getName()))
                        return method;
                }
            }
        }
        return null;
    }

    protected static Field getField(Object bean, String property)
    {
        if(bean != null && property != null)
        {
            try
            {
                return bean.getClass().getField(property);
            }
            catch (NoSuchFieldException ex)
            {
//                ex.printStackTrace();
            }
        }
        return null;
    }

    protected static String toTitleCase(String value)
    {
        if(value != null)
        {
			StringBuilder sb = new StringBuilder(value.length());
			sb.appendCodePoint(Character.toTitleCase(value.codePointAt(0)));
			sb.append(value.substring(1));
			return sb.toString();
        }

        return null;
    }

    public static Object getStaticFieldValue(Class sourceClass, String fieldName)
    {
        return getStaticFieldValue(sourceClass, fieldName, null);
    }

    public static Object getStaticFieldValue(Class sourceClass, String fieldName, String prefixFieldName)
    {
        if(sourceClass == null)
            throw new IllegalArgumentException("The source class can not be NULL.");
        if(fieldName == null || (fieldName = fieldName.trim()).length() <= 0)
            throw new IllegalArgumentException("The field name can not be NULL or empty: '" + fieldName + "'.");

        fieldName = fieldName.toUpperCase();
        if(prefixFieldName != null && (prefixFieldName = prefixFieldName.trim()).length() > 0)
        {
            prefixFieldName = prefixFieldName.toUpperCase();
            if(!fieldName.startsWith(prefixFieldName))
            {
                fieldName = prefixFieldName + fieldName;
            }
        }

        try
        {
            Field field = sourceClass.getField(fieldName);
            if(field != null && Modifier.isStatic(field.getModifiers()))
            {
                return field.get(null);
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }

        return null;
    }


    public static void main(String[] args)
    {
        FileBean fileBean = new FileBean(new File("."));
        Object value = getPropertyValue(fileBean, "size");
        System.out.println("value: " + value);
        value = getPropertyValue(fileBean, "file");
        System.out.println("value: " + value);

        setPropertyValue(fileBean, "file", new File("E:\\BluesRecorderPro.log"));
        value = getPropertyValue(fileBean, "file.length");
        System.out.println("value: " + value);
        value = getPropertyValue(fileBean, "file");
        System.out.println("value: " + value);

        setPropertyValue(fileBean, "file", null);
        value = getPropertyValue(fileBean, "file");
        System.out.println("value: " + value);
    }
}
