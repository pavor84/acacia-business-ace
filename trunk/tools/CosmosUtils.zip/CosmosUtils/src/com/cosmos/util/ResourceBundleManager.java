package com.cosmos.util;

import com.cosmos.util.ResourceBundleControl;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 *
 * @author miro
 */
public class ResourceBundleManager
{
    public static final String RESOURCE_BUNDLE_KEY_NAME     = "com.cosmos.ResourceBundle";
    public static final String RESOURCE_BUNDLE_LOCAL_FOLDER  = "com.cosmos.LocalFolder";

    private static ResourceBundle resourceBundle;
    private static String resourceBundleName;

    public static ResourceBundle getResourceBundle()
    {
        if(resourceBundle == null)
        {
            ResourceBundleControl control = new ResourceBundleControl();
            try
            {
                resourceBundle = ResourceBundle.getBundle(getResourceBundleName(), control);
            }
            catch(MissingResourceException ex)
            {
                Locale.setDefault(Locale.ENGLISH);
                resourceBundle = ResourceBundle.getBundle(getResourceBundleName(), control);
            }
        }

        return resourceBundle;
    }

    public static String getResourceBundleName()
    {
        if(resourceBundleName != null)
            return resourceBundleName;

        resourceBundleName = System.getProperty(RESOURCE_BUNDLE_KEY_NAME);
        if(resourceBundleName != null)
            return resourceBundleName;

        throw new IllegalArgumentException("getResourceBundleName() must be implemented or System Property \"com.cosmos.ResourceBundle\" must be setted.");
    }

    public static void setResourceBundleName(String resourceName)
    {
        resourceBundleName = resourceName;
    }

    public static void resetResourceBundle()
    {
        resourceBundle = null;
    }

    /*public static ImageIcon getIcon(String iconName, boolean large)
    {
        if(iconName != null && (iconName = iconName.trim()).length() > 0)
        {
            try
            {
                String iconKey = "icon." + iconName + (large ? ".Large" : ".Small");
                String iconLocation = getResourceBundle().getString(iconKey);
                if(iconLocation != null)
                {
                    InputStream inStream = SystemUtils.getResourceAsStream(iconLocation);
                    if(inStream != null)
                    {
                        return new ImageIcon(SystemUtils.toByteArray(inStream));
                    }
                }
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
        }
        return null;
    }

    public static String getString(String key, String defaultValue)
    {
        ResourceBundle rb = null;
        try
        {
            rb = getResourceBundle();
            if(rb != null)
            {
                String value = rb.getString(key);
                if(value != null)
                    return value;
            }
        }
        catch(Exception ex)
        {
//            ex.printStackTrace();
        }

        return defaultValue;
    }*/
}
