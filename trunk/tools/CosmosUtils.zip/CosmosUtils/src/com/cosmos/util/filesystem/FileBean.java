package com.cosmos.util.filesystem;

import com.cosmos.bean.table.BeanTableModel;
import com.cosmos.bean.table.ColumnType;
import com.cosmos.util.SystemUtils;
import com.cosmos.util.data.ComparableBean;
import com.cosmos.util.data.UniversalIndexKey;
import java.io.File;
import java.util.Date;
import java.util.ResourceBundle;

public class FileBean
    implements Comparable<FileBean>,
	Cloneable
{
    private static final long KILOBYTE = 0x400;
    private static final long MEGABYTE = 0x100000;
    private static final long GIGABYTE = 0x40000000;

    private File file;

    public FileBean(File file)
    {
        if(file == null)
            throw new IllegalArgumentException("The file argument can not be NULL.");

        try
        {
            this.file = file.getCanonicalFile();
        }
        catch(Exception ex)
        {
            this.file = file;
        }
    }

    public int compareTo(FileBean otherFile)
    {
        return file.compareTo(otherFile.file);
    }

    public boolean equals(Object other)
    {
        if(!(other instanceof FileBean))
            return false;

        FileBean otherFile = (FileBean)other;

        return file.equals(otherFile.file);
    }

    public int hashCode()
    {
        return file.hashCode();
    }

    public String getSize()
    {
        return getStringSize(file.length());
    }

    public String getLastModified()
    {
        return SystemUtils.formatDate(new Date(file.lastModified()));
    }

    public String getName()
    {
        return file.getName();
    }

    public String getFullName()
    {
        return file.getAbsolutePath();
    }

    public String getPath()
    {
        return file.getParent();
    }

    public File getFile()
    {
        return file;
    }

    private String getStringSize(long size)
    {
        String suffix;
        double fileSize = size;
        if(size > GIGABYTE)
        {
            fileSize /= GIGABYTE;
            suffix = " GB";
        }
        else if(size > MEGABYTE)
        {
            fileSize /= MEGABYTE;
            suffix = " MB";
        }
        else if(size > KILOBYTE)
        {
            fileSize /= KILOBYTE;
            suffix = " KB";
        }
        else
            suffix = " Bytes";

        return SystemUtils.getDecimalFormatter().format(fileSize) + suffix;
    }

    public Object clone()
    {
	try
        {
	    return super.clone();
	}
        catch(CloneNotSupportedException ex)
        {
	    throw new InternalError(ex.toString());
	}
    }

    public String toString()
    {
        return file.getAbsolutePath();
    }


    public static BeanTableModel getBeanTableModel()
    {
        return getBeanTableModel(false);
    }

    public static BeanTableModel getBeanTableModel(boolean showPathName)
    {
        BeanTableModel tableModel = new FileSystemTableModel();
        tableModel.addColumn(
                "FileName",
                "name",
                "File name",
                ColumnType.STRING
            );
        tableModel.addColumn(
                "FilePath",
                "path",
                "File pathname",
                ColumnType.STRING,
                showPathName
            );
        tableModel.addColumn(
                "FileAbsolutePath",
                "fullName",
                "Absolute file pathname",
                ColumnType.STRING,
                false
            );
        tableModel.addColumn(
                "FileSize",
                "size",
                "File size",
                ColumnType.STRING
            );
        tableModel.addColumn(
                "FileLastModified",
                "lastModified",
                "Last modified",
                ColumnType.STRING
            );

        return tableModel;
    }

    protected static ResourceBundle getResourceBundle()
    {
        return ResourceBundle.getBundle("com.cosmos.util.filesystem.FileBean");
    }

    private static class FileSystemTableModel
        extends BeanTableModel<FileBean>
    {
        ResourceBundle resourceBundle;

        public FileSystemTableModel()
        {
        }

        public ResourceBundle getResourceBundle()
        {
            try
            {
                return super.getResourceBundle();
            }
            catch(Exception ex)
            {
//                ex.printStackTrace();
            }

            if(resourceBundle == null)
            {
                resourceBundle = FileBean.getResourceBundle();
            }

            return resourceBundle;
        }
    }
}
