package com.cosmos.util;

import java.util.zip.CRC32;
import sun.misc.CRC16;

/**
 *
 * @author miro
 */
public class CRCHelper
{
    
    /** Creates a new instance of CRCHelper */
    public CRCHelper()
    {
    }

    public static void main(String[] args)
    {
        CRC16 crc16 = new CRC16();
        crc16.value = 0xFFFF;
        System.out.println("CRC-16: " + crc16.value);
        for(int i = 0; i <= 15; i++)
        {
            crc16.update((byte)i);
        }
        System.out.println("CRC-16: " + crc16.value + ", hex: " + Integer.toHexString(crc16.value));

        CRC32 crc32 = new CRC32();
    }

    public class TestCRC16
    {

        /** value contains the currently computed CRC, set it to 0 initally */
        public int value;

        public TestCRC16()
        {
            value = 0;
        }

        /** update CRC with byte b */
        public void update(byte aByte)
        {
            int a, b;

            a = (int) aByte;
            for(int count = 7; count >= 0; count--)
            {
                a = a << 1;
                b = (a >>> 8) & 1;
                if((value & 0x8000) != 0)
                {
                    value = ((value << 1) + b) ^ 0x1021;
                }
                else
                {
                    value = (value << 1) + b;
                }
            }
            value = value & 0xffff;
            return;
        }

        /** reset CRC value to 0 */
        public void reset()
        {
            value = 0;
        }
    }

}
