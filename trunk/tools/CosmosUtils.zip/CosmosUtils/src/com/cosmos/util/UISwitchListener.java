/*
 * UISwitchListener.java
 *
 * Created on Събота, 2006, Ноември 25, 15:18
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.cosmos.util;

import java.awt.Component;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 *
 *  JFrame:
 * 	UIManager.addPropertyChangeListener(new UISwitchListener((JComponent)getRootPane()));
 * 
 * @author miro
 */
public class UISwitchListener
    implements PropertyChangeListener
{
    Component componentToSwitch;

    public UISwitchListener(Component c)
    {
        componentToSwitch = c;
    }

    public void propertyChange(PropertyChangeEvent event)
    {
        String name = event.getPropertyName();
        if(name.equals("lookAndFeel"))
        {
            SwingUtilities.updateComponentTreeUI(componentToSwitch);
            if(componentToSwitch instanceof JFrame)
            {
                ((JFrame)componentToSwitch).pack();
            }
            componentToSwitch.invalidate();
            componentToSwitch.validate();
            componentToSwitch.repaint();
        }
    }
}
