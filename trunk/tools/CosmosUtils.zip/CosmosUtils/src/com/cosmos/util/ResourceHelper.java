package com.cosmos.util;

import com.cosmos.net.URIHelper;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.JarURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 *
 * @author miro
 */
public class ResourceHelper
{
    private String classFileName;
    private String resourceFolderName;
    private URL resourceURL;
    private Enumeration<ResourceEntry> resourceEntries;
    
    public ResourceHelper(Class clazz)
        throws IOException
    {
        this(clazz, null);
    }

    public ResourceHelper(Class clazz, String resourceFolderName)
        throws IOException
    {
        this.resourceFolderName = resourceFolderName;
        classFileName = clazz.getName().replace('.', '/') + ".class";
        ClassLoader classLoader = clazz.getClassLoader();
        resourceURL = classLoader.getSystemResource(classFileName);
        if(resourceURL == null)
        {
            resourceURL = classLoader.getResource(classFileName);
        }
        if(resourceURL == null)
            throw new IOException("Impossible to find Resource URL.");
    }

    public URL getResourceURL()
    {
        return resourceURL;
    }

    public Enumeration<ResourceEntry> resourceEntries()
        throws IOException
    {
        if(resourceEntries == null)
        {
            String protocol = resourceURL.getProtocol().toLowerCase();
            if("file".equals(protocol))
            {
                String path = resourceURL.getPath();
                int pos = path.length() - classFileName.length();
                String basePath = path.substring(0, pos);
                File baseFolder = new File(basePath);
                if(resourceFolderName != null)
                    baseFolder = new File(baseFolder, resourceFolderName);
                List<File> fileStore = new ArrayList<File>();
                loadFiles(baseFolder, fileStore);
                return new FileResourceEntries(fileStore);
            }
            else if("jar".equals(protocol))
            {
                resourceEntries = new JarResourceEntries(resourceURL, resourceFolderName);
            }
            else
                resourceEntries = new EmptyResourceEntries();
        }

        return resourceEntries;
    }

    private void loadFiles(File folder, List<File> fileStore)
    {
        for(File file : folder.listFiles())
        {
            fileStore.add(file);
            if(file.isDirectory())
                loadFiles(file, fileStore);
        }
    }

    private static class EmptyResourceEntries
        implements Enumeration<ResourceEntry>
    {
        public boolean hasMoreElements()
        {
            return false;
        }

        public ResourceEntry nextElement()
        {
            throw new NoSuchElementException();
        }
    }

    private static class JarResourceEntries
        implements Enumeration<ResourceEntry>
    {
        private String uriString;
        private JarFile jarFile;
        private Iterator<JarEntry> entries;

        public JarResourceEntries(URL resourceURL, String resourceFolderName)
            throws IOException
        {
            JarURLConnection jarConn = (JarURLConnection)resourceURL.openConnection();
            jarFile = jarConn.getJarFile();

            try
            {
                uriString = resourceURL.toURI().toString();
            }
            catch(Exception ex)
            {
                throw new IOException(ex);
            }

            int index = uriString.indexOf("!/");
            if(index >= 0)
            {
                uriString = uriString.substring(0, index);
            }

            List<JarEntry> jarEntryList = new ArrayList<JarEntry>();
            Enumeration<JarEntry> jarEntries = jarFile.entries();
            while(jarEntries.hasMoreElements())
            {
                JarEntry entry = jarEntries.nextElement();
                if(resourceFolderName == null || entry.getName().startsWith(resourceFolderName))
                    jarEntryList.add(entry);
            }

            entries = jarEntryList.iterator();
        }

        public boolean hasMoreElements()
        {
            return entries.hasNext();
        }

        public ResourceEntry nextElement()
        {
            return new JarResourceEntry(uriString, jarFile, entries.next());
        }
    }

    private static class FileResourceEntries
        implements Enumeration<ResourceEntry>
    {
        private Iterator<File> entries;

        public FileResourceEntries(List<File> fileStore)
        {
            entries = fileStore.iterator();
        }

        public boolean hasMoreElements()
        {
            return entries.hasNext();
        }

        public ResourceEntry nextElement()
        {
            return new FileResourceEntry(entries.next());
        }
    }

    public static interface ResourceEntry
    {
        public URI getSourceURI()
            throws IOException;
        public boolean isDirectory();
        public InputStream getInputStream()
            throws IOException;
    }

    private static class FileResourceEntry
        implements ResourceEntry
    {
        private File file;

        public FileResourceEntry(File file)
        {
            this.file = file;
        }

        public URI getSourceURI()
            throws IOException
        {
            return file.toURI();
        }

        public boolean isDirectory()
        {
            return file.isDirectory();
        }

        public InputStream getInputStream()
            throws IOException
        {
            return new FileInputStream(file);
        }
    }

    private static class JarResourceEntry
        implements ResourceEntry
    {
        private String uriString;
        private JarFile jarFile;
        private JarEntry entry;

        public JarResourceEntry(String uriString, JarFile jarFile, JarEntry entry)
        {
            this.uriString = uriString;

            this.entry = entry;
            this.jarFile = jarFile;
        }

        public URI getSourceURI()
            throws IOException
        {
            try
            {
                String name = URIHelper.toASCIIPath(entry.getName());
                return new URI(uriString + "!/" + name);
            }
            catch(Exception ex)
            {
                throw new IOException(ex);
            }
        }

        public boolean isDirectory()
        {
            return entry.isDirectory();
        }

        public InputStream getInputStream()
            throws IOException
        {
            return jarFile.getInputStream(entry);
        }
    }
}
