package com.cosmos.util.filesystem;

import java.io.File;
import com.cosmos.form.JBTree;
import java.io.File;
import javax.swing.tree.TreePath;
import javax.swing.event.TreeWillExpandListener;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.tree.ExpandVetoException;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeSelectionModel;

/**
 * <p>Title: FileSystemTree</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: COSMOS Software Enterprises, Ltd.</p>
 *
 * @author Miroslav Nachev
 * @version 1.0
 */
public class FileSystemTree
    extends JBTree
{
    public FileSystemTree()
    {
        this(new File("."));
    }

    public FileSystemTree(File selectedFolder)
    {
        this(selectedFolder.getAbsolutePath());
    }

    public FileSystemTree(String selectedFolderName)
    {
        super(new FileSystemTreeModel());
        getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        addTreeWillExpandListener(new FileSystemTreeWillHandler());
        ((FileSystemTreeModel)getModel()).setFileSystemTree(this);
        setCellRenderer(new FileSystemTreeRenderer());
        setSelectedFolder(selectedFolderName);
    }

    public void setModel(TreeModel model)
    {
        super.setModel(model);
        if(model != null)
        {
            ((FileSystemTreeModel)model).setFileSystemTree(this);
        }
    }
    
    public void setSelectedFolder(File fileFolder)
    {
        setSelectedFolder(fileFolder.getAbsolutePath());
    }

    public void setSelectedFolder(String folderName)
    {
        FileSystemTreeNode root = (FileSystemTreeNode)getModel().getRoot();
        TreePath path = root.getFileTreePath(folderName);
        if(path != null)
        {
            scrollPathToVisible(path);
            setSelectionPath(path);
        }
    }

    public File getSelectedFolder()
    {
        FileSystemTreeNode node = (FileSystemTreeNode)getLastSelectedPathComponent();
        if(node != null)
        {
            return node.getFile();
        }
        return null;
    }

    public void setVisibleFolder(String folderName)
    {
        FileSystemTreeNode root = (FileSystemTreeNode)getModel().getRoot();
        TreePath path = root.getFileTreePath(folderName);
        if(path != null)
        {
            scrollPathToVisible(path);
        }
    }

    private class FileSystemTreeWillHandler
        implements TreeWillExpandListener
    {
        public void treeWillCollapse(TreeExpansionEvent event)
            throws ExpandVetoException
        {
        }

        public void treeWillExpand(TreeExpansionEvent event)
            throws ExpandVetoException
        {
            TreePath path = event.getPath();
            FileSystemTreeNode selectedNode = (FileSystemTreeNode)path.getLastPathComponent();

            if(!selectedNode.isChildrenAreLoaded())
            {
                selectedNode.loadChildren();
            }
        }
    }
}
