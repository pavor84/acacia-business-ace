package com.cosmos.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import java.util.TreeMap;

/**
 *
 * @author miro
 */
public class UIResourceManager
{
    private static final String thisClassName = UIResourceManager.class.getName();
    private static TreeMap<String, ResourceBundle> systemResources = new TreeMap<String, ResourceBundle>();
    private static List<ResourceBundle> resources = new ArrayList<ResourceBundle>();

    private static String[] unusedPackages = 
    {
        "com.sun.",
        "sun.",
        "sunw.",
        "java.",
        "javax.",
        "org.apache.",
        "org.ietf.",
        "org.jcp.",
        "org.omg.",
        "org.relaxng.",
        "org.w3c.",
        "org.xml.",
        "org.hibernate.",
    };

    private UIResourceManager()
    {
    }

    public static String getResourceString(String key)
    {
        return getResourceString(key, null);
    }

    public static String getResourceString(String key, String defaultValue)
    {
        ResourceBundle rb = getResourceBundle();

        String value;
        if(rb != null)
        {
            try
            {
                value = rb.getString(key);
                if(value != null)
                    return value;
            }
            catch(Exception ex) {}
        }

        List<ResourceBundle> rbs = getSystemResourceBundles();
        Collections.reverse(rbs);
        for(ResourceBundle r : rbs)
        {
            try
            {
                value = r.getString(key);
                if(value != null)
                {
                    return value;
                }
            }
            catch(Exception ex) {}
        }

        for(ResourceBundle r : resources)
        {
            try
            {
                value = r.getString(key);
                if(value != null)
                {
                    return value;
                }
            }
            catch(Exception ex) {}
        }

        return defaultValue;
    }

    public static Object getResourceObject(String key)
    {
        return getResourceObject(key, null);
    }

    public static Object getResourceObject(String key, Object defaultValue)
    {
        return defaultValue;
    }

    private static ResourceBundle getResourceBundle()
    {
        try
        {
            return ResourceBundleManager.getResourceBundle();
        }
        catch(Exception ex)
        {
            return null;
        }
    }

    private static List<ResourceBundle> getSystemResourceBundles()
    {
        ArrayList<ResourceBundle> rbs = new ArrayList<ResourceBundle>();
        List<String> classNames = getInvokerClassNames();
        for(String className : classNames)
        {
            ResourceBundle rb = getSystemResourceBundle(className);
            if(rb != null)
            {
                rbs.add(rb);
            }
        }

        return rbs;
    }

    private static ResourceBundle getSystemResourceBundle(String className)
    {
        String packageName = getInvokerPackageName(className);
        if(systemResources.containsKey(packageName))
            return systemResources.get(packageName);

        ResourceBundle firstAvailableRB = null;
        ResourceBundle lastAvailableRB = null;
        while(packageName != null)
        {
            ResourceBundle rb = getResourceBundle(packageName, className);
            systemResources.put(packageName, rb);

            if(rb != null)
            {
                if(!resources.contains(rb))
                    resources.add(rb);

                if(lastAvailableRB != null)
                {
                    SmartResourceBundle srb = (SmartResourceBundle)lastAvailableRB;
                    SmartResourceBundle prb = srb.getParentResourceBundle();
                    while(prb != null)
                    {
                        srb = prb;
                        prb = srb.getParentResourceBundle();
                    }

                    srb.setParentResourceBundle((SmartResourceBundle)rb);
                }

                if(firstAvailableRB == null)
                    firstAvailableRB = rb;
                lastAvailableRB = rb;
            }

            packageName = getParentPackageName(packageName);
        }

        return firstAvailableRB;
    }

    private static String getParentPackageName(String packageName)
    {
        if(packageName == null || packageName.length() == 0)
            return null;

        if(packageName.endsWith("."))
            packageName = packageName.substring(0, packageName.length() - 1);

        int index = packageName.lastIndexOf('.');
        if(index > 0)
            return packageName.substring(0, index + 1);
        else
            return "";
    }

    private static ResourceBundle getResourceBundle(String packageName, String className)
    {
        ResourceBundleControl control;
        Class clazz = null;
        try
        {
            clazz = Class.forName(className);
            control = new ResourceBundleControl(clazz);
        }
        catch(Exception ex)
        {
            control = new ResourceBundleControl();
        }

        String resourceBundleName = packageName + "system_resources";
        try
        {
            return ResourceBundle.getBundle(resourceBundleName, control);
        }
        catch(Exception ex)
        {
            return null;
        }
    }

    private static String getInvokerPackageName(String className)
    {
        if(className != null)
        {
            int index = className.lastIndexOf('.');
            if(index > 0)
            {
                return className.substring(0, index + 1);
            }
        }

        return "";
    }

    private static List<String> getInvokerClassNames()
    {
        int depth = 0;
        ArrayList<String> classNames = new ArrayList<String>();
        ArrayList<String> packageNames = new ArrayList<String>();
        Throwable ex = new Throwable();
        for(StackTraceElement ste : ex.getStackTrace())
        {
            String className = ste.getClassName();
            if(isUnusedPackage(className))
                continue;
            String packageName = getInvokerPackageName(className);
            if(!thisClassName.equals(className) && !packageNames.contains(packageName))
            {
                classNames.add(className);
                packageNames.add(packageName);
            }
        }
        packageNames.clear();
        packageNames = null;

        return classNames;
    }

    private static boolean isUnusedPackage(String packageName)
    {
        for(String prefix : unusedPackages)
        {
            if(packageName.startsWith(prefix))
                return true;
        }

        return false;
    }
}
