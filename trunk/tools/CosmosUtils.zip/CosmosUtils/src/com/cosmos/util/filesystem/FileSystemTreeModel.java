package com.cosmos.util.filesystem;

import javax.swing.tree.DefaultTreeModel;
import java.io.File;

/**
 * <p>Title: FileSystemTree</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: COSMOS Software Enterprises, Ltd.</p>
 *
 * @author Miroslav Nachev
 * @version 1.0
 */
public class FileSystemTreeModel
	extends DefaultTreeModel
{
	private FileSystemTree fileSystemTree;

	public FileSystemTreeModel()
	{
		this(new FileSystemTreeNode());
	}

	public FileSystemTreeModel(File rootFile)
	{
		this(new FileSystemTreeNode(rootFile));
	}

	public FileSystemTreeModel(FileSystemTreeNode root, boolean asksAllowsChildren)
	{
		super(root, asksAllowsChildren);
		root.setTreeModel(this);
	}

	public FileSystemTreeModel(FileSystemTreeNode root)
	{
		super(root);
		root.setTreeModel(this);
	}

	public FileSystemTree getFileSystemTree()
	{
		return fileSystemTree;
	}

	void setFileSystemTree(FileSystemTree fileSystemTree)
	{
		this.fileSystemTree = fileSystemTree;
	}
}
