package com.cosmos.util;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.jdesktop.jdic.filetypes.Action;
import org.jdesktop.jdic.filetypes.Association;
import org.jdesktop.jdic.filetypes.AssociationAlreadyRegisteredException;
import org.jdesktop.jdic.filetypes.AssociationNotRegisteredException;
import org.jdesktop.jdic.filetypes.AssociationService;
import org.jdesktop.jdic.filetypes.RegisterFailedException;

/**
 * <p>Title: Cosmos Security</p>
 *
 * <p>Description: Cosmos X509/XML Security Library</p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: COSMOS Software Enterprises, Ltd.</p>
 *
 * @author Miroslav Nachev
 * @version 1.0
 */
public class AssociationHelper
{
    private static AssociationService associationService = new AssociationService();

    private AssociationHelper()
    {
    }


    public static Association getFileExtensionAssociation(String fileExt)
    {
        return associationService.getFileExtensionAssociation(fileExt);
    }

    public static Association getMimeTypeAssociation(String mimeType)
    {
        return associationService.getMimeTypeAssociation(mimeType);
    }

    public static Association getAssociationByContent(URL url)
    {
        return associationService.getAssociationByContent(url);
    }

    public static void registerAssociation(Association association)
        throws AssociationAlreadyRegisteredException,
            RegisterFailedException
    {
        try
        {
            associationService.registerSystemAssociation(association);
        }
        catch(RegisterFailedException ex)
        {
            associationService.registerUserAssociation(association);
        }
    }

    public static void unregisterAssociation(Association association)
        throws AssociationNotRegisteredException,
            RegisterFailedException
    {
        try
        {
            associationService.unregisterSystemAssociation(association);
        }
        catch(RegisterFailedException ex)
        {
            associationService.unregisterUserAssociation(association);
        }
    }

    public static void associateFileExtension(String fileExt,
                                              Action action)
        throws AssociationAlreadyRegisteredException,
            RegisterFailedException
    {
        associateFileExtension(fileExt, action, null);
    }

    public static void associateFileExtension(String fileExt,
                                              Action action,
                                              String iconFileName)
        throws AssociationAlreadyRegisteredException,
            RegisterFailedException
    {
        associateFileExtension(fileExt,
                               "application-x/" + trim(fileExt),
                               action,
                               iconFileName);
    }

    public static void associateFileExtension(String fileExt,
                                              String mimeType,
                                              Action action,
                                              String iconFileName)
        throws AssociationAlreadyRegisteredException,
            RegisterFailedException
    {
        associateFileExtension(Collections.<String>singletonList(fileExt),
                               mimeType,
                               action,
                               iconFileName);
    }

    public static void associateFileExtension(List<String> fileExtList,
                                              String mimeType,
                                              Action action,
                                              String iconFileName)
        throws AssociationAlreadyRegisteredException,
            RegisterFailedException
    {
        String verb = action.getVerb().toLowerCase();
        String command = action.getCommand().toLowerCase();
        int index = command.indexOf('%');
        if(index > 0)
            command = command.substring(0, index).trim();

        List<Association> oldAssociations = new ArrayList<Association>(fileExtList.size());
        Association association = new Association();
        for(String fileExt : fileExtList)
        {
            fileExt = trim(fileExt);
            association.addFileExtension(fileExt);
            Association existingAssociation = getFileExtensionAssociation(fileExt);
            if(existingAssociation != null)
            {
                oldAssociations.add(existingAssociation);

                for(Object obj : existingAssociation.getActionList())
                {
                    Action oldAction = (Action)obj;
                    String c = oldAction.getCommand();
                    String v = oldAction.getVerb();
                    if(c != null && v != null &&
                       c.toLowerCase().indexOf(command) >= 0 &&
                       v.equalsIgnoreCase(verb))
                        return;
                }
            }
        }

        association.setMimeType(trim(mimeType));

        File file;
        if(iconFileName != null && (file = new File(iconFileName)).exists())
        {
            association.setIconFileName(iconFileName);
        }

        for(Association oldAssociation : oldAssociations)
        {
            try
            {
                unregisterAssociation(oldAssociation);
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }

            for(Object obj : oldAssociation.getActionList())
            {
                //association.addAction((Action)obj);
            }
        }

        association.addAction(action);

        registerAssociation(association);
    }

    private static String trim(String src)
    {
        if(src == null)
            return null;

        src = src.trim();
        int dotIndex = 0;
        int length = src.length();
        while(dotIndex < length && src.charAt(dotIndex) == '.')
            dotIndex++;

        if(dotIndex == 0)
            return src;
        else
            return src.substring(dotIndex);
    }

/*
association.getDescription(): .wse file
association.getFileExtList(): [.wse]
association.getIconFileName(): E:\Documents and Settings\miro\Application Data\Sun\Java\Deployment\cache\6.0\14\1ff7fd0e-1e55ce16.ico
association.getMimeType(): application-x/wse
association.getName(): null
*/

    public static void main(String[] args)
    {
        try
        {
            Association association = getFileExtensionAssociation("wse");
            System.out.println("association: " + association);

            String verb = "open";
            String command = "E:\\Works.NetBeans\\PlanC.biz\\eCSystem\\Protector\\eCSProtector.exe %1 %2 %3 %4 %5 %6 %7 %8 %9 %10";
            String description = "eCryptoSystem Signed and/or Encrypted File";
            Action action = new Action(verb, command, description);

            associateFileExtension("wse", action);

            association = getFileExtensionAssociation("wse");
            System.out.println("New association: " + association);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }

/*        AssociationService associationService = new AssociationService();
        Association ecsAssociation = new Association();
        ecsAssociation.addFileExtension("woo");
        ecsAssociation.addFileExtension("wso");
        ecsAssociation.addFileExtension("wse");
        ecsAssociation.addFileExtension("woe");

        //ecsAssociation.setIconFileName("");
        //ecsAssociation.setMimeType(mimeType);

        ecsAssociation.addAction(action);

        try
        {
           // Adds the .log Association to the file types' table 
           // at the user level using an AssociationService object.
           associationService.registerUserAssociation(ecsAssociation);
           //associationService.registerSystemAssociation(ecsAssociation);
        } 
        catch(IllegalArgumentException ex)
        {
           // This exception will be caught if the given Association is not valid 
           // to be added to the table of file types.
           System.err.println(ex);
        }
        catch(AssociationAlreadyRegisteredException ex)
        {
           // This exception will be caught if the Association already
           // exists in the table of file types.
           System.err.println(ex);
        }
        catch(RegisterFailedException ex)
        {
           // This exception will be caught if the Association was
           // unable to be added to the table of file types.
           System.err.println(ex);
       }


       // getMimeTypeAssociation(String mimeType)
       // getAssociationByContent(URL url)
       ecsAssociation = associationService.getFileExtensionAssociation("woo");
       try
       {
           // The AssociationService will remove the .log file type from 
           // the table of file types.
           associationService.unregisterUserAssociation(ecsAssociation);
           //associationService.unregisterSystemAssociation(ecsAssociation);
       }
       catch(IllegalArgumentException ex)
       {
           // This exception will be caught if the given Association is not valid 
           // to be removed from the table of file types.
           System.err.println(ex);
       }
       catch(AssociationNotRegisteredException ex)
       {
           // This exception will be caught if the Association does not already  
           // exist in the table of file types.
           System.err.println(ex);
       }
       catch(RegisterFailedException ex)
       {
           // This exception will be caughtif the association was unable to be 
           // removed from the table of file types.
           System.err.println(ex);
       }
*/
   }
}