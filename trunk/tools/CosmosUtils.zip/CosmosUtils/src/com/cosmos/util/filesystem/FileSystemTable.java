package com.cosmos.util.filesystem;

import com.cosmos.bean.table.BeanTableModel;
import com.cosmos.form.JBTable;
import java.io.File;
import java.io.FileFilter;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.tree.TreePath;

/**
 *
 * @author miro
 */
public class FileSystemTable
    extends JBTable
{
    private FileFilter fileFilter;

    public FileSystemTable()
    {
        this(false);
    }

    public FileSystemTable(boolean showPathName)
    {
        super();
        setModel(FileBean.getBeanTableModel(showPathName));
    }

    public void parentTreeSelectionChanged(TreeSelectionEvent event)
    {
        TreePath path = event.getPath();
        if(path != null)
        {
            FileSystemTreeNode node = (FileSystemTreeNode)path.getLastPathComponent();
            setParentFolder(node.getFile());
        }
    }

    public void setParentFolder(File parentFolder)
    {
        if(parentFolder != null)
        {
            if(parentFolder.isFile())
                parentFolder = parentFolder.getParentFile();
            File[] children;
            FileFilter fileFilter = getFileFilter();
            if(fileFilter != null)
                children = parentFolder.listFiles(fileFilter);
            else
                children = parentFolder.listFiles();

            int size;
            ArrayList<FileBean> files = null;
            if(children != null && (size = children.length) > 0)
            {
                files = new ArrayList<FileBean>(size);
                for(File child : children)
                {
                    if(!child.isDirectory())
                        files.add(new FileBean(child));
                }
            }

            if(files != null && files.size() > 0)
            {
                setData((Collection)files);
                packAll();
            }
            else
                setData(Collections.EMPTY_LIST);
        }
    }

    public void setFileFilter(FileFilter fileFilter)
    {
        this.fileFilter = fileFilter;
    }

    public FileFilter getFileFilter()
    {
        return fileFilter;
    }

    public void setVisiblePathName(boolean visible)
    {
        BeanTableModel model = (BeanTableModel)getModel();
        if(model != null)
        {
            model.setColumnVisibleByPropertyName("path", visible);
        }
    }

    public void setSelectedFile(File selectedFile)
    {
        JTree tree = getParentTree();
        if(tree != null && tree instanceof FileSystemTree)
        {
            ((FileSystemTree)tree).setSelectedFolder(selectedFile);
            setParentFolder(selectedFile);
            setSelectedRowObject(new FileBean(selectedFile));
        }
        else
            setSelectedRowObject(new FileBean(selectedFile));
    }

}
