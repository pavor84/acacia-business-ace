package com.cosmos.util;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;

/**
 *
 * @author miro
 */
public class ResourceBundleControl
    extends ResourceBundle.Control
{
    private String charsetName;
    private Class invokerClass;

    public ResourceBundleControl()
    {
        this("UTF-8", null);
    }

    public ResourceBundleControl(Class invokerClass)
    {
        this("UTF-8", invokerClass);
    }

    public ResourceBundleControl(String charsetName, Class invokerClass)
    {
        super();
        this.charsetName = charsetName;
        this.invokerClass = invokerClass;
    }

    public List<String> getFormats(String baseName)
    {
        if(baseName == null)
            throw new NullPointerException();
        return Arrays.asList("properties", "xml");
    }

    public Locale getFallbackLocale(String baseName, Locale locale)
    {
        Locale fallBacklocale = super.getFallbackLocale(baseName, locale);
        return fallBacklocale;
    }

    public ResourceBundle newBundle(String baseName,
                                    Locale locale,
                                    String format,
                                    ClassLoader loader,
                                    boolean reload)
        throws IllegalAccessException,
               InstantiationException,
               IOException
    {
        if(baseName == null || locale == null || format == null || loader == null)
            throw new NullPointerException();

        ResourceBundle bundle = null;
        if("properties".equals(format) || "xml".equals(format))
        {
            String bundleName = toBundleName(baseName, locale);
            String resourceName = toResourceName(bundleName, format);

            IOException ioEx = null;
            try
            {
                bundle = newBundle(reload, resourceName, baseName, loader, format);
            }
            catch(IOException ex)
            {
                ioEx = ex;
            }

            if(bundle == null)
            {
                String ext;
                if(!format.startsWith("."))
                    ext = "." + format;
                else
                    ext = format;
                if(!bundleName.endsWith(ext))
                    bundleName = bundleName + ext;
                bundle = newBundle(reload, bundleName, baseName, loader, format);
            }

            if(bundle == null && ioEx != null)
                throw ioEx;
        }

        return bundle;
    }

    private ResourceBundle newBundle(boolean reload,
                                     String resourceName,
                                     String baseName,
                                     ClassLoader loader,
                                     String format)
        throws IOException
    {
        ResourceBundle bundle = null;
        InputStream stream = null;
        if(reload)
        {
            URL url = loader.getResource(resourceName);
            if (url != null)
            {
                URLConnection connection = url.openConnection();
                if (connection != null)
                {
                    // Disable caches to get fresh data for
                    // reloading.
                    connection.setUseCaches(false);
                    stream = connection.getInputStream();
                }
            }
        }
        else
        {
            stream = loader.getResourceAsStream(resourceName);
            if(stream == null)
            {
                if(invokerClass != null)
                    stream = SystemUtils.getResourceAsStream(invokerClass, resourceName);
                else
                    stream = SystemUtils.getResourceAsStream(resourceName);
            }
        }

        if (stream != null)
        {
            if("properties".equals(format))
            {
                InputStreamReader isr = new InputStreamReader(stream, charsetName);
                bundle = new SmartResourceBundle(isr, baseName, resourceName);
                isr.close();
            }
            else
                if("xml".equals(format))
                {
                    BufferedInputStream bis = new BufferedInputStream(stream);
                    bundle = new XMLResourceBundle(bis);
                    bis.close();
                }
        }

        return bundle;
    }

    private static class XMLResourceBundle
        extends ResourceBundle
    {
        private Properties props;

        XMLResourceBundle(InputStream stream)
            throws IOException
        {
            props = new Properties();
            props.loadFromXML(stream);
        }

        protected Object handleGetObject(String key)
        {
            return props.getProperty(key);
        }

        public Enumeration<String> getKeys()
        {
            return null;
        }
    }
}
