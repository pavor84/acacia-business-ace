package com.cosmos.util.filesystem;

import javax.swing.tree.DefaultTreeCellRenderer;
import java.awt.Component;
import javax.swing.JTree;
import java.io.File;
import javax.swing.Icon;


/**
 * <p>Title: FileSystemTree</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: COSMOS Software Enterprises, Ltd.</p>
 *
 * @author Miroslav Nachev
 * @version 1.0
 */
public class FileSystemTreeRenderer
    extends DefaultTreeCellRenderer
{

    public Component getTreeCellRendererComponent(
            JTree tree,
            Object value,
            boolean isSelected,
            boolean isExpanded,
            boolean leaf,
            int row,
            boolean hasFocus)
    {
        Component component = super.getTreeCellRendererComponent(
                tree, value, isSelected, isExpanded, leaf, row, hasFocus);

        if(value != null && value instanceof FileSystemTreeNode)
        {
            FileSystemTreeNode treeNode = (FileSystemTreeNode)value;
            // ===
            // For Windows "My Computer" node only.
            // ===
            File selectedDir = (File)treeNode.getUserObject();

            Icon icon = treeNode.getSystemIcon();
            if(icon != null)
            {
                setIcon(icon);
            }
/*
            if (selectedDir.equals(new File(FileExplorer.MY_COMPUTER_FOLDER_PATH))) {
                setIcon(FileExplorer.computerIcon);
            } else if (selectedDir.getParent() == null) {
                setIcon(FileExplorer.driverIcon);
            } else {
                setIcon(FileExplorer.folderIcon);
            }
 */

            return component;
        }

        return this;
    }
}
