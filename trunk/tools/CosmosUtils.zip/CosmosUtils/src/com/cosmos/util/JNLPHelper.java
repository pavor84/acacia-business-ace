package com.cosmos.util;

import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.ShortcutDesc;
import com.sun.jnlp.JNLPClassLoader;

import com.sun.deploy.config.Config;
import java.net.URL;

/**
 *
 * @author miro
 */
public class JNLPHelper
{
    private static JNLPHelper jnlpHelper;

    private JNLPClassLoader jnlpClassLoader;
    private Config config;
    
    private JNLPHelper()
    {
        jnlpClassLoader = JNLPClassLoader.getInstance();
        config = Config.getInstance();
    }

    public static JNLPHelper getInstance()
    {
        if(jnlpHelper == null)
        {
            jnlpHelper = new JNLPHelper();
        }

        return jnlpHelper;
    }

    public JNLPClassLoader getJNLPClassLoader()
    {
        return jnlpClassLoader;
    }

    public String getSubmenu()
    {
        if(jnlpClassLoader != null)
        {
            ShortcutDesc shortcut;
            shortcut = jnlpClassLoader.getLaunchDesc().getInformation().getShortcut();
            if(shortcut.getMenu())
                return shortcut.getSubmenu();
        }

        return null;
    }

    public URL getLocation()
    {
        if(jnlpClassLoader != null)
        {
            LaunchDesc ld = jnlpClassLoader.getLaunchDesc();
            return ld.getLocation();
        }

        return null;
    }

    private void printLaunchDesc(LaunchDesc ld)
    {
        System.out.println("jnlpClassLoader.getLaunchDesc(): " + ld);
        System.out.println("ld.getAppInfo(): " + ld.getAppInfo());
        System.out.println("ld.getApplicationDescriptor(): " + ld.getApplicationDescriptor());
        System.out.println("ld.getCanonicalHome(): " + ld.getCanonicalHome());
        System.out.println("ld.getCodebase(): " + ld.getCodebase());
        System.out.println("ld.getInformation(): " + ld.getInformation());
        System.out.println("ld.getInstallerDescriptor(): " + ld.getInstallerDescriptor());
        System.out.println("ld.getInternalCommand(): " + ld.getInternalCommand());
        System.out.println("ld.getLocation(): " + ld.getLocation());
        System.out.println("ld.getResources(): " + ld.getResources());
        System.out.println("ld.getSource(): " + ld.getSource());
        System.out.println("ld.getSpecVersion(): " + ld.getSpecVersion());
        System.out.println("ld.getSplashCanonicalHome(): " + ld.getSplashCanonicalHome());
        System.out.println("ld.getUpdate(): " + ld.getUpdate());
    }

    public Config getConfig()
    {
        return config;
    }

    public void enableCreateUninstallShortcut(boolean enable)
    {
        Config config = getConfig();
        config.setProperty("deployment.javaws.uninstall.shortcut", Boolean.toString(enable));
    }
}
