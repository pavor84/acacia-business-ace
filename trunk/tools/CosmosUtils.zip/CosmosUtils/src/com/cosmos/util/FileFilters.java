package com.cosmos.util;

import java.io.File;
import java.util.Collections;
import java.util.TreeSet;

import com.cosmos.util.SystemUtils;


public class FileFilters
{
    public static java.io.FileFilter getIOFileFilter(FileExtension fileExts)
    {
        return new IOFileFilter(fileExts);
    }

    public static javax.swing.filechooser.FileFilter getSwingFileFilter(FileExtension fileExts)
    {
        return new SwingFileFilter(fileExts);
    }

    private static class IOFileFilter
        extends SwingFileFilter
        implements java.io.FileFilter
    {
        private IOFileFilter(FileExtension fileExtension)
        {
            super(fileExtension);
        }
    }

    private static class SwingFileFilter
        extends javax.swing.filechooser.FileFilter
    {
        protected Class fileExtensionClass;
        protected FileExtension fileExtension;
        protected TreeSet<FileExtension> fileExtensions;

        private SwingFileFilter(FileExtension fileExtension)
        {
            this.fileExtension = fileExtension;
            fileExtensionClass = fileExtension.getClass();
            String ext = fileExtension.getExtension();
            if(ext != null)
                fileExtensions = new TreeSet<FileExtension>(Collections.<FileExtension>singleton(fileExtension));
            else
                fileExtensions = new TreeSet<FileExtension>(fileExtension.getExtensions());
        }

        public boolean accept(File pathName)
        {
            if(pathName.isDirectory())
                return true;

            if(!pathName.isFile())
                return false;

            String fileName = pathName.getName();

            String extStr = SystemUtils.getFileExtension(fileName);
            if(extStr == null)
                return false;

            FileExtension ext = DefaultFileExtension.getFileExtensionById(fileExtensionClass, extStr);
            if(ext == null)
                return false;
            return fileExtensions.contains(ext);
        }

        public String getDescription()
        {
            return fileExtension.getFileFilterName();
        }
    }
}
