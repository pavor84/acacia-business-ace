package com.cosmos.util;

import com.cosmos.form.ErrorPanel;
import java.awt.Component;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.util.ResourceBundle;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author miro
 */
public class DialogHelper
{
    public static final ResponseType[] OK_RESPONSE = {ResponseType.OK};
    public static final ResponseType[] YES_NO_RESPONSE = {ResponseType.YES, ResponseType.NO};
    public static final ResponseType[] YES_NO_CANCEL_RESPONSE = {ResponseType.YES, ResponseType.NO, ResponseType.CANCEL};
    public static final ResponseType[] OK_CANCEL_RESPONSE = {ResponseType.OK, ResponseType.CANCEL};
    public static final ResponseType[] CLOSE_RESPONSE = {ResponseType.CLOSE};

    public static ResponseType showWarningDialog(Component parentComponent,
                                                 Object message)
    {
        return showWarningDialog(parentComponent, message, null);
    }

    public static ResponseType showWarningDialog(Component parentComponent,
                                                 Object message,
                                                 String title)
    {
        if(title == null)
        {
            title = UIResourceManager.getResourceString("form.WarningDialog.Title.Text", "Warning");
        }

        return showDialog(parentComponent,
                          message,
                          title,
                          JOptionPane.WARNING_MESSAGE,
                          OK_RESPONSE,
                          null);
    }

    public static ResponseType showInformationDialog(Component parentComponent,
                                                     Object message)
    {
        return showInformationDialog(parentComponent, message, null);
    }

    public static ResponseType showInformationDialog(Component parentComponent,
                                                     Object message,
                                                     String title)
    {
        if(title == null)
        {
            title = UIResourceManager.getResourceString("form.InformationDialog.Title.Text", "Info");
        }

        return showDialog(parentComponent,
                          message,
                          title,
                          JOptionPane.INFORMATION_MESSAGE,
                          OK_RESPONSE,
                          null);
    }

    public static ResponseType showConfirmationDialog(Component parentComponent,
                                                      Object message)
    {
        return showConfirmationDialog(parentComponent, message, null);
    }

    public static ResponseType showConfirmationDialog(Component parentComponent,
                                                      Object message,
                                                      String title)
    {
        if(title == null)
        {
            title = UIResourceManager.getResourceString("form.ConfirmationDialog.Title.Text", "Confirmation");
        }

        return showDialog(parentComponent,
                          message,
                          title,
                          JOptionPane.QUESTION_MESSAGE,
                          YES_NO_RESPONSE,
                          null);
    }



    public static ResponseType showDialog(Component parentComponent,
                                          Object message,
                                          String title,
                                          int messageType,
                                          ResponseType[] responses,
                                          Object initialValue)
	{
        DialogPane pane = new DialogPane(
                message,
                messageType,
                null,
                responses,
                initialValue);

        JDialog dialog = pane.createDialog(parentComponent, title);

        try
        {
            ResourceBundle rb = ResourceBundleManager.getResourceBundle();
            if(rb != null)
            {
                ImageIcon icon = (ImageIcon)rb.getObject("icon.SystemLogo.Small");
                if(icon != null)
                {
                    dialog.setIconImage(icon.getImage());
                }
            }
        }
        catch(Exception ex) {}

        dialog.pack();
        dialog.setVisible(true);
        dialog.dispose();
        Object response = pane.getValue();
        if(response == null || !(response instanceof ResponseType))
        {
            return ResponseType.CLOSE;
        }

        return (ResponseType)response;
    }

    public static ResponseType showError(Component parent, Throwable ex)
    {
        return showError(parent, ex, null);
    }

    public static ResponseType showError(Component parent, Throwable ex, String title)
    {
        if(title == null)
        {
            title = UIResourceManager.getResourceString("form.ErrorDialog.Title.Text", "Error");
        }
        ErrorPanel errorPanel = new ErrorPanel();
        errorPanel.setError(ex);
        return showDialog(parent,
                          errorPanel,
                          title,
                          JOptionPane.ERROR_MESSAGE,
                          DialogHelper.OK_RESPONSE,
                          null);
    }

    public static ResponseType showError(Component parent, String messageText)
    {
        return showError(parent, messageText, null);
    }

    public static ResponseType showError(Component parent, String messageText, String title)
    {
        if(title == null)
        {
            title = UIResourceManager.getResourceString("form.ErrorDialog.Title.Text", "Error");
        }
        JLabel messageLabel = new JLabel(SystemUtils.getStringAsHTML(messageText));
        return showDialog(parent,
                          messageLabel,
                          title,
                          JOptionPane.ERROR_MESSAGE,
                          DialogHelper.OK_RESPONSE,
                          null);
    }

    private static class DialogPane
        extends JOptionPane
    {
        private JDialog dialog;

        public DialogPane(Object message,
                          int messageType,
                          Icon icon,
                          ResponseType[] responses,
                          Object initialValue)
        {
            super(message, messageType, JOptionPane.CANCEL_OPTION, icon);

            ResourceBundle rb = null;
            try
            {
                rb = ResourceBundleManager.getResourceBundle();
            }
            catch(Exception ex) {}

            int size = responses.length;
            JButton[] buttons = new JButton[size];
            for(int i = 0; i < size; i++)
            {
                ResponseType response = responses[i];
                JButton button = new JButton(new PropertyAction(response, rb)
                {
                    public void actionPerformed(ActionEvent event)
                    {
                        Object selectedValue = getValue(RESOURCE_RESPONSE_TYPE);
                        setValue(selectedValue);
                        dialog.setVisible(false);
                    }
                });
                buttons[i] = button;
            }

            setOptions(buttons);

            if(initialValue != null)
            {
                setInitialValue(initialValue);
            }
        }

        public JDialog createDialog(Component parentComponent, String title)
            throws HeadlessException
        {
            dialog = super.createDialog(parentComponent, title);
            return dialog;
        }

        public JDialog createDialog(String title)
            throws HeadlessException
        {
            dialog = super.createDialog(title);
            return dialog;
        }

    }

    public static void main(String[] args)
    {
//        LoginForm.init();
        ResponseType response;
//        response = showInformationDialog(null, "Some Information.", "My Title");
//        System.out.println("response: " + response);
        
        response = showConfirmationDialog(null, "Confirm the Information.", "My Title");
        System.out.println("response: " + response);
    }

}
