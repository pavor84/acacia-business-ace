package com.cosmos.util;

import java.awt.event.KeyEvent;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

/**
 *
 * @author miro
 */
public abstract class PropertyAction
    extends AbstractAction
{
    public static final String RESOURCE_ACTION_NAME = "PropertyAction.ResourceActionName";
    public static final String RESOURCE_RESPONSE_TYPE = "PropertyAction.ResponseType";

    public PropertyAction(String actionName)
    {
        this(actionName, ResourceBundleManager.getResourceBundle());
    }

    public PropertyAction(ResponseType response)
    {
        this(response, ResourceBundleManager.getResourceBundle());
    }

    public PropertyAction(ResponseType response, ResourceBundle resourceBundle)
    {
        this(response.getActionName(), resourceBundle);
        putValue(RESOURCE_RESPONSE_TYPE, response);
    }

    public PropertyAction(String actionName, ResourceBundle resourceBundle)
    {
        if(resourceBundle == null)
        {
            putValue(RESOURCE_ACTION_NAME, actionName);
            putValue(Action.NAME, actionName);
            putValue(Action.ACTION_COMMAND_KEY, actionName);
            return;
        }

        ActionProperties ap = new ActionProperties(actionName, resourceBundle);

        putValue(RESOURCE_ACTION_NAME, actionName);

        Object value = ap.getName();
        if(value == null)
            value = actionName;

        putValue(Action.NAME, value);

        value = ap.getShortDescription();
        if(value != null)
            putValue(Action.SHORT_DESCRIPTION, value);

        value = ap.getLongDescription();
        if(value != null)
            putValue(Action.LONG_DESCRIPTION, value);

        value = ap.getActionCommandKey();
        if(value != null)
            putValue(Action.ACTION_COMMAND_KEY, value);
        else
            putValue(Action.ACTION_COMMAND_KEY, actionName);

        value = ap.getAcceleratorKey();
        if(value != null)
            putValue(Action.ACCELERATOR_KEY, value);

        value = ap.getMnemonicKey();
        if(value != null)
            putValue(Action.MNEMONIC_KEY, value);

        value = ap.getDisplayedMnemonicIndex();
        if(value != null)
            putValue(Action.DISPLAYED_MNEMONIC_INDEX_KEY, value);

        value = ap.getSmallIcon();
        if(value != null)
            putValue(Action.SMALL_ICON, value);

        value = ap.getLargeIcon();
        if(value != null)
            putValue(Action.LARGE_ICON_KEY, value);

        value = ap.isSelectedKey();
        if(value != null)
            putValue(Action.SELECTED_KEY, value);

        setEnabled(ap.isEnabled());
    }


    private static int getKeyEventValue(String keyEvent)
    {
        try
        {
            if(keyEvent != null && (keyEvent = keyEvent.trim()).length() > 0)
            {
                Object object = BeanUtil.getStaticFieldValue(keyEventClass, keyEvent, "VK_");
                if(object != null)
                    return ((Integer)object).intValue();
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }

        return 0;
    }


    private static final Class keyEventClass = KeyEvent.class;

    protected class ActionProperties
    {
        private String actionName;
        private String propertyActionName;
        private ResourceBundle resourceBundle;

        public ActionProperties(String actionName, ResourceBundle resourceBundle)
        {
            this.actionName = actionName;
            this.propertyActionName = "action." + actionName + ".";
            this.resourceBundle = resourceBundle;
        }

        private String getPropertyName(String key)
        {
            return propertyActionName + key;
        }

        public String getName()
        {
            try
            {
                return resourceBundle.getString(getPropertyName(Action.NAME));
            }
            catch(MissingResourceException ex)
            {
                return actionName;
            }
        }

        public String getShortDescription()
        {
            try
            {
                return resourceBundle.getString(getPropertyName(Action.SHORT_DESCRIPTION));
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        public String getLongDescription()
        {
            try
            {
                return resourceBundle.getString(getPropertyName(Action.LONG_DESCRIPTION));
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        public String getActionCommandKey()
        {
            try
            {
                return resourceBundle.getString(getPropertyName(Action.ACTION_COMMAND_KEY));
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        public KeyStroke getAcceleratorKey()
        {
            try
            {
                String value = resourceBundle.getString(getPropertyName(Action.ACCELERATOR_KEY));
                if(value != null)
                {
                        return KeyStroke.getKeyStroke(value);
                }
            }
            catch(Exception ex) {}
            return null;
        }

        public Integer getMnemonicKey()
        {
            try
            {
                String value = resourceBundle.getString(getPropertyName(Action.MNEMONIC_KEY));
                if(value != null)
                {
                    return getKeyEventValue(value);
                }
            }
            catch(Exception ex) {}
            return null;
        }

        public Integer getDisplayedMnemonicIndex()
        {
            try
            {
                String value = resourceBundle.getString(getPropertyName(Action.DISPLAYED_MNEMONIC_INDEX_KEY));
                if(value != null)
                {
                    return Integer.parseInt(value);
                }
            }
            catch(Exception ex) {}
            return null;
        }
/*
        protected Icon getIcon(String iconName)
        {
            if(iconName != null)
            {
                try
                {
                    InputStream inStream = SystemUtils.getResourceAsStream(iconName);
                    if(inStream != null)
                    {
                        return new ImageIcon(SystemUtils.toByteArray(inStream));
                    }
                }
                catch(Exception ex)
                {
                    ex.printStackTrace();
                }
            }
            return null;
        }
*/
        public ImageIcon getSmallIcon()
        {
            try
            {
                return (ImageIcon)resourceBundle.getObject(getPropertyName(Action.SMALL_ICON));
            }
            catch(Exception ex) {}
            return null;
        }

        public ImageIcon getLargeIcon()
        {
            try
            {
                return (ImageIcon)resourceBundle.getObject(getPropertyName(Action.LARGE_ICON_KEY));
            }
            catch(Exception ex) {}

            return null;
        }

        public Boolean isSelectedKey()
        {
            try
            {
                String value = resourceBundle.getString(getPropertyName(Action.SELECTED_KEY));
                if(value != null)
                {
                    return Boolean.valueOf(value);
                }
            }
            catch(Exception ex) {}
            return null;
        }

        public boolean isEnabled()
        {
            try
            {
                String value = resourceBundle.getString(getPropertyName("Enabled"));
                if(value != null)
                {
                    return Boolean.parseBoolean(value);
                }
            }
            catch(Exception ex) {}
            return true;
        }
    }

}
