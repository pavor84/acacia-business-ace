package com.cosmos.util;

/**
 *
 * @author miro
 */
public enum OperatingSystem
{
    WINDOWS, LINUX, SOLARIS, UNKNOWN_OS;
}
