package com.cosmos.util;

import com.cosmos.util.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.GZIPInputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PipedOutputStream;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class GZIPDecoder
	extends BaseUtilClass
{
	private InputStream inData;
	private OutputStream outData;

	public GZIPDecoder(InputStream inData, OutputStream outData)
	{
		this.inData = inData;
		this.outData = outData;
	}

	public void decompress()
		throws IOException
	{
		GZIPInputStream in = new GZIPInputStream(inData);

		byte[] buf = new byte[1024];
		int len;
		while((len = in.read(buf)) >= 0)
		{
			outData.write(buf, 0, len);
			Thread.currentThread().yield();
		}
		outData.flush();
		outData.close();
	}

	static public class GZIPDecoderThread
		extends BaseUtilClass
		implements Runnable
	{
		private GZIPDecoder gzip;
		private Throwable throwable = null;
		private boolean isWorking = false;
		private boolean waitClause = false;

		public GZIPDecoderThread(InputStream inData,
								 OutputStream outData)
		{
			gzip = new GZIPDecoder(inData, outData);
		}

		public void run()
		{
			try
			{
				isWorking = true;
				gzip.decompress();
				while(waitClause)
					Thread.currentThread().yield();
			}
			catch(Throwable ex)
			{
				throwable = ex;
				Logger errorLogger = getLoggerHelper().getErrorLogger();
				if(errorLogger != null)
					errorLogger.logp(Level.SEVERE, this.getClass().getName(), "run()", "waitClause = " + waitClause, ex);
			}
			finally
			{
				isWorking = false;
			}
		}

		public Throwable getThrowable()
		{
			return throwable;
		}

		public boolean isWorking()
		{
			return isWorking;
		}

		public void setWaitClause(boolean flag)
		{
			waitClause = flag;
		}

		public boolean getWaitClause()
		{
			return waitClause;
		}
	}

    public static void decompressBase64(InputStream compressedBase64Data, OutputStream pureData)
        throws IOException,
        Base64DecoderException
    {
        try
        {
            ByteArrayOutputStream compressedOutData = new ByteArrayOutputStream();
            Base64Decoder base64 = new Base64Decoder(compressedBase64Data, compressedOutData);
            base64.decode();
            compressedBase64Data.close();
            compressedBase64Data = null;
            compressedOutData.flush();
            ByteArrayInputStream compressedInData = new ByteArrayInputStream(compressedOutData.toByteArray());
            compressedOutData.close();
            compressedOutData = null;
            GZIPDecoder gzip = new GZIPDecoder(compressedInData, pureData);
            gzip.decompress();
            compressedInData.close();
            compressedInData = null;
            pureData.flush();
            pureData = null;
            System.gc();
        }
        catch(Base64FormatException ex)
        {
            throw new Base64DecoderException(ex);
        }
    }

	public static void decompressBase64_Pipe(InputStream compressedBase64Data, OutputStream pureData)
		throws IOException,
		Base64DecoderException
	{
		PipedOutputStream compressedOutData = new PipedOutputStream();
		PipedInputStream compressedInData = new PipedInputStream(compressedOutData);
		Base64Decoder.Base64DecoderThread base64 = new Base64Decoder.Base64DecoderThread(
			compressedBase64Data, compressedOutData);
		base64.setWaitClause(true);
		GZIPDecoder gzip = new GZIPDecoder(compressedInData, pureData);
		Thread thread = new Thread(base64);
		thread.start();
		gzip.decompress();
		base64.setWaitClause(false);
		Throwable throwable = base64.getThrowable();
		thread = null;
		base64 = null;
		if(throwable != null)
			throw new Base64DecoderException(throwable);
	}
}
