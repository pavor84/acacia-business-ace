package com.cosmos.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import javax.swing.ImageIcon;

/**
 *
 * @author miro
 */
public class SmartResourceBundle
    extends PropertyResourceBundle
{
    private ArrayList<Locale> installedLocales = new ArrayList<Locale>();
    private String baseName;
    private String resourceName;
    private SmartResourceBundle parent;
    private File localFolder;

    public SmartResourceBundle(InputStream stream, String baseName, String resourceName)
        throws IOException
    {
        super(stream);
        this.baseName = baseName;
        this.resourceName = resourceName;
    }

    public SmartResourceBundle(Reader reader, String baseName, String resourceName)
        throws IOException
    {
        super(reader);
        this.baseName = baseName;
        this.resourceName = resourceName;
    }    

    public Object handleGetObject(String key)
    {
        if(key == null)
        {
            throw new NullPointerException();
        }

        key = key.trim();
        if(lookup.containsKey(key))
        {
            return lookup.get(key);
        }

        Object value = super.handleGetObject(key);
        if(value != null && value instanceof String)
        {
            if(isIconKey(key))
            {
                ImageIcon icon = getIcon((String)value);
                if(icon != null)
                {
                    lookup.put(key, icon);
                    value = icon;
                }
            }
        }

        return value;
    }

    protected boolean isIconKey(String key)
    {
        if(key.startsWith("icon."))
            return true;
        if(key.startsWith("action.") && (key.endsWith(".SmallIcon") || key.endsWith(".SwingLargeIconKey")))
            return true;

        return false;
    }

    protected ImageIcon getIcon(String iconName)
    {
        if(iconName != null && (iconName = iconName.trim()).length() > 0)
        {
            try
            {
                InputStream inStream = null;
                File localFolder = getLocalFolder();
                if(localFolder != null)
                {
                    File file = new File(localFolder, iconName);
                    if(file.exists())
                        inStream = SystemUtils.getResourceAsStream(file.getAbsolutePath());
                }

                if(inStream == null)
                    inStream = SystemUtils.getResourceAsStream(iconName);

                if(inStream != null)
                {
                    return new SmartImageIcon(SystemUtils.toByteArray(inStream), iconName);
                }
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
        }

        return null;
    }

    protected File getLocalFolder()
    {
        if(localFolder == null)
        {
            String localFolderName = System.getProperty(ResourceBundleManager.RESOURCE_BUNDLE_LOCAL_FOLDER);
            if(localFolderName != null)
            {
                localFolder = new File(localFolderName);
                if(!localFolder.exists())
                {
                    localFolder = null;
                }
            }
        }
        return localFolder;
    }

    private Map<String,Object> lookup = new HashMap<String,Object>();

    private class SmartImageIcon
        extends ImageIcon
    {
        private String propertyStringValue;

        public SmartImageIcon(byte[] byteArray, String propertyStringValue)
        {
            super(byteArray);
            this.propertyStringValue = propertyStringValue;
        }

        public String toString()
        {
            return propertyStringValue;
        }
    }

    public void setParentResourceBundle(SmartResourceBundle parent)
    {
        setParent(parent);
    }

    public SmartResourceBundle getParentResourceBundle()
    {
        return parent;
    }

    protected void setParent(ResourceBundle parent)
    {
        this.parent = (SmartResourceBundle)parent;
        Locale locale;
        if(installedLocales.isEmpty())
        {
            locale = getLocale();
            if(locale == null || Locale.ROOT.equals(locale))
            {
                locale = Locale.ENGLISH;
            }
            installedLocales.add(locale);
        }

        if(parent != null)
        {
            locale = parent.getLocale();
            if(locale == null || Locale.ROOT.equals(locale))
            {
                locale = Locale.ENGLISH;
            }
            if(!installedLocales.contains(locale))
            {
                installedLocales.add(locale);
            }
        }

        super.setParent(parent);
    }

    public List<Locale> getInstalledLocales()
    {
        return installedLocales;
    }

    public String getBaseName()
    {
        return baseName;
    }

    public String getResourceName()
    {
        return resourceName;
    }

}

