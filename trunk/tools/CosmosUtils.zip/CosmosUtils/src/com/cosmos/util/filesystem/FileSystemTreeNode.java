package com.cosmos.util.filesystem;

import com.cosmos.util.SystemUtils;
import java.io.File;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Vector;
import javax.swing.Icon;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileSystemView;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;


/**
 * <p>Title: FileSystemTree</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: COSMOS Software Enterprises, Ltd.</p>
 *
 * @author Miroslav Nachev
 * @version 1.0
 */
public class FileSystemTreeNode
    extends DefaultMutableTreeNode
{
    protected static final FileSystemView fileSystemView = FileSystemView.getFileSystemView();

    public FileSystemTreeNode()
    {
        File[] roots = fileSystemView.getRoots();
        if(roots != null && roots.length > 0)
        {
            setUserObject(roots[0]);
        }
    }

    public FileSystemTreeNode(File file)
    {
        setUserObject(file);
    }

    private static String osName = SystemUtils.getOSName().toLowerCase();
    private boolean childrenAreLoaded = false;
	private FileSystemTreeModel treeModel;
	private boolean fileAccessError = false;

    private void errorDisplayingPermission()
    {
		fileAccessError = true;
        JOptionPane.showMessageDialog(null,
                "You do not have the permissions necessary to view the contents of \""
                + getFile() + "\"", "Error Displaying Folder",
                JOptionPane.ERROR_MESSAGE);

		TreePath path = new TreePath(getRoot());
		FileSystemTree tree = getFileSystemTree();
		tree.setSelectionPath(path);

		path = new TreePath(getPath());
		if(tree.isExpanded(path))
		{
			tree.collapsePath(path);
		}
    }

    private void errorDisplayingNoDisk()
    {
		fileAccessError = true;
        File file = getFile();
        String fileName = file.getName();
        String errorMsg = "The file : " + fileName + " does not exist any longer!";

        if (osName.startsWith("windows") && (fileSystemView.isFloppyDrive(file) || fileSystemView.isDrive(file)))
        {
			errorMsg = "Please insert disk into driver:  " + file;
        }

        JOptionPane.showMessageDialog(
            null,
            errorMsg,
            "Error Displaying Folder",
            JOptionPane.ERROR_MESSAGE);

		TreePath path = new TreePath(getRoot());
		FileSystemTree tree = getFileSystemTree();
		tree.setSelectionPath(path);

		path = new TreePath(getPath());
		if(tree.isExpanded(path))
		{
			tree.collapsePath(path);
		}
    }

    public boolean getAllowsChildren()
    {
		return isDirectory();
    }

    public boolean isLeaf()
    {
		return !isDirectory();
    }

    public File getFile()
    {
        return (File)getUserObject();
    }

    public boolean isChildrenAreLoaded()
    {
        return childrenAreLoaded;
    }

    public boolean isDirectory()
    {
        File file = getFile();

        return file.isDirectory();
    }

	protected boolean fileExists()
	{
		try
		{
			return getFile().exists();
		}
		catch(Throwable ex)
		{
			return false;
		}
	}

	protected boolean canReadFile()
	{
		try
		{
			return getFile().canRead();
		}
		catch(Throwable ex)
		{
			return false;
		}
	}

    public void loadChildren()
    {
        File file = getFile();

        if(!isDirectory())
        {
            return;
        }

		if(!fileExists())
		{
			errorDisplayingNoDisk();
			return;
		}

		if(!canReadFile())
		{
			errorDisplayingPermission();
			return;
		}

        if(!isChildrenAreLoaded())
        {
            File[] children = file.listFiles();

            if(children != null)
            {
                for(int i = 0; i < children.length; ++i)
                {
                    if(children[i].isDirectory())
                    {
                        FileSystemTreeNode treeNode = new FileSystemTreeNode(children[i]);
                        add(treeNode);
                    }
                }
            }

            childrenAreLoaded = true;
        }
    }

    public String toString()
    {
        return fileSystemView.getSystemDisplayName(getFile());
    }

	private int getChildrenCount()
    {
		if(fileAccessError)
			return 0;

        File file = getFile();

		if(!fileExists())
		{
			errorDisplayingNoDisk();
			return 0;
		}

		if(!canReadFile())
		{
			errorDisplayingPermission();
			return 0;
		}

        if(!isDirectory())
        {
            return 0;
        }
        else
        {
            File[] children = file.listFiles();
			int childrenCount = 0;
			if(children != null)
			{
				for(File child : children)
				{
					if(child.isDirectory())
						childrenCount++;
				}
			}

            return childrenCount;
        }
    }

    public Icon getSystemIcon()
    {
        return fileSystemView.getSystemIcon(getFile());
    }

    public String getSystemTypeDescription()
    {
        return fileSystemView.getSystemTypeDescription(getFile());
    }

	public TreeNode getChildAt(int childIndex)
	{
		if(!isChildrenAreLoaded())
		{
			loadChildren();
		}
		try
		{
			return super.getChildAt(childIndex);
		}
		catch(ArrayIndexOutOfBoundsException ex)
		{
			ex.printStackTrace();
			reloadChildren();
			return super.getChildAt(childIndex);
		}
	}

	public Enumeration children()
	{
		if(!isChildrenAreLoaded())
		{
			isChildrenAreLoaded();
		}

		return super.children();
	}

	protected void reloadChildren()
	{
		removeAllChildren();
		childrenAreLoaded = false;
		isChildrenAreLoaded();
		treeModel.nodeStructureChanged(this);
	}

	public int getChildCount()
	{
		int childCount = super.getChildCount();
		int childrenCount = getChildrenCount();
		if(childCount > 0 && childCount != childrenCount && treeModel != null)
		{
			reloadChildren();
		}
		return childrenCount;
	}

	public void add(MutableTreeNode newChild)
	{
		if(!allowsChildren)
		{
			throw new IllegalStateException("node does not allow children");
		}
		else
			if(newChild == null)
			{
				throw new IllegalArgumentException("new child is null");
			}
			else
				if(isNodeAncestor(newChild))
				{
					throw new IllegalArgumentException("new child is an ancestor");
				}


		MutableTreeNode oldParent = (MutableTreeNode)newChild.getParent();

		if(oldParent != null)
		{
			oldParent.remove(newChild);
		}
		newChild.setParent(this);
		if(children == null)
		{
			children = new Vector();
		}
		children.add(newChild);
	}

	public void setTreeModel(FileSystemTreeModel treeModel)
	{
		this.treeModel = treeModel;
	}

	public DefaultTreeModel getTreeModel()
	{
		return treeModel;
	}

	protected TreePath findChildTreePath(TreePath parentPath, File file)
	{
		if(parentPath != null && file != null)
		{
			FileSystemTreeNode node = (FileSystemTreeNode)parentPath.getLastPathComponent();
			int childCount = node.getChildCount();
			for(int i = 0; i < childCount; i++)
			{
				FileSystemTreeNode child = (FileSystemTreeNode)node.getChildAt(i);
				if(child.getUserObject().equals(file))
				{
					return parentPath.pathByAddingChild(child);
				}
			}
		}

		return null;
	}

	protected File[] getFileTreeForPath(String filePathName)
	{
		LinkedList<File> list = new LinkedList<File>();
		File file = fileSystemView.createFileObject(filePathName);
		while(file != null && !file.isDirectory())
		{
			file = file.getParentFile();
		}

		while(file != null)
		{
			list.add(file);
			file = fileSystemView.getParentDirectory(file);
		}

		File[] fileTree = new File[list.size()];
		Iterator<File> iter = list.descendingIterator();
		int pos = 0;
		while(iter.hasNext())
		{
			fileTree[pos++] = iter.next();
		}

		return fileTree;
	}

    public TreePath getFileTreePath(String filePathName)
    {
        filePathName = SystemUtils.trimFileName(filePathName);

        TreePath path = null;
        File[] fileTree = getFileTreeForPath(filePathName);
        if(fileTree != null && fileTree.length > 0)
        {
            FileSystemTreeNode rootTreeNode = (FileSystemTreeNode)getRoot();
            if(rootTreeNode.getUserObject().equals(fileTree[0]))
            {
                path = new TreePath(rootTreeNode);
                for(int i = 1; i < fileTree.length; i++)
                {
                    path = findChildTreePath(path, fileTree[i]);
                    if(path == null)
                    {
                        break;
                    }
                }
            }
        }

        return path;
    }

	public FileSystemTree getFileSystemTree()
	{
		FileSystemTreeNode root = (FileSystemTreeNode)getRoot();
		FileSystemTreeModel model = (FileSystemTreeModel)(root.getTreeModel());
		return model.getFileSystemTree();
	}
}
