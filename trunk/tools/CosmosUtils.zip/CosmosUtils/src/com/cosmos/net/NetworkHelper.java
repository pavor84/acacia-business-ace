package com.cosmos.net;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.net.SocketFactory;
import javax.net.ssl.SSLSocketFactory;

/**
 *
 * @author miro
 */
public class NetworkHelper
{
    private static final int CONNECTION_TIMEOUT = 500;

    public static boolean isReachable(InetAddress inetAddr, int port, boolean secure)
        throws IOException
    {
        boolean reachable = false;
        reachable = inetAddr.isReachable(CONNECTION_TIMEOUT);

        if(!reachable)
        {
            Socket socket = null;
            try
            {
                if(secure)
                {
                    SocketFactory sf = SSLSocketFactory.getDefault();
                    socket = sf.createSocket(inetAddr, port);
                    sf = null;
                }
                else
                {
                    InetSocketAddress inetSocket = new InetSocketAddress(inetAddr, port);
                    socket = new Socket();
                    socket.setSoTimeout(CONNECTION_TIMEOUT);
                    socket.connect(inetSocket);
                    inetSocket = null;
                }

                if(socket != null)
                    reachable = socket.isConnected();
            }
            finally
            {
                if(socket != null)
                {
                    socket.close();
                    socket = null;
                }
            }
        }

        return reachable;
    }

/*
line: 
line: 
line: Pinging ghs.l.google.com [72.14.207.121] with 32 bytes of data:
line: 
line: 
line: 
line: Reply from 72.14.207.121: bytes=32 time=139ms TTL=237
line: 
line: 
line: 
line: Ping statistics for 72.14.207.121:
line: 
line:     Packets: Sent = 1, Received = 1, Lost = 0 (0% loss),
line: 
line: Approximate round trip times in milli-seconds:
line: 
line:     Minimum = 139ms, Maximum = 139ms, Average = 139ms
line: 
ping1: dostepny
*/
    public int ping(String addr)
    {
        try
        {
            BufferedReader in = null;
            Runtime rtime = Runtime.getRuntime();
            Process s = rtime.exec("ping -n 1" + " " + addr);
            in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            String line, ping1;
            ping1="dostepny";
            while ((line = in.readLine()) != null)
            {
                System.out.println("line: " + line);
                if (line.trim().length() > 0)
                {
                    if (line.indexOf("100% straty") >= 0)
                    {
                        ping1="brak polaczenia"; 
                    }
                } 
            }
            in.close();
            System.out.println("ping1: " + ping1);
          }
          catch(IOException ex)
          {
              ex.printStackTrace();
          }

          return -1;
    }

    private static DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss.SSS");
    private static String now()
    {
        return dateFormat.format(new Date());
    }

    private static long ct()
    {
        return System.currentTimeMillis();
    }

    public static void main(String[] args)
    {
        try
        {
            InetAddress inetAddr = InetAddress.getByName("smtp.gmail.com");
            System.out.println(ct() + " isReachable(inetAddr, 25, false): " + isReachable(inetAddr, 25, false) + " " + ct());
            System.out.println(ct() + " isReachable(inetAddr, 587, false): " + isReachable(inetAddr, 587, false) + " " + ct());
            System.out.println(ct() + " isReachable(inetAddr, 587, true): " + isReachable(inetAddr, 587, true) + " " + ct());
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
