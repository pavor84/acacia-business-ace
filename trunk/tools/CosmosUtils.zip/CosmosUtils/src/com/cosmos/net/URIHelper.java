package com.cosmos.net;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.text.Normalizer;

/**
 *
 * @author miro
 */
public class URIHelper
{
    
    // Character-class masks, in reverse order from RFC2396 because
    // initializers for static fields cannot make forward references.
    
    // digit    = "0" | "1" | "2" | "3" | "4" | "5" | "6" | "7" |
    //            "8" | "9"
    private static final long L_DIGIT = lowMask('0', '9');
    private static final long H_DIGIT = 0L;
    
    // upalpha  = "A" | "B" | "C" | "D" | "E" | "F" | "G" | "H" | "I" |
    //            "J" | "K" | "L" | "M" | "N" | "O" | "P" | "Q" | "R" |
    //            "S" | "T" | "U" | "V" | "W" | "X" | "Y" | "Z"
    private static final long L_UPALPHA = 0L;
    private static final long H_UPALPHA = highMask('A', 'Z');
    
    // lowalpha = "a" | "b" | "c" | "d" | "e" | "f" | "g" | "h" | "i" |
    //            "j" | "k" | "l" | "m" | "n" | "o" | "p" | "q" | "r" |
    //            "s" | "t" | "u" | "v" | "w" | "x" | "y" | "z"
    private static final long L_LOWALPHA = 0L;
    private static final long H_LOWALPHA = highMask('a', 'z');
    
    // alpha         = lowalpha | upalpha
    private static final long L_ALPHA = L_LOWALPHA | L_UPALPHA;
    private static final long H_ALPHA = H_LOWALPHA | H_UPALPHA;
    
    // alphanum      = alpha | digit
    private static final long L_ALPHANUM = L_DIGIT | L_ALPHA;
    private static final long H_ALPHANUM = H_DIGIT | H_ALPHA;
    
    // hex           = digit | "A" | "B" | "C" | "D" | "E" | "F" |
    //                         "a" | "b" | "c" | "d" | "e" | "f"
    private static final long L_HEX = L_DIGIT;
    private static final long H_HEX = highMask('A', 'F') | highMask('a', 'f');
    
    // mark          = "-" | "_" | "." | "!" | "~" | "*" | "'" |
    //                 "(" | ")"
    private static final long L_MARK = lowMask("-_.!~*'()");
    private static final long H_MARK = highMask("-_.!~*'()");
    
    // unreserved    = alphanum | mark
    private static final long L_UNRESERVED = L_ALPHANUM | L_MARK;
    private static final long H_UNRESERVED = H_ALPHANUM | H_MARK;
    
    // reserved      = ";" | "/" | "?" | ":" | "@" | "&" | "=" | "+" |
    //                 "$" | "," | "[" | "]"
    // Added per RFC2732: "[", "]"
    private static final long L_RESERVED = lowMask(";/?:@&=+$,[]");
    private static final long H_RESERVED = highMask(";/?:@&=+$,[]");
    
    // The zero'th bit is used to indicate that escape pairs and non-US-ASCII
    // characters are allowed; this is handled by the scanEscape method below.
    private static final long L_ESCAPED = 1L;
    private static final long H_ESCAPED = 0L;
    
    // uric          = reserved | unreserved | escaped
    private static final long L_URIC = L_RESERVED | L_UNRESERVED | L_ESCAPED;
    private static final long H_URIC = H_RESERVED | H_UNRESERVED | H_ESCAPED;
    
    // pchar         = unreserved | escaped |
    //                 ":" | "@" | "&" | "=" | "+" | "$" | ","
    private static final long L_PCHAR = L_UNRESERVED | L_ESCAPED | lowMask(":@&=+$,");
    private static final long H_PCHAR = H_UNRESERVED | H_ESCAPED | highMask(":@&=+$,");
    
    // All valid path characters
    private static final long L_PATH = L_PCHAR | lowMask(";/");
    private static final long H_PATH = H_PCHAR | highMask(";/");
    
    // Dash, for use in domainlabel and toplabel
    private static final long L_DASH = lowMask("-");
    private static final long H_DASH = highMask("-");
    
    // Dot, for use in hostnames
    private static final long L_DOT = lowMask(".");
    private static final long H_DOT = highMask(".");
    
    // userinfo      = *( unreserved | escaped |
    //                    ";" | ":" | "&" | "=" | "+" | "$" | "," )
    private static final long L_USERINFO = L_UNRESERVED | L_ESCAPED | lowMask(";:&=+$,");
    private static final long H_USERINFO = H_UNRESERVED | H_ESCAPED | highMask(";:&=+$,");
    
    // reg_name      = 1*( unreserved | escaped | "$" | "," |
    //                     ";" | ":" | "@" | "&" | "=" | "+" )
    private static final long L_REG_NAME = L_UNRESERVED | L_ESCAPED | lowMask("$,;:@&=+");
    private static final long H_REG_NAME = H_UNRESERVED | H_ESCAPED | highMask("$,;:@&=+");
    
    // All valid characters for server-based authorities
    private static final long L_SERVER = L_USERINFO | L_ALPHANUM | L_DASH | lowMask(".:@[]");
    private static final long H_SERVER = H_USERINFO | H_ALPHANUM | H_DASH | highMask(".:@[]");
    
    // Special case of server authority that represents an IPv6 address
    // In this case, a % does not signify an escape sequence
    private static final long L_SERVER_PERCENT = L_SERVER | lowMask("%");
    private static final long H_SERVER_PERCENT = H_SERVER | highMask("%");
    private static final long L_LEFT_BRACKET = lowMask("[");
    private static final long H_LEFT_BRACKET = highMask("[");
    
    // scheme        = alpha *( alpha | digit | "+" | "-" | "." )
    private static final long L_SCHEME = L_ALPHA | L_DIGIT | lowMask("+-.");
    private static final long H_SCHEME = H_ALPHA | H_DIGIT | highMask("+-.");
    
    // uric_no_slash = unreserved | escaped | ";" | "?" | ":" | "@" |
    //                 "&" | "=" | "+" | "$" | ","
    private static final long L_URIC_NO_SLASH = L_UNRESERVED | L_ESCAPED | lowMask(";?:@&=+$,");
    private static final long H_URIC_NO_SLASH = H_UNRESERVED | H_ESCAPED | highMask(";?:@&=+$,");
    
    // Compute the low-order mask for the characters in the given string
    private static long lowMask(String chars)
    {
        int n = chars.length();
        long m = 0;
        for(int i = 0; i < n; i++)
        {
            char c = chars.charAt(i);
            if(c < 64)
                m |= (1L << c);
        }
        return m;
    }
    
    // Compute the high-order mask for the characters in the given string
    private static long highMask(String chars)
    {
        int n = chars.length();
        long m = 0;
        for(int i = 0; i < n; i++)
        {
            char c = chars.charAt(i);
            if((c >= 64) && (c < 128))
                m |= (1L << (c - 64));
        }
        return m;
    }
    
    // Compute a low-order mask for the characters
    // between first and last, inclusive
    private static long lowMask(char first, char last)
    {
        long m = 0;
        int f = Math.max(Math.min(first, 63), 0);
        int l = Math.max(Math.min(last, 63), 0);
        for(int i = f; i <= l; i++)
            m |= 1L << i;
        return m;
    }
    
    // Compute a high-order mask for the characters
    // between first and last, inclusive
    private static long highMask(char first, char last)
    {
        long m = 0;
        int f = Math.max(Math.min(first, 127), 64) - 64;
        int l = Math.max(Math.min(last, 127), 64) - 64;
        for(int i = f; i <= l; i++)
            m |= 1L << i;
        return m;
    }
    
    // Tell whether the given character is permitted by the given mask pair
    private static boolean match(char c, long lowMask, long highMask)
    {
        if(c < 64)
            return((1L << c) & lowMask) != 0;
        if(c < 128)
            return((1L << (c - 64)) & highMask) != 0;
        return false;
    }
    
    // Quote any characters in s that are not permitted
    // by the given mask pair
    //
    private static String quote(String s, long lowMask, long highMask)
    {
        int n = s.length();
        StringBuilder sb = null;
        boolean allowNonASCII = ((lowMask & L_ESCAPED) != 0);
        for(int i = 0; i < s.length(); i++)
        {
            char c = s.charAt(i);
            if(c < '\u0080')
            {
                if(!match(c, lowMask, highMask))
                {
                    if(sb == null)
                    {
                        sb = new StringBuilder();
                        sb.append(s.substring(0, i));
                    }
                    appendEscape(sb, (byte)c);
                }
                else
                {
                    if(sb != null)
                        sb.append(c);
                }
            }
            else
                if(allowNonASCII && (Character.isSpaceChar(c)
                   || Character.isISOControl(c)))
                {
                    if(sb == null)
                    {
                        sb = new StringBuilder();
                        sb.append(s.substring(0, i));
                    }
                    appendEncoded(sb, c);
                }
                else
                {
                    if(sb != null)
                        sb.append(c);
                }
        }
        return(sb == null) ? s : sb.toString();
    }
    
    private final static char[] hexDigits =
    {
        '0', '1', '2', '3', '4', '5', '6', '7',
        '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'
    };
    
    private static void appendEscape(StringBuilder sb, byte b)
    {
        sb.append('%');
        sb.append(hexDigits[(b >> 4) & 0x0f]);
        sb.append(hexDigits[(b >> 0) & 0x0f]);
    }
    
    private static void appendEncoded(StringBuilder sb, char c)
    {
        ByteBuffer bb = null;
        Charset charset = Charset.forName("UTF-8");
        bb = charset.encode(CharBuffer.wrap("" + c));
        
        while(bb.hasRemaining())
        {
            int b = bb.get() & 0xff;
            if(b >= 0x80)
                appendEscape(sb, (byte)b);
            else
                sb.append((char)b);
        }
    }
    
    public static String toASCIIPath(String path)
    {
        String str = quote(path, L_PATH, H_PATH);
        return encode(str);
    }
    
    private static String encode(String s)
    {
        if(s == null)
            return null;
        
        int n = s.length();
        if (n == 0)
            return s;
        
        // First check whether we actually need to encode
        for (int i = 0;;)
        {
            if (s.charAt(i) >= '\u0080')
                break;
            if (++i >= n)
                return s;
        }
        
        String ns = Normalizer.normalize(s, Normalizer.Form.NFC);
        ByteBuffer bb = null;
        Charset charset = Charset.forName("UTF-8");
        bb = charset.encode(CharBuffer.wrap(ns));
        
        StringBuilder sb = new StringBuilder();
        while (bb.hasRemaining())
        {
            int b = bb.get() & 0xff;
            if (b >= 0x80)
                appendEscape(sb, (byte)b);
            else
                sb.append((char)b);
        }
        return sb.toString();
    }
}
