package com.cosmos.io;

import com.cosmos.util.OperatingSystem;
import com.cosmos.util.SystemUtils;
import java.io.File;

import com.sun.deploy.config.Config;


/**
 *
 * Symbolic Link:   Unix, Linux, MS Windows Vista
 * Shortcut:        MS Windows (*.lnk)
 * Alias:           Mac OS
 * Shadow:          Graphical Workplace Shell of the OS/2 operating system
 *
 **/

/**
 *
 * @author miro
 */
public class SymbolicLink
{
    private File link;
    private String path;
    private String appName;
    private String description;
    private String appPath;
    private String args;
    private String directory;
    private String iconPath;

    /**
     * @link:   specifies the new symbolic link name.
     *          This can be existing folder or existing folder with not
     *          existing file name.
     *          For MS Windows bellow Vista if the file name extension is not
     *          ".lnk", the ".lnk" extension is added.
     *          If the link parameters is existing directory only, then the
     *          name of target is taken plus the ".lnk" extension.
     * @target: specifies the path (relative or absolute) that the new link
     *          refers to. The path must exists.
     * @parameters: the parameters which will be passed to the target in
     *          case that this is a shortcut instead symbolic link
     * @icon:   the existing icon file name. This parameter can be null.
     * @description: the tooltip/description of this link
     * @workingDir: the working directory/folder for this application/target
     *
     **/
    public SymbolicLink(File link,
                        File target,
                        String parameters,
                        File icon,
                        String description,
                        File workingDirectory)
    {
        if(link == null)
            throw new IllegalArgumentException("The link can not be NULL.");

        if(target == null)
            throw new IllegalArgumentException("The link target can not be NULL.");

        if(!target.exists())
            throw new IllegalArgumentException("The target path must exists.");

        if(link.exists() && !link.isDirectory())
            throw new IllegalArgumentException("The link already exists.");

        if(link.isDirectory())
            link = new File(link, target.getName());

        if(OperatingSystem.WINDOWS.equals(SystemUtils.getOperatingSystem()))
        {
            String name = link.getName();
            if(!name.toLowerCase().endsWith(".lnk"))
                link = new File(link.getParentFile(), name + ".lnk");
        }


        this.link = link;

        this.path = link.getAbsolutePath();
        this.appName = link.getName();
        this.description = description;
        this.appPath = target.getAbsolutePath();
        this.args = parameters;
        if(workingDirectory != null && workingDirectory.exists())
            this.directory = workingDirectory.getAbsolutePath();

        if(icon != null && icon.exists())
            this.iconPath = icon.getAbsolutePath();
    }

    public SymbolicLink(File link, File target)
    {
        this(link, target, null, null, null, null);
    }

    protected Config getConfig()
    {
        return Config.getInstance();
    }

    public boolean exists()
    {
        return link.exists();
    }

    public boolean create()
    {
        int result = getConfig().installShortcut(path, appName, description, appPath, args, directory, iconPath);
        return result == 0;
    }

    public boolean delete()
    {
        return link.delete();
    }

    public File getLink()
    {
        return link;
    }

    private void printDeployConfig()
    {
        Config config = getConfig();
        System.out.println("config.canAutoDownloadJRE(): " + config.canAutoDownloadJRE());
        System.out.println("config.getAppContextKeyPrefix(): " + config.getAppContextKeyPrefix());
        System.out.println("config.getAssociationValue(): " + config.getAssociationValue());
        System.out.println("config.getBrowserPath(): " + config.getBrowserPath());
        System.out.println("config.getCacheDirectory(): " + config.getCacheDirectory());
        System.out.println("config.getCacheSizeMax(): " + config.getCacheSizeMax());
        System.out.println("config.getDefaultCacheDirectory(): " + config.getDefaultCacheDirectory());
        System.out.println("config.getEnterprizeString(): " + config.getEnterprizeString());
        System.out.println("config.getFireFoxUserProfileDirectory(): " + config.getFireFoxUserProfileDirectory());
        System.out.println("config.getJavaCommand(): " + config.getJavaCommand());
        System.out.println("config.getJavaHome(): " + config.getJavaHome());
        System.out.println("config.getJavawsCommand(): " + config.getJavawsCommand());
        System.out.println("config.getLibraryPrefix(): " + config.getLibraryPrefix());
        System.out.println("config.getLibrarySufix(): " + config.getLibrarySufix());
        System.out.println("config.getLogDirectory(): " + config.getLogDirectory());
        System.out.println("config.getMozillaUserProfileDirectory(): " + config.getMozillaUserProfileDirectory());
        System.out.println("config.getPlatformExtension(): " + config.getPlatformExtension());
        System.out.println("config.getPluginCacheDir(): " + config.getPluginCacheDir());
        System.out.println("config.getSessionSpecificString(): " + config.getSessionSpecificString());
        System.out.println("config.getSplashDir(): " + config.getSplashDir());
        System.out.println("config.getSplashIndex(): " + config.getSplashIndex());
        System.out.println("config.getSystemCacheDirectory(): " + config.getSystemCacheDirectory());
        System.out.println("config.getSystemClientAuthCertFile(): " + config.getSystemClientAuthCertFile());
        System.out.println("config.getSystemExtensionDirectory(): " + config.getSystemExtensionDirectory());
        System.out.println("config.getTempCacheDir(): " + config.getTempCacheDir());
        System.out.println("config.getTempDirectory(): " + config.getTempDirectory());
    }
}
