package com.cosmos.form;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.EventObject;
import java.util.HashSet;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLayeredPane;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.JViewport;
import javax.swing.ListSelectionModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.table.TableModel;
import javax.swing.text.Document;
import javax.swing.text.JTextComponent;
import javax.swing.tree.TreeSelectionModel;

/**
 *
 * @author miro
 */
public class GenericOptionPageListener
    implements ContainerListener,
    ListSelectionListener,
    TreeSelectionListener,
    TableModelListener,
    ActionListener,
    ItemListener,
    DocumentListener,
    ChangeListener,
    FocusListener
{
    private static final Logger logger = Logger.getLogger(GenericOptionPageListener.class.getName());

    private OptionPage optionPage;
    private OptionPageContentsChangedListener contentsChangedListener;
    private HashSet listenedTo = new HashSet();
    private boolean ignoreEvents;


    public GenericOptionPageListener(OptionPage optionPage,
                                     OptionPageContentsChangedListener contentsChangedListener)
    {
        if(optionPage == null)
        {
            throw new IllegalArgumentException("OptionPage can not be NULL");
        }
        this.optionPage = optionPage;

        if(contentsChangedListener == null)
        {
            throw new IllegalArgumentException("OptionPageContentsChangedListener can not be NULL");
        }
        this.contentsChangedListener = contentsChangedListener;

        JComponent comp = optionPage.getPageComponent();
        if(comp == null)
        {
            throw new IllegalArgumentException("Component of OptionPage can not be NULL");
        }

        // comp.addContainerListener(this);
        initListeners(comp);
    }

    protected boolean isSwingClass(Component comp)
    {
        Class clazz = comp.getClass();
        while(clazz != null)
        {
            String packageName = clazz.getPackage().getName();
            if("javax.swing".equals(packageName))
                return true;
            clazz = clazz.getSuperclass();
        }
        return false;
    }

    protected boolean isContainer(Component comp)
    {
        if(isSwingClass(comp))
        {
            return comp instanceof JPanel ||
                   comp instanceof JSplitPane ||
                   comp instanceof JToolBar ||
                   comp instanceof JViewport ||
                   comp instanceof JScrollPane ||
                   comp instanceof JFrame ||
                   comp instanceof JRootPane ||
                   comp instanceof Window ||
                   comp instanceof Frame ||
                   comp instanceof Dialog ||
                   comp instanceof JTabbedPane ||
                   comp instanceof JInternalFrame ||
                   comp instanceof JDesktopPane ||
                   comp instanceof JLayeredPane;
        }
        else
        {
            return comp instanceof Container;
        }
    }

    public void initListeners(JComponent jComponent)
    {
        if(accept(jComponent))
        {
            attachTo(jComponent);
        }

        Component[] comps = jComponent.getComponents();
        for(Component comp : comps)
        {
            if(accept(comp))
            {
                attachTo(comp);
            }
        }
    }

    public void componentAdded(ContainerEvent event)
    {
        if(accept(event.getChild()))
        {
            attachTo(event.getChild());
        }
    }

    public void componentRemoved(ContainerEvent event)
    {
        if(accept(event.getChild()))
        {
            detachFrom(event.getChild());
        }
    }

    protected boolean accept(Component jComponent)
    {
        if (!(jComponent instanceof JComponent))
        {
            return false;
        }

        return isContainer(jComponent) ||
            jComponent instanceof JList ||
            jComponent instanceof JComboBox ||
            jComponent instanceof JTree ||
            jComponent instanceof JToggleButton ||
            jComponent instanceof JTextComponent ||
            jComponent instanceof JColorChooser ||
            jComponent instanceof JSpinner ||
            jComponent instanceof JSlider;
    }

    protected void attachTo(Component jComponent)
    {
        if(isContainer(jComponent))
        {
            attachContainer((Container)jComponent);
        }
        else if(jComponent instanceof JList)
        {
            listenedTo.add(jComponent);
            ((JList)jComponent).addListSelectionListener(this);
        }
        else if(jComponent instanceof JComboBox)
        {
            ((JComboBox)jComponent).addActionListener(this);
        }
        else if(jComponent instanceof JTree)
        {
            listenedTo.add(jComponent);
            ((JTree)jComponent).getSelectionModel().addTreeSelectionListener(this);
        }
        else if(jComponent instanceof JToggleButton)
        {
            AbstractButton button = ((AbstractButton)jComponent);
            ItemListener[] itemListeners = button.getItemListeners();
            int size;
            if(itemListeners != null && (size = itemListeners.length) > 0)
            {
                for(int i = (size - 1); i >= 0; i--)
                {
                    button.removeItemListener(itemListeners[i]);
                }

                button.addItemListener(this);

                for(ItemListener itemListener : itemListeners)
                {
                    button.addItemListener(itemListener);
                }
            }
            else
                button.addItemListener(this);
        }
        else if(jComponent instanceof JTextComponent)
        {
            // logger.fine("JTextComponent found: " + jComponent);
            listenedTo.add(jComponent);
            ((JTextComponent)jComponent).getDocument().addDocumentListener(this);
            jComponent.addFocusListener(this);
        }
        else if(jComponent instanceof JColorChooser)
        {
            listenedTo.add(jComponent);
            ((JColorChooser)jComponent).getSelectionModel().addChangeListener(this);
        }
        else if(jComponent instanceof JSpinner)
        {
            ((JSpinner)jComponent).addChangeListener(this);
        }
        else if(jComponent instanceof JSlider)
        {
            ((JSlider)jComponent).addChangeListener(this);
        }
        else if(jComponent instanceof JTable)
        {
            JTable table = (JTable)jComponent;
            listenedTo.add(table);
            table.getSelectionModel().addListSelectionListener(this);
            table.getModel().addTableModelListener(this);
        }
        else
        {
            if(logger.isLoggable(Level.FINE))
            {
                // logger.fine("Don't know how to listen to a " + jComponent.getClass().getName());
            }
        }
    }

    protected void detachFrom(Component jComponent)
    {
        listenedTo.remove(jComponent);
        if(isContainer(jComponent))
        {
            detachContainer((Container)jComponent);
        }
        else if(jComponent instanceof JList)
        {
            ((JList)jComponent).removeListSelectionListener(this);
        }
        else if(jComponent instanceof JComboBox)
        {
            ((JComboBox)jComponent).removeActionListener(this);
        }
        else if(jComponent instanceof JTree)
        {
            ((JTree)jComponent).getSelectionModel().removeTreeSelectionListener(this);
        }
        else if(jComponent instanceof JToggleButton)
        {
            ((AbstractButton)jComponent).removeActionListener(this);
        }
        else if(jComponent instanceof JTextComponent)
        {
            ((JTextComponent)jComponent).getDocument().removeDocumentListener(this);
            jComponent.removeFocusListener(this);
        }
        else if(jComponent instanceof JColorChooser)
        {
            ((JColorChooser)jComponent).getSelectionModel().removeChangeListener(this);
        }
        else if(jComponent instanceof JSpinner)
        {
            ((JSpinner)jComponent).removeChangeListener(this);
        }
        else if(jComponent instanceof JSlider)
        {
            ((JSlider)jComponent).removeChangeListener(this);
        }
        else if(jComponent instanceof JTable)
        {
            JTable table = (JTable)jComponent;
            table.getSelectionModel().removeListSelectionListener(this);
            table.getModel().removeTableModelListener(this);
        }
    }

    private void attachContainer(Container container)
    {
        container.addContainerListener(this);
        Component[] components = container.getComponents();
        for(Component comp : components)
        {
            attachTo(comp);
        }
    }

    private void detachContainer(Container container)
    {
        container.removeContainerListener(this);
        Component[] components = container.getComponents();
        for(Component comp : components)
        {
            detachFrom(comp);
        }
    }

    public void insertUpdate(DocumentEvent event)
    {
        fire(event);
    }
    
    public void changedUpdate(DocumentEvent event)
    {
        fire(event);
    }
    
    public void removeUpdate(DocumentEvent event)
    {
        fire(event);
    }
    
    public void stateChanged(ChangeEvent event)
    {
        fire(event);
    }
    
    public void valueChanged(ListSelectionEvent event)
    {
        fire(event);
    }
    
    public void valueChanged(TreeSelectionEvent event)
    {
        fire(event);
    }
    
    public void tableChanged(TableModelEvent event)
    {
        fire(event);
    }

    public void itemStateChanged(ItemEvent event)
    {
        fire(event);
    }

    public void actionPerformed(ActionEvent event)
    {
        fire(event);
    }

    public void focusGained(FocusEvent event)
    {
    }

    public void focusLost(FocusEvent event)
    {
        //logger.fine("focusLost.FocusEvent: " + event);
        fire(event);
    }

    private void fire(EventObject event)
    {
        if(!ignoreEvents)
        {
            ignoreEvents = true;
            try
            {
                Object source = event.getSource();
                if(source instanceof Component)
                {
                    contentsChangedListener.contentsChanged(optionPage, (Component)source, event);
                }
                else if(event instanceof TreeSelectionEvent)
                {
                    TreeSelectionModel selectionModel = (TreeSelectionModel)source;
                    for(Iterator i = listenedTo.iterator(); i.hasNext(); )
                    {
                        Object obj = i.next();
                        if(obj instanceof JTree &&
                           ((JTree)obj).getSelectionModel() == selectionModel)
                        {
                            contentsChangedListener.contentsChanged(optionPage, (Component)obj, event);
                            break;
                        }
                    }
                }
                else if(event instanceof ListSelectionEvent)
                {
                    ListSelectionModel selectionModel = (ListSelectionModel)source;
                    for(Iterator i = listenedTo.iterator(); i.hasNext(); )
                    {
                        Object obj = i.next();
                        if(obj instanceof JList &&
                           ((JList)obj).getSelectionModel() == selectionModel)
                        {
                            contentsChangedListener.contentsChanged(optionPage, (Component)obj, event);
                            break;
                        }
                        else if(obj instanceof JTable &&
                                ((JTable)obj).getSelectionModel() == selectionModel)
                        {
                            contentsChangedListener.contentsChanged(optionPage, (Component)obj, event);
                            break;
                        }
                    }
                }
                else if(event instanceof TableModelEvent)
                {
                    TableModel model = (TableModel)source;
                    for(Iterator i = listenedTo.iterator(); i.hasNext(); )
                    {
                        Object obj = i.next();
                        if(obj instanceof JTable &&
                           ((JTable)obj).getModel() == model)
                        {
                            contentsChangedListener.contentsChanged(optionPage, (Component)obj, event);
                            break;
                        }
                    }
                }
                else
                {
                    contentsChangedListener.contentsChanged(optionPage, null, event);
                }
            }
            finally
            {
                ignoreEvents = false;
            }
        }
    }

    private void fire(DocumentEvent event)
    {
        if(!ignoreEvents)
        {
            ignoreEvents = true;
            try
            {
                Document document = event.getDocument();
                //logger.fine("DocumentEvent: " + event + ", Document: " + document);
                for(Iterator i = listenedTo.iterator(); i.hasNext(); )
                {
                    Object obj = i.next();
                    if(obj instanceof JTextComponent &&
                       ((JTextComponent)obj).getDocument() == document)
                    {
                        contentsChangedListener.contentsChanged(optionPage, (Component)obj, event);
                        break;
                    }
                }
            }
            finally
            {
                ignoreEvents = false;
            }
        }
    }
}
