package com.cosmos.form;

import java.awt.Component;

/**
 *
 * @author miro
 */
public interface OptionPageContentsChangedListener
{
    public void contentsChanged(OptionPage optionPage, Component comp, Object event);
}
