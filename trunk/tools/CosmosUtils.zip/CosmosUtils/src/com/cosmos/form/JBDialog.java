/*
 * JBDialog.java
 *
 * Created on Сряда, 2006, Ноември 29, 10:25
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.cosmos.form;

import com.cosmos.util.ResourceBundleManager;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.HeadlessException;
import java.awt.Window;
import java.util.ResourceBundle;
import javax.swing.ImageIcon;
import javax.swing.JDialog;

/**
 *
 * @author miro
 */
public class JBDialog
    extends JDialog
{
   
    public JBDialog()
        throws HeadlessException
    {
        super();
        init();
    }

    public JBDialog(Window owner, String title)
        throws HeadlessException
    {
        super(owner, title);
        init();
    }

    public JBDialog(Frame owner, String title)
        throws HeadlessException
    {
        super(owner, title);
        init();
    }

    public JBDialog(Dialog owner, String title)
        throws HeadlessException
    {
        super(owner, title);
        init();
    }

    protected void init()
    {
        try
        {
            ResourceBundle rb = getResourceBundle();
            if(rb != null)
            {
                ImageIcon icon = (ImageIcon)rb.getObject("icon.SystemLogo.Small");
                if(icon != null)
                {
                    setIconImage(icon.getImage());
                }
            }
        }
        catch(Exception ex) {}
    }

    public ResourceBundle getResourceBundle()
    {
        return ResourceBundleManager.getResourceBundle();
    }

}
