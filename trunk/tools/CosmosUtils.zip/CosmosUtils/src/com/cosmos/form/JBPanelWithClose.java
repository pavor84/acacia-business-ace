package com.cosmos.form;


/**
 *
 * @author miro
 */
public class JBPanelWithClose
    extends JBPanel
{
    
    /** Creates a new instance of JBPanelWithClose */
    public JBPanelWithClose()
    {
        super();
        setOptionActions(getCloseAction());
    }
    
}
