package com.cosmos.form;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import org.jdesktop.swingx.JXImagePanel;

/**
 *
 * @author  miro
 */
public class LoginPanel
    extends JBPanel
{
    public LoginPanel()
    {
        setFormName("Login");
        initComponents();
    }
    
    private void initComponents()
    {
        GridBagConstraints gridBagConstraints;

        bannerPanel = new JXImagePanel();
        bannerTopLevelLabel = new JLabel();
        bannerMiddleLevelLabel = new JLabel();
        bannerDownLevelLabel = new JLabel();
        dataPanel = new JBPanel();
        usernameLabel = new JLabel();
        passwordLabel = new JLabel();
        usernameField = new JTextField();
        passwordField = new JPasswordField();

        super.setLayout(new GridBagLayout());

        bannerPanel.setLayout(new BorderLayout());
        bannerPanel.setImage(getBannerIcon().getImage());

        Font font = new Font("Bauhaus-Heavy", Font.PLAIN, 18);
        String text = getBannerTopLevelText();
        if(text != null)
        {
            bannerTopLevelLabel.setFont(font);
//            bannerTopLevelLabel.setForeground(new Color(153, 102, 0));
            bannerTopLevelLabel.setText(text);
        }
        bannerTopLevelLabel.setHorizontalAlignment(SwingConstants.LEADING);
        bannerPanel.add(bannerTopLevelLabel, BorderLayout.PAGE_START);

        text = getBannerMiddleLevelText();
        if(text != null)
        {
            bannerMiddleLevelLabel.setFont(font);
            bannerMiddleLevelLabel.setText(text);
        }
        bannerMiddleLevelLabel.setHorizontalAlignment(SwingConstants.CENTER);
        bannerPanel.add(bannerMiddleLevelLabel, BorderLayout.CENTER);

        text = getBannerDownLevelText();
        if(text != null)
        {
//            font = new Font("Bauhaus-Heavy", Font.PLAIN, 18);
            bannerDownLevelLabel.setFont(font);
//            bannerDownLevelLabel.setForeground(new Color(153, 102, 0));
            bannerDownLevelLabel.setText(text);
        }
        bannerDownLevelLabel.setHorizontalAlignment(SwingConstants.TRAILING);
        bannerPanel.add(bannerDownLevelLabel, BorderLayout.PAGE_END);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagConstraints.insets = new Insets(10, 10, 10, 10);
        add(bannerPanel, gridBagConstraints);

        dataPanel.setLayout(new GridBagLayout());

        usernameLabel.setText(getUsernameText());
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = GridBagConstraints.WEST;
        dataPanel.add(usernameLabel, gridBagConstraints);

        passwordLabel.setText(getPasswordText());
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = GridBagConstraints.WEST;
        dataPanel.add(passwordLabel, gridBagConstraints);

        usernameField.setColumns(12);
        usernameField.setText(getUsername());
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new Insets(5, 5, 5, 5);
        dataPanel.add(usernameField, gridBagConstraints);

        passwordField.setColumns(12);
        passwordField.setText(new String(getPassword()));
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new Insets(5, 5, 5, 5);
        dataPanel.add(passwordField, gridBagConstraints);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new Insets(10, 10, 10, 10);
        add(dataPanel, gridBagConstraints);

        usernameField.setAction(getUsernameAction());
        passwordField.setAction(getPasswordAction());
    }
    
    
    private JLabel bannerDownLevelLabel;
    private JLabel bannerMiddleLevelLabel;
    private JXImagePanel bannerPanel;
    private JLabel bannerTopLevelLabel;
    private com.cosmos.form.JBPanel dataPanel;
    private JPasswordField passwordField;
    private JLabel passwordLabel;
    private JTextField usernameField;
    private JLabel usernameLabel;
    

    public void setLayout(LayoutManager layout)
    {
    }

    public String getFormTitle()
    {
        String dialogTitle = super.getFormTitle();
        if(dialogTitle == null)
        {
            dialogTitle = "Login";
        }

        return dialogTitle;
    }


    private ImageIcon bannerIcon;
    private String bannerTopLevelText;
    private String bannerMiddleLevelText;
    private String bannerDownLevelText;
    private String usernameText;
    private String passwordText;

    
    protected JLabel getLabelFromResourse(String labelKey)
    {
        try
        {
            labelKey = "form.Login." + labelKey;
            ResourceBundle rb = getResourceBundle();
            if(rb != null)
            {
                String text = rb.getString(labelKey + ".Text");
                if(text != null)
                {
                    JLabel label = new JLabel(text);
                    try
                    {
                        
                    }
                    catch(Exception ex)
                    {
                        return label;
                    }
                }
            }
            
        }
        catch(Exception ex)
        {
            return null;
        }
//"form.Login.BannerTopLevel.Text=eConfidance System"

        if(bannerTopLevelLabel == null)
        {
            Font font = new Font("Bauhaus-Heavy", Font.PLAIN, 20);
            String text = getBannerTopLevelText();
            if(text != null)
            {
                bannerTopLevelLabel.setFont(font);
                bannerTopLevelLabel.setForeground(new Color(153, 102, 0));
                bannerTopLevelLabel.setText(text);
            }
        }
        return bannerTopLevelLabel;
    }

    public ImageIcon getBannerIcon()
    {
        if(bannerIcon == null)
        {
            Object value = getResourceBundle().getObject("icon.LoginBanner.Large");
            if(value != null && value instanceof ImageIcon)
                bannerIcon = (ImageIcon)value;
        }
        return bannerIcon;
    }

    public void setBannerIcon(ImageIcon bannerIcon)
    {
        this.bannerIcon = bannerIcon;
    }

    public String getFormName()
    {
        return "Login";
    }

    public String getBannerTopLevelText()
    {
        if(bannerTopLevelText == null)
        {
            bannerTopLevelText = getResourceText("BannerTopLevel");
        }
        return bannerTopLevelText;
    }

    public void setBannerTopLevelText(String bannerTopLevelText)
    {
        this.bannerTopLevelText = bannerTopLevelText;
        bannerTopLevelLabel.setText(bannerTopLevelText);
    }

    public String getBannerMiddleLevelText()
    {
        if(bannerMiddleLevelText == null)
        {
            bannerMiddleLevelText = getResourceText("BannerMiddleLevel");
        }
        return bannerMiddleLevelText;
    }

    public void setBannerMiddleLevelText(String bannerMiddleLevelText)
    {
        this.bannerMiddleLevelText = bannerMiddleLevelText;
        bannerMiddleLevelLabel.setText(bannerMiddleLevelText);
    }

    public String getBannerDownLevelText()
    {
        if(bannerDownLevelText == null)
        {
            bannerTopLevelText = getResourceText("BannerDownLevel");
        }
        return bannerDownLevelText;
    }

    public void setBannerDownLevelText(String bannerDownLevelText)
    {
        this.bannerDownLevelText = bannerDownLevelText;
        bannerDownLevelLabel.setText(bannerDownLevelText);
    }

    public String getUsername()
    {
        return usernameField.getText();
    }
    
    public void setUsername(String username)
    {
        usernameField.setText(username);
    }

    public char[] getPassword()
    {
        return passwordField.getPassword();
    }

    public void setPassword(char[] password)
    {
        passwordField.setText(new String(password));
    }

    public String getUsernameText()
    {
        if(usernameText == null)
        {
            usernameText = getResourceText("Username", "Username:");
        }

        return usernameText;
    }
    
    public void setUsernameText(String usernameText)
    {
        this.usernameText = usernameText;
    }

    public String getPasswordText()
    {
        if(passwordText == null)
        {
            passwordText = getResourceText("Password", "Password:");
        }

        return passwordText;
    }
    
    public void setPasswordText(String passwordText)
    {
        this.passwordText = passwordText;
    }


    public List<Action> getOptionActions()
    {
        List<Action> optionActions = super.getOptionActions();
        if(optionActions == null || optionActions.size() <= 0)
        {
            optionActions = Arrays.<Action>asList(getLoginAction(), getCancelAction());
            super.setOptionActions(optionActions);
        }
        return optionActions;
    }

    public void loginActionPerformed(ActionEvent event)
    {
        if(!doLogin())
        {
            String message = getResourceText("ErrorMessage");
            String title = getResourceText("ErrorTitle");
            if(message == null)
                message = "Wrong password or/and username. Please try again.";
            if(title == null)
                title = "Login error";
            JOptionPane.showMessageDialog(
                    getDialog(),
                    message,
                    title,
                    JOptionPane.ERROR_MESSAGE);

            if(event instanceof SmartActionEvent)
            {
                ((SmartActionEvent)event).setExitFromDialog(false);
                usernameField.requestFocus();
            }
        }
    }

    public void usernameActionPerformed(ActionEvent event)
    {
        String username = getUsername();
        if(username != null && (username = username.trim()).length() > 0)
        {
            passwordField.requestFocus();
        }
    }

    public void passwordActionPerformed(ActionEvent event)
    {
        List<JButton> optionButtons = getOptionButtonList();
        if(optionButtons != null && optionButtons.size() > 0)
        {
            optionButtons.get(0).requestFocus();
        }
    }

    public boolean doLogin()
    {
        throw new RuntimeException("The method \"boolean doLogin()\" must be implemented.");
    }
}
