package com.cosmos.form;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;

/**
 *
 * @author miro
 */
public class UniformFlowLayout
    extends FlowLayout
{
    
    public UniformFlowLayout()
    {
        super();
    }

    public UniformFlowLayout(int align)
    {
        super(align);
    }

    public UniformFlowLayout(int align, int hgap, int vgap)
    {
        super(align, hgap, vgap);
    }

    public Dimension preferredLayoutSize(Container target)
    {
        setComponentsSize(target);
        return super.preferredLayoutSize(target);
    }

    public Dimension minimumLayoutSize(Container target)
    {
        setComponentsSize(target);
        return super.minimumLayoutSize(target);
    }

    public void layoutContainer(Container target)
    {
        setComponentsSize(target);
        super.layoutContainer(target);
    }

    protected void setComponentsSize(Container target)
    {
        synchronized(target.getTreeLock())
        {
            Dimension preferredSize = new Dimension(0, 0);
            Component[] components = target.getComponents();
            for(Component comp : components)
            {
                if(comp.isVisible())
                {
                    Dimension size = comp.getMinimumSize();
                    preferredSize.width = Math.max(preferredSize.width, size.width);
                    preferredSize.height = Math.max(preferredSize.height, size.height);

                    size = comp.getPreferredSize();
                    preferredSize.width = Math.max(preferredSize.width, size.width);
                    preferredSize.height = Math.max(preferredSize.height, size.height);
                }
            }

            for(Component comp : components)
            {
                if(comp.isVisible())
                {
                    comp.setMinimumSize(preferredSize);
                    comp.setPreferredSize(preferredSize);
                }
            }
        }
    }

}
