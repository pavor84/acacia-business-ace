/*
 * JBTree.java
 *
 * Created on Петък, 2006, Ноември 24, 8:15
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.cosmos.form;

import java.util.Hashtable;
import java.util.Vector;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;
import org.jdesktop.swingx.JXTree;

/**
 *
 * @author miro
 */
public class JBTree
    extends JXTree
{
    public JBTree()
    {
        super();
    }

    public JBTree(Object[] value)
    {
        super(value);
    }

    public JBTree(Vector<?> value)
    {
        super(value);
    }

    public JBTree(Hashtable<?,?> value)
    {
        super(value);
    }

    public JBTree(TreeNode root)
    {
        super(root);
    }

    public JBTree(TreeNode root, boolean asksAllowsChildren)
    {
        super(root, asksAllowsChildren);
    }

    public JBTree(TreeModel newModel)
    {
        super(newModel);
    }

}
