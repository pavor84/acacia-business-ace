package com.cosmos.form;

import com.cosmos.util.ResourceBundleControl;
import com.cosmos.util.ResponseType;
import com.cosmos.util.SmartResourceBundle;
import com.cosmos.util.data.UniversalIndexKey;
import com.cosmos.util.locale.CountryDisplayLocale;
import com.cosmos.util.locale.DisplayLocale;
import com.cosmos.util.locale.LanguageDisplayLocale;
import com.cosmos.util.locale.VariantDisplayLocale;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.SortedMap;
import java.util.TreeMap;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JLabel;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

/**
 *
 * @author miro
 */
public class LocalePanel
    extends JBPanel
{
    protected static final String MIN_STRING_KEY = UniversalIndexKey.getMinString(2);
    protected static final String MAX_STRING_KEY = UniversalIndexKey.getMaxString(2);

    private JBComboBox countryComboBox;
    private JLabel countryLabel;
    private JBComboBox languageComboBox;
    private JLabel languageLabel;
    private JBComboBox variantComboBox;
    private JLabel variantLabel;

    protected TreeMap<Comparable, Locale> localesMap;
    protected ResourceBundleControl rbControl;
    protected Action okAction;
    

    public LocalePanel()
    {
        initComponents();
        initData();
    }
    
    private void initComponents()
    {
        Dimension size = new Dimension(270, 110);
        setMinimumSize(size);
        setPreferredSize(size);
        GridBagConstraints gridBagConstraints;

        languageLabel = new JLabel();
        countryLabel = new JLabel();
        variantLabel = new JLabel();

        languageComboBox = new JBComboBox();
        countryComboBox = new JBComboBox();
        variantComboBox = new JBComboBox();
        size = new Dimension(186, 25);
        languageComboBox.setMinimumSize(size);
        languageComboBox.setPreferredSize(size);
        countryComboBox.setMinimumSize(size);
        countryComboBox.setPreferredSize(size);
        variantComboBox.setMinimumSize(size);
        variantComboBox.setPreferredSize(size);

        setLayout(new GridBagLayout());

        languageLabel.setText(getLanguageLabelText());
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = GridBagConstraints.WEST;
        gridBagConstraints.insets = new Insets(5, 5, 5, 5);
        add(languageLabel, gridBagConstraints);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new Insets(5, 5, 5, 5);
        add(languageComboBox, gridBagConstraints);

        countryLabel.setText(getCountryLabelText());
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = GridBagConstraints.WEST;
        gridBagConstraints.insets = new Insets(5, 5, 5, 5);
        add(countryLabel, gridBagConstraints);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new Insets(5, 5, 5, 5);
        add(countryComboBox, gridBagConstraints);

        variantLabel.setText(getVariantLabelText());
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = GridBagConstraints.WEST;
        gridBagConstraints.insets = new Insets(5, 5, 5, 5);
        add(variantLabel, gridBagConstraints);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new Insets(5, 5, 5, 5);
        add(variantComboBox, gridBagConstraints);

        languageComboBox.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent evt)
            {
                languageComboBoxActionPerformed(evt);
            }
        });

        countryComboBox.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent evt)
            {
                countryComboBoxActionPerformed(evt);
            }
        });

        variantComboBox.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent evt)
            {
                variantComboBoxActionPerformed(evt);
            }
        });
    }

    private void variantComboBoxActionPerformed(ActionEvent evt)
    {
        variantChanged();
    }

    private void countryComboBoxActionPerformed(ActionEvent evt)
    {
        countryChanged();
    }

    private void languageComboBoxActionPerformed(ActionEvent evt)
    {
        languageChanged();
    }
    
    protected void initData()
    {
        AutoCompleteDecorator.decorate(languageComboBox);
        AutoCompleteDecorator.decorate(countryComboBox);
        AutoCompleteDecorator.decorate(variantComboBox);

        Locale[] locales = Locale.getAvailableLocales();

        localesMap = new TreeMap<Comparable, Locale>();
        TreeMap<Comparable, Locale> languages = new TreeMap<Comparable, Locale>();

        for(Locale locale : locales)
        {
            String language = locale.getLanguage();
            String country = locale.getCountry();
            String variant = locale.getVariant();

            UniversalIndexKey key = new UniversalIndexKey(language, country, variant);
            localesMap.put(key, locale);
            if(!languages.containsKey(language))
            {
                languages.put(language, locale);
            }
        }

        List<DisplayLocale> langList = LanguageDisplayLocale.toDisplayLocale(languages.values());
        languageComboBox.setData(langList);

        try
        {
            ResourceBundle rb = getResourceBundle();
            if(rb != null)
            {
                setSelectedLocale(rb.getLocale());
            }
        }
        catch(Exception ex) {}
    }

    public String getFormName()
    {
        return "Locale";
    }

    protected ResourceBundleControl getResourceBundleControl()
    {
        if(rbControl == null)
        {
            rbControl = new ResourceBundleControl();
        }
        return rbControl;
    }

    protected String getLanguageLabelText()
    {
        return getResourceText("Language", "Language:");
    }

    protected String getCountryLabelText()
    {
        return getResourceText("Country", "Country:");
    }

    protected String getVariantLabelText()
    {
        return getResourceText("Variant", "Variant:");
    }

    protected void countryChanged()
    {
        DisplayLocale displayLocale = (DisplayLocale)countryComboBox.getSelectedItem();
        if(displayLocale != null)
        {
            Locale locale = displayLocale.getLocale();
            String language = locale.getLanguage();
            String country = locale.getCountry();
            UniversalIndexKey fromIndex = new UniversalIndexKey(language, country, null);
            UniversalIndexKey toIndex = new UniversalIndexKey(language, country, MAX_STRING_KEY);
            SortedMap subMap = localesMap.subMap(fromIndex, true, toIndex, true);
            List<DisplayLocale> variantList = VariantDisplayLocale.toDisplayLocale(subMap.values());
            variantComboBox.setData(variantList);
        }
    }

    protected void languageChanged()
    {
        DisplayLocale displayLocale = (DisplayLocale)languageComboBox.getSelectedItem();
        if(displayLocale != null)
        {
            String language = displayLocale.getId();
            UniversalIndexKey fromIndex = new UniversalIndexKey(language, null, null);
            UniversalIndexKey toIndex = new UniversalIndexKey(language, MAX_STRING_KEY, MAX_STRING_KEY);
            SortedMap<Comparable, Locale> subMap = localesMap.subMap(fromIndex, true, toIndex, true);

            List<DisplayLocale> countryList = CountryDisplayLocale.toDisplayLocale(subMap.values());
            countryComboBox.setData(countryList);
        }
    }

    protected void variantChanged()
    {
        Locale locale = getSelectedLocale();
        if(locale != null)
        {
            SmartResourceBundle rb = null;
            try
            {
                rb = (SmartResourceBundle)getResourceBundle();
            }
            catch(Exception ex) {}

            Action okAction = getOkAction();
            String baseName;
            if(okAction != null &&
               rb != null &&
               (baseName = rb.getBaseName()) != null &&
               (baseName = baseName.trim()).length() > 0)
            {
                try
                {
                    ResourceBundle testRB = ResourceBundle.getBundle(baseName,
                                                                     locale,
                                                                     getResourceBundleControl());
                    if(locale.equals(testRB.getLocale()))
                    {
                        okAction.setEnabled(true);
                    }
                    else
                    {
                        okAction.setEnabled(false);
                    }
                }
                catch(Exception ex) {}
            }
        }
    }

    public void setSelectedLocale(Locale locale)
    {
        if(locale != null)
        {
            String id = locale.getLanguage();
            if(id != null)
            {
                List<DisplayLocale> data = languageComboBox.getData();
                for(DisplayLocale displayLocale : data)
                {
                    if(id.equals(displayLocale.getId()))
                    {
                        languageComboBox.setSelectedItem(displayLocale);
                        break;
                    }
                }
            }

            id = locale.getCountry();
            if(id != null)
            {
                List<DisplayLocale> data = countryComboBox.getData();
                for(DisplayLocale displayLocale : data)
                {
                    if(id.equals(displayLocale.getId()))
                    {
                        countryComboBox.setSelectedItem(displayLocale);
                        break;
                    }
                }
            }

            id = locale.getVariant();
            if(id != null)
            {
                List<DisplayLocale> data = variantComboBox.getData();
                for(DisplayLocale displayLocale : data)
                {
                    if(id.equals(displayLocale.getId()))
                    {
                        variantComboBox.setSelectedItem(displayLocale);
                        break;
                    }
                }
            }
        }
    }

    public Locale getSelectedLocale()
    {
        DisplayLocale languageLocale = (DisplayLocale)languageComboBox.getSelectedItem();
        DisplayLocale countryLocale = (DisplayLocale)countryComboBox.getSelectedItem();
        DisplayLocale variantLocale = (DisplayLocale)variantComboBox.getSelectedItem();

        String language = null;
        String country = null;
        String variant = null;
        String id;
        if(languageLocale != null &&
           (id = languageLocale.getId()) != null &&
           (id = id.trim()).length() > 0)
        {
            language = id;
        }

        if(countryLocale != null &&
           (id = countryLocale.getId()) != null &&
           (id = id.trim()).length() > 0)
        {
            country = id;
        }

        if(variantLocale != null &&
           (id = variantLocale.getId()) != null &&
           (id = id.trim()).length() > 0)
        {
            variant = id;
        }

        if(language != null)
        {
            if(country != null)
            {
                if(variant != null)
                    return new Locale(language, country, variant);
                else
                    return new Locale(language, country);
            }
            else
                return new Locale(language);
        }

        return null;
    }

    public List<Action> getOptionActions()
    {
        List<Action> optionActions = super.getOptionActions();
        if(optionActions == null || optionActions.size() <= 0)
        {
            optionActions = Arrays.<Action>asList(getOkAction(), getCancelAction());
            super.setOptionActions(optionActions);
        }
        return optionActions;
    }



    public static void main(String[] args)
    {
        LocalePanel form = new LocalePanel();
        ResponseType response = form.showDialog(null);
//        System.out.println("action: " + action + ", Name: " + action.getValue(Action.NAME) + ", CommandKey: " + action.getValue(Action.ACTION_COMMAND_KEY));
        System.exit(0);
    }

}


