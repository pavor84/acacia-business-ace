package com.cosmos.form;

import javax.swing.InputVerifier;
import javax.swing.JComponent;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.JTextComponent;

/**
 *
 * @author miro
 */
public abstract class TextInputVerifierAdapter
    extends InputVerifier
    implements DocumentListener
{
    protected JTextComponent textComponent;
    
    /** Creates a new instance of TextInputVerifierAdapter */
    public TextInputVerifierAdapter(JTextComponent textComponent)
    {
        this.textComponent = textComponent;
        textComponent.setInputVerifier(this);
        textComponent.getDocument().addDocumentListener(this);
    }
    
    public boolean verify(JComponent input)
    {
        return textChanged();
    }

    public void insertUpdate(DocumentEvent event)
    {
        textChanged();
    }

    public void changedUpdate(DocumentEvent event)
    {
        textChanged();
    }

    public void removeUpdate(DocumentEvent event)
    {
        textChanged();
    }

    public abstract boolean textChanged();
}
