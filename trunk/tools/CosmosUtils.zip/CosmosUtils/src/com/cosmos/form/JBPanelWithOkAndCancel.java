package com.cosmos.form;

/**
 *
 * @author miro
 */
public class JBPanelWithOkAndCancel
    extends JBPanel
{
    
    /** Creates a new instance of JBPanelWithOkAndCancel */
    public JBPanelWithOkAndCancel()
    {
        super();
        setOptionActions(getOkAction(), getCancelAction());
    }
    
}
