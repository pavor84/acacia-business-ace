package com.cosmos.form;

import com.cosmos.bean.table.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import org.jdesktop.swingx.JXTable;

/**
 *
 * @author miro
 */
public class JBTable
    extends JXTable
{
    private JTable parentTable;
    private JTree parentTree;
    private ParentListSelectionHandler parentListSelectionHandler;
    private ParentTreeSelectionHandler parentTreeSelectionHandler;

    public JBTable()
    {
        super();
        internalInitialization();
    }

    public JBTable(TableModel dm)
    {
        super(dm);
        internalInitialization();
    }

    public JBTable(TableModel dm, TableColumnModel cm)
    {
        super(dm, cm);
        internalInitialization();
    }

    public JBTable(TableModel dm, TableColumnModel cm, ListSelectionModel sm)
    {
        super(dm, cm, sm);
        internalInitialization();
    }

    public JBTable(int numRows, int numColumns)
    {
        super(numRows, numColumns);
        internalInitialization();
    }

    public JBTable(Vector rowData, Vector columnNames)
    {
        super(rowData, columnNames);
        internalInitialization();
    }

    public JBTable(Object[][] rowData, Object[] columnNames)
    {
        super(rowData, columnNames);
        internalInitialization();
    }

    protected void internalInitialization()
    {
        setAutoResizeMode(AUTO_RESIZE_OFF);
        setColumnControlVisible(true);
        getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        setHorizontalScrollEnabled(true);
        setEditable(false);
    }

    public void setParentTable(JTable parentTable)
    {
        this.parentTable = parentTable;

        if(parentListSelectionHandler != null)
        {
            parentTable.getSelectionModel().removeListSelectionListener(parentListSelectionHandler);
            parentListSelectionHandler = null;
        }

        if(parentTable != null)
        {
            parentListSelectionHandler = new ParentListSelectionHandler();
            parentTable.getSelectionModel().addListSelectionListener(parentListSelectionHandler);
        }
    }

    public JTable getParentTable()
    {
        return parentTable;
    }

    public void setParentTree(JTree parentTree)
    {
        this.parentTree = parentTree;

        if(parentTreeSelectionHandler != null)
        {
            parentTree.getSelectionModel().removeTreeSelectionListener(parentTreeSelectionHandler);
            parentTreeSelectionHandler = null;
        }

        if(parentTree != null)
        {
            parentTreeSelectionHandler = new ParentTreeSelectionHandler();
            parentTree.getSelectionModel().addTreeSelectionListener(parentTreeSelectionHandler);
        }
    }

    public JTree getParentTree()
    {
        return parentTree;
    }

    public int addRow(Object bean)
    {
        return ((BeanTableModel)getModel()).addRow(bean);
    }

    public void setRow(int rowIndex, Object bean)
    {
        ((BeanTableModel)getModel()).setRow(convertRowIndexToModel(rowIndex), bean);
    }

    public void replaceSelectedRow(Object bean)
    {
        int rowIndex = getSelectedRow();
        setRow(rowIndex, bean);
    }

    public int getRowIndex(Object bean)
    {
        int rowIndex = ((BeanTableModel)getModel()).getRowIndex(bean);
        if(rowIndex >= 0)
        {
            return convertRowIndexToView(rowIndex);
        }

        return -1;
    }

    public void setSelectedRowObject(Object bean)
    {
        int rowIndex = getRowIndex(bean);
        if(rowIndex >= 0)
            getSelectionModel().setSelectionInterval(rowIndex, rowIndex);
    }

    public int getSelectedModelRowIndex()
    {
        int viewRowIndex;
        if((viewRowIndex = getSelectedRow()) != -1)
        {
            return convertRowIndexToModel(viewRowIndex);
        }
        
        return -1;
    }

    public void fireSelectedRowUpdated()
    {
        int rowIndex = getSelectedModelRowIndex();
        if(rowIndex >= 0)
            ((BeanTableModel)getModel()).fireTableRowsUpdated(rowIndex, rowIndex);
    }

    public int[] getSelectedModelRowIndexes()
    {
        int[] selectedRowIndexes = getSelectedRows();
        int size;
        if(selectedRowIndexes != null && (size = selectedRowIndexes.length) > 0)
        {
            for(int i = 0; i < size; i++)
            {
                selectedRowIndexes[i] = convertRowIndexToModel(selectedRowIndexes[i]);
            }
        }
        
        return selectedRowIndexes;
    }

    public Object getSelectedRowObject()
    {
        int rowIndex = getSelectedModelRowIndex();
        if(rowIndex >= 0)
        {
            return ((BeanTableModel)getModel()).getRow(rowIndex);
        }
        
        return null;
    }

    public List getSelectedRowObjects()
    {
        int[] rowIndexes = getSelectedModelRowIndexes();
        int size;
        if(rowIndexes != null && (size = rowIndexes.length) > 0)
        {
            ArrayList rows = new ArrayList(size);
            BeanTableModel tableModel = ((BeanTableModel)getModel());
            for(int rowIndex : rowIndexes)
            {
                rows.add(tableModel.getRow(rowIndex));
            }
            return rows;
        }
        
        return Collections.EMPTY_LIST;
    }

    public void setData(Collection data)
    {
        ((BeanTableModel)getModel()).setData(data);
    }    

    public List getData()
    {
        return ((BeanTableModel)getModel()).getData();
    }

    public void clearData()
    {
        ((BeanTableModel)getModel()).clearData();
    }    

    public Object removeSelectedRow()
    {
        int rowIndex = getSelectedModelRowIndex();
        if(rowIndex >= 0)
        {
            return ((BeanTableModel)getModel()).removeRow(rowIndex);
        }

        return null;
    }

    public ResourceBundle getResourceBundle()
    {
        BeanTableModel model = (BeanTableModel)getModel();
        if(model != null)
        {
            return model.getResourceBundle();
        }
        return null;
    }

    public void parentTableSelectionChanged(ListSelectionEvent event)
    {
    }

    public void parentTreeSelectionChanged(TreeSelectionEvent event)
    {
    }

    public void addListSelectionListener(ListSelectionListener listener)
    {
        ListSelectionModel selectionModel = getSelectionModel();
        if(selectionModel != null)
        {
            selectionModel.addListSelectionListener(listener);
        }
    }

    public void removeListSelectionListener(ListSelectionListener listener)
    {
        ListSelectionModel selectionModel = getSelectionModel();
        if(selectionModel != null)
        {
            selectionModel.removeListSelectionListener(listener);
        }
    }

    private class ParentListSelectionHandler
        implements ListSelectionListener
    {
        public void valueChanged(ListSelectionEvent event)
        {
            parentTableSelectionChanged(event);
        }
    }

    private class ParentTreeSelectionHandler
        implements TreeSelectionListener
    {
        public void valueChanged(TreeSelectionEvent event)
        {
            parentTreeSelectionChanged(event);
        }
    }

}
