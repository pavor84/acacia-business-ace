package com.cosmos.form;

import java.awt.Component;
import java.util.Map;
import java.util.Properties;
import javax.swing.Icon;
import javax.swing.JComponent;

/**
 *
 * @author miro
 */
public interface OptionPage
{
    public String getPageName();
    public String getPageDescription();
    public String getPageTitle();
    public String getPageTooltip();
    public void validatePage(Component comp, Object event)
        throws FieldValidationException;
    public void allowNext(Map currentSettings)
        throws FieldValidationException;
    public void allowBack(Map currentSettings)
        throws FieldValidationException;
    public void initPage(Map settings);
    public Properties getPageProperties();
    public void setPageProperties(Map settings);
    public JComponent getPageComponent();
    public Icon getPageIcon();
}
