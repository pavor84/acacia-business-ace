/*
 * JBPanel.java
 *
 * Created on Петък, 2006, Ноември 24, 8:24
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.cosmos.form;

import com.cosmos.util.ButtonBoxLayout;
import com.cosmos.util.PropertyAction;
import com.cosmos.util.ResourceBundleManager;
import com.cosmos.util.ResponseType;
import com.cosmos.util.UIResourceManager;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.LayoutManager;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JSeparator;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import org.jdesktop.swingx.JXPanel;

/**
 *
 * @author miro
 */
public class JBPanel
    extends JXPanel
{
    private Dialog.ModalityType modalityType = Dialog.ModalityType.APPLICATION_MODAL;
    private String formTitle;
    private String titleSuffix;
    private Object selectedValue;
    private Object[] selectedValues;
    private Action dialogSelectedAction;
    private List<Action> optionActions;
    private DialogPanel dialogPanel;
    private JBDialog dialog;
    private JBFrame frame;
    private String formName;
    private String formPrefix;
    private boolean formResizable;
    private ResponseType response;

    private ResourceBundle resourceBundle;


    public JBPanel(LayoutManager layout, boolean isDoubleBuffered)
    {
        super(layout, isDoubleBuffered);
    }

    public JBPanel(LayoutManager layout)
    {
        super(layout);
    }

    public JBPanel(boolean isDoubleBuffered)
    {
        super(isDoubleBuffered);
    }

    public JBPanel()
    {
        super();
    }

    public ResourceBundle getResourceBundle()
    {
        try
        {
            if(resourceBundle == null)
                return ResourceBundleManager.getResourceBundle();
        }
        catch(Exception ex)
        {
//            ex.printStackTrace();
        }

        if(resourceBundle == null)
        {
            resourceBundle = ResourceBundle.getBundle("com.cosmos.form.JBPanel");
        }

        return resourceBundle;
    }

    public Dialog.ModalityType getModalityType()
    {
        return modalityType;
    }

    public void setModalityType(Dialog.ModalityType modalityType)
    {
        this.modalityType = modalityType;
    }

    public String getFormName()
    {
        return formName;
    }

    public void setFormName(String formName)
    {
        this.formName = formName;
    }

    public String getFormPrefix()
    {
        if(formPrefix == null)
        {
            formPrefix = "form." + getFormName() + ".";
        }
        return formPrefix;
    }
    
    public void setFormPrefix(String formPrefix)
    {
        this.formPrefix = formPrefix;
    }

    public String getResourceString(String key, String defaultValue)
    {
        return UIResourceManager.getResourceString(key, defaultValue);
/*
        try
        {
            ResourceBundle rb = getResourceBundle();
            if(rb != null)
            {
                String value = rb.getString(key);
                if(value != null)
                    return value;
            }
        }
        catch(Exception ex)
        {
//            ex.printStackTrace();
        }

        return defaultValue;
 */
    }

    public String getResourceString(String suffixOrKey)
    {
        String value = UIResourceManager.getResourceString(getFormPrefix() + suffixOrKey);
        if(value != null)
            return value;
        return UIResourceManager.getResourceString(suffixOrKey);
/*
        ResourceBundle rb = null;
        try
        {
            rb = getResourceBundle();

            if(rb != null)
            {
                try
                {
                    if(formName != null)
                    {
                        String value = rb.getString(getFormPrefix() + suffixOrKey);
                        if(value != null)
                            return value;
                    }
                }
                catch(Exception ex) {}
                return rb.getString(suffixOrKey);
            }
        }
        catch(Exception ex) {}

        return null;
*/
    }

    protected String getResourceText(String key)
    {
        return getResourceText(key, null);
    }

    protected String getResourceText(String key, String defaultText)
    {
        String text = getResourceString(key + ".Text");
        if(text == null)
            return defaultText;
        return text;
    }

    public boolean isFormResizable()
    {
        return formResizable;
    }

    public void setFormResizable(boolean formResizable)
    {
        this.formResizable = formResizable;
    }

    public String getFormTitle()
    {
        if(formTitle == null)
        {
            formTitle =  getResourceText("Title");
        }
        return formTitle;
    }

    public void setFormTitle(String formTitle)
    {
        this.formTitle = formTitle;
    }

    public void setTitleSuffix(String titleSuffix)
    {
        this.titleSuffix = titleSuffix;
        setTitle(getTitle());
    }

    public String getTitleSuffix()
    {
        return titleSuffix;
    }

    private String getTitle()
    {
        String title = getFormTitle();
        String titleSuffix = getTitleSuffix();
        if(title == null && titleSuffix == null)
            return "";

        if(titleSuffix != null && title != null)
        {
            int size = title.length() + titleSuffix.length() + 2;
            StringBuilder sb = new StringBuilder(size);
            sb.append(title).append(": ").append(titleSuffix);
            return sb.toString();
        }

        if(title != null)
            return title;
        else
            return titleSuffix;
    }

    private void setTitle(String title)
    {
        if(frame != null)
        {
            frame.setTitle(title);
        }
        if(dialog != null)
        {
            dialog.setTitle(title);
        }
    }

    private Window getWindow()
    {
        if(frame != null)
        {
            return frame;
        }
        if(dialog != null)
        {
            return dialog;
        }
        return null;
    }

    protected void setWindowVisible(boolean visible)
    {
        Window win = getWindow();
        if(win != null)
            win.setVisible(visible);
    }

    public List<Action> getOptionActions()
    {
        return optionActions;
    }

    public void setOptionActions(Action ... optionActions)
    {
        setOptionActions(Arrays.<Action>asList(optionActions));
    }

    public void setOptionActions(List<Action> optionActions)
    {
        this.optionActions = new ArrayList(optionActions);
    }

    public Object getSelectedValue()
    {
        return selectedValue;
    }

    protected void setSelectedValue(Object selectedValue)
    {
        this.selectedValue = selectedValue;
    }

    public Object[] getSelectedValues()
    {
        return selectedValues;
    }

    protected void setSelectedValues(Object[] selectedValues)
    {
        int size;
        if(selectedValues != null && (size = selectedValues.length) > 0)
        {
            this.selectedValues = new Object[size];
            System.arraycopy(selectedValues, 0, this.selectedValues, 0, size);
        }
        else
            this.selectedValues = selectedValues;
    }

    public Action getDialogSelectedAction()
    {
        return dialogSelectedAction;
    }

    protected void setDialogSelectedAction(Action dialogSelectedAction)
    {
        this.dialogSelectedAction = dialogSelectedAction;
    }

    public ResponseType getDialogResponse()
    {
        return response;
    }

    public JBDialog getDialog()
    {
        return dialog;
    }

    public void showForm(Component parentComponent)
    {
        frame = new JBFrame();
        frame.setDefaultCloseOperation(JBFrame.DISPOSE_ON_CLOSE);
        frame.setTitle(getTitle());
        frame.getContentPane().add(this);
        frame.pack();
        frame.setMinimumSize(frame.getPreferredSize());
        frame.setLocationRelativeTo(parentComponent);
        frame.setResizable(isFormResizable());
        frame.addWindowListener(new WindowAdapter()
        {
            public void windowClosed(WindowEvent event)
            {
                frame = null;
            }
        });
        frame.setVisible(true);
    }

    public ResponseType showDialog(Component parentComponent)
    {
        selectedValue = null;
        selectedValues = null;
        dialogSelectedAction = null;
        response = null;

        Window window = null;
        if(parentComponent != null)
            window = SwingUtilities.getWindowAncestor(parentComponent);
        dialog = new JBDialog(window, getTitle());

        dialogPanel = new DialogPanel(this, dialog);

        Container contentPane = dialog.getContentPane();
        contentPane.removeAll();
        contentPane.add(dialogPanel, BorderLayout.CENTER);

        Dialog.ModalityType modalityType = getModalityType();
        if(modalityType != null)
        {
            dialog.setModalityType(modalityType);
        }

        dialog.pack();
        dialog.setMinimumSize(dialog.getPreferredSize());
        dialog.setMaximumSize(getMaximumSize());
        dialog.setLocationRelativeTo(parentComponent);
        dialog.setResizable(isFormResizable());

        dialog.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        dialog.addWindowListener(new DialogWindowAdapter());

        dialog.setVisible(true);
        dialog.dispose();
        dialog = null;

        Action action = getDialogSelectedAction();
        if(action != null)
        {
            response = (ResponseType)action.getValue(PropertyAction.RESOURCE_RESPONSE_TYPE);
            if(response != null)
                return response;
        }

        response = ResponseType.CLOSE;
        return response;
    }

    public DialogPanel getDialogPanel()
    {
        return dialogPanel;
    }

    public List<JButton> getOptionButtonList()
    {
        DialogPanel dialogPanel = getDialogPanel();
        if(dialogPanel != null)
        {
            JBPanel buttonPanel = dialogPanel.getButtonPanel();
            if(buttonPanel != null)
            {
                Component[] comps = buttonPanel.getComponents();
                if(comps != null && comps.length > 0)
                {
                    ArrayList<JButton> buttons = new ArrayList<JButton>(comps.length);
                    for(Component comp : comps)
                    {
                        if(comp instanceof JButton)
                        {
                            buttons.add((JButton)comp);
                        }
                    }
                    return buttons;
                }
            }
        }

        return Collections.<JButton>emptyList();
    }

    public Map<String, JButton> getOptionButtonMap()
    {
        DialogPanel dialogPanel = getDialogPanel();
        if(dialogPanel != null)
        {
            JBPanel buttonPanel = dialogPanel.getButtonPanel();
            if(buttonPanel != null)
            {
                Component[] comps = buttonPanel.getComponents();
                if(comps != null && comps.length > 0)
                {
                    TreeMap<String, JButton> buttons = new TreeMap<String, JButton>();
                    for(Component comp : comps)
                    {
                        if(comp instanceof JButton)
                        {
                            JButton button = (JButton)comp;
                            String name = null;
                            Action action = button.getAction();
                            if(action != null)
                            {
                                name = (String)action.getValue(Action.NAME);
                            }
                            if(name == null)
                            {
                                name = button.getText();
                            }
                            if(name != null)
                            {
                                buttons.put(name, button);
                            }
                        }
                    }
                    return buttons;
                }
            }
        }

        return Collections.<String, JButton>emptyMap();
    }


    public class DialogPanel
        extends JBPanel
    {
        private List<Action> optionActions;
        private JBPanel contentPanel;
        private JBPanel buttonPanel;
        private JDialog dialog;

        public DialogPanel(JBPanel contentPanel, JDialog dialog)
        {
            super(new BorderLayout());
            this.contentPanel = contentPanel;
            this.dialog = dialog;
            optionActions = contentPanel.getOptionActions();

            initComponents();
        }

        private void initComponents()
        {
            add(contentPanel, BorderLayout.CENTER);
            if(contentPanel.getBorder() == null)
            {
                contentPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
            }

            if(optionActions == null || optionActions.isEmpty())
                return;

            buttonPanel = new JBPanel(new ButtonBoxLayout());
            buttonPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

            JSeparator separator = new JSeparator();
            JBPanel separatorPanel = new JBPanel(new BorderLayout());
            separatorPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
            separatorPanel.add(separator, BorderLayout.PAGE_START);
            separatorPanel.add(buttonPanel, BorderLayout.CENTER);
            add(separatorPanel, BorderLayout.PAGE_END);

            if(optionActions != null && optionActions.size() > 0)
            {
                for(Action action : optionActions)
                {
                    if(action != null)
                    {
                        JButton button = new JButton(action);
                        buttonPanel.add(button);
                    }
                }
            }
        }

        public JBPanel getButtonPanel()
        {
            return buttonPanel;
        }
    }

    private final static String[] ACTION_LIST =
    {
        Action.NAME,
        Action.SHORT_DESCRIPTION,
        Action.LONG_DESCRIPTION,
        Action.ACTION_COMMAND_KEY,
        Action.ACCELERATOR_KEY,
        Action.MNEMONIC_KEY,
        Action.DISPLAYED_MNEMONIC_INDEX_KEY,
        Action.SMALL_ICON,
        Action.LARGE_ICON_KEY,
        Action.SELECTED_KEY,
        PropertyAction.RESOURCE_ACTION_NAME,
        PropertyAction.RESOURCE_RESPONSE_TYPE,
    };


    private CancelAction cancelAction;
    private CloseAction closeAction;
    private OkAction okAction;
    private YesAction yesAction;
    private NoAction noAction;
    private LoginAction loginAction;
    private UsernameAction usernameAction;
    private PasswordAction passwordAction;
    private AddFileAction addFileAction;
    private RemoveFileAction removeFileAction;
    private PreviewFileAction previewFileAction;

    public Action getCancelAction()
    {
        if(cancelAction == null)
        {
            cancelAction = new CancelAction();
        }
        return cancelAction;
    }

    public Action getCloseAction()
    {
        if(closeAction == null)
        {
            closeAction = new CloseAction();
        }
        return closeAction;
    }

    public Action getOkAction()
    {
        if(okAction == null)
        {
            okAction = new OkAction();
        }
        return okAction;
    }

    public Action getYesAction()
    {
        if(yesAction == null)
        {
            yesAction = new YesAction();
        }
        return yesAction;
    }

    public Action getNoAction()
    {
        if(noAction == null)
        {
            noAction = new NoAction();
        }
        return noAction;
    }

    public Action getLoginAction()
    {
        if(loginAction == null)
        {
            loginAction = new LoginAction();
        }
        return loginAction;
    }

    public Action getUsernameAction()
    {
        if(usernameAction == null)
        {
            usernameAction = new UsernameAction();
        }
        return usernameAction;
    }

    public Action getPasswordAction()
    {
        if(passwordAction == null)
        {
            passwordAction = new PasswordAction();
        }
        return passwordAction;
    }

    public Action getAddFileAction()
    {
        if(addFileAction == null)
        {
            addFileAction = new AddFileAction();
        }
        return addFileAction;
    }

    public Action getRemoveFileAction()
    {
        if(removeFileAction == null)
        {
            removeFileAction = new RemoveFileAction();
        }
        return removeFileAction;
    }

    public Action getPreviewFileAction()
    {
        if(previewFileAction == null)
        {
            previewFileAction = new PreviewFileAction();
        }
        return previewFileAction;
    }

    public void closeActionPerformed(ActionEvent event) {}
    public void cancelActionPerformed(ActionEvent event) {}
    public void okActionPerformed(ActionEvent event) {}
    public void yesActionPerformed(ActionEvent event) {}
    public void noActionPerformed(ActionEvent event) {}
    public void loginActionPerformed(ActionEvent event) {}
    public void usernameActionPerformed(ActionEvent event) {}
    public void passwordActionPerformed(ActionEvent event) {}
    public void addFileActionPerformed(ActionEvent event) {}
    public void removeFileActionPerformed(ActionEvent event) {}
    public void previewFileActionPerformed(ActionEvent event) {}


    private class CancelAction
        extends PropertyAction
    {
        public CancelAction()
        {
            super(ResponseType.CANCEL, getResourceBundle());
        }

        public void actionPerformed(ActionEvent event)
        {
            SmartActionEvent smartEvent = new SmartActionEvent(event);
            cancelActionPerformed(smartEvent);
            if(smartEvent.isExitFromDialog())
            {
                setDialogSelectedAction(CancelAction.this);
                setWindowVisible(false);
            }
        }
    }

    private class CloseAction
        extends PropertyAction
    {
        public CloseAction()
        {
            super(ResponseType.CLOSE, getResourceBundle());
        }

        public void actionPerformed(ActionEvent event)
        {
            SmartActionEvent smartEvent = new SmartActionEvent(event);
            closeActionPerformed(smartEvent);
            if(smartEvent.isExitFromDialog())
            {
                setDialogSelectedAction(CloseAction.this);
                setWindowVisible(false);
            }
        }
    }

    private class OkAction
        extends PropertyAction
    {
        public OkAction()
        {
            super(ResponseType.OK, getResourceBundle());
        }

        public void actionPerformed(ActionEvent event)
        {
            SmartActionEvent smartEvent = new SmartActionEvent(event);
            okActionPerformed(smartEvent);
            if(smartEvent.isExitFromDialog())
            {
                setDialogSelectedAction(OkAction.this);
                setWindowVisible(false);
            }
        }
    }

    private class YesAction
        extends PropertyAction
    {
        public YesAction()
        {
            super(ResponseType.YES, getResourceBundle());
        }

        public void actionPerformed(ActionEvent event)
        {
            SmartActionEvent smartEvent = new SmartActionEvent(event);
            yesActionPerformed(smartEvent);
            if(smartEvent.isExitFromDialog())
            {
                setDialogSelectedAction(YesAction.this);
                setWindowVisible(false);
            }
        }
    }

    private class NoAction
        extends PropertyAction
    {
        public NoAction()
        {
            super(ResponseType.NO, getResourceBundle());
        }

        public void actionPerformed(ActionEvent event)
        {
            SmartActionEvent smartEvent = new SmartActionEvent(event);
            noActionPerformed(smartEvent);
            if(smartEvent.isExitFromDialog())
            {
                setDialogSelectedAction(NoAction.this);
                setWindowVisible(false);
            }
        }
    }

    private class LoginAction
        extends PropertyAction
    {
        public LoginAction()
        {
            super(ResponseType.LOGIN, getResourceBundle());
        }

        public void actionPerformed(ActionEvent event)
        {
            SmartActionEvent smartEvent = new SmartActionEvent(event);
            loginActionPerformed(smartEvent);
            if(smartEvent.isExitFromDialog())
            {
                setDialogSelectedAction(LoginAction.this);
                setWindowVisible(false);
            }
        }
    }

    private class UsernameAction
        extends PropertyAction
    {
        public UsernameAction()
        {
            super(ResponseType.USERNAME, getResourceBundle());
        }

        public void actionPerformed(ActionEvent event)
        {
            SmartActionEvent smartEvent = new SmartActionEvent(event);
            usernameActionPerformed(smartEvent);
            if(smartEvent.isExitFromDialog())
            {
                setDialogSelectedAction(UsernameAction.this);
                setWindowVisible(false);
            }
        }
    }

    private class PasswordAction
        extends PropertyAction
    {
        public PasswordAction()
        {
            super(ResponseType.PASSWORD, getResourceBundle());
        }

        public void actionPerformed(ActionEvent event)
        {
            SmartActionEvent smartEvent = new SmartActionEvent(event);
            passwordActionPerformed(smartEvent);
            if(smartEvent.isExitFromDialog())
            {
                setDialogSelectedAction(PasswordAction.this);
                setWindowVisible(false);
            }
        }
    }

    private class AddFileAction
        extends PropertyAction
    {
        public AddFileAction()
        {
            super(ResponseType.ADD_FILE, getResourceBundle());
        }

        public void actionPerformed(ActionEvent event)
        {
            SmartActionEvent smartEvent = new SmartActionEvent(event);
            addFileActionPerformed(smartEvent);
            if(smartEvent.isExitFromDialog())
            {
                setDialogSelectedAction(AddFileAction.this);
                setWindowVisible(false);
            }
        }
    }

    private class RemoveFileAction
        extends PropertyAction
    {
        public RemoveFileAction()
        {
            super(ResponseType.REMOVE_FILE, getResourceBundle());
        }

        public void actionPerformed(ActionEvent event)
        {
            SmartActionEvent smartEvent = new SmartActionEvent(event);
            removeFileActionPerformed(smartEvent);
            if(smartEvent.isExitFromDialog())
            {
                setDialogSelectedAction(RemoveFileAction.this);
                setWindowVisible(false);
            }
        }
    }

    private class PreviewFileAction
        extends PropertyAction
    {
        public PreviewFileAction()
        {
            super(ResponseType.PREVIEW_FILE, getResourceBundle());
        }

        public void actionPerformed(ActionEvent event)
        {
            SmartActionEvent smartEvent = new SmartActionEvent(event);
            previewFileActionPerformed(smartEvent);
            if(smartEvent.isExitFromDialog())
            {
                setDialogSelectedAction(PreviewFileAction.this);
                setWindowVisible(false);
            }
        }
    }


    protected void dialogWindowClosing(WindowEvent event)
    {
        JDialog dialog = (JDialog)event.getSource();
        if(getDialogSelectedAction() == null)
            setDialogSelectedAction(getCloseAction());
        dialog.setVisible(false);
    }

    private class DialogWindowAdapter
        extends WindowAdapter
    {
        public void windowClosing(WindowEvent event)
        {
            dialogWindowClosing(event);
        }
    }


}
