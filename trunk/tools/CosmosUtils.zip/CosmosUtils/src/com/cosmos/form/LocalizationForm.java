/*
 * LocalizationForm.java
 *
 * Created on Неделя, 2006, Декември 3, 16:35
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.cosmos.form;

import javax.swing.Action;

/**
 *
 * @author miro
 */
public class LocalizationForm
    extends LocalePanel
{
    
    /** Creates a new instance of LocalizationForm */
    public LocalizationForm()
    {
        super();
    }

/*
    public static void main(String[] args)
    {
        LoginForm.init();

        LocalizationForm form = new LocalizationForm();
        Action action = form.showDialog(null);
        System.out.println("action: " + action + ", Name: " + action.getValue(Action.NAME) + ", CommandKey: " + action.getValue(Action.ACTION_COMMAND_KEY));
        System.exit(0);
    }
*/
}
