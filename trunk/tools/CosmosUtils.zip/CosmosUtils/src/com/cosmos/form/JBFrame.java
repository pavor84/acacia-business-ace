/*
 * JBFrame.java
 *
 * Created on Петък, 2006, Ноември 24, 8:36
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.cosmos.form;

import com.cosmos.util.BeanUtil;
import com.cosmos.util.PropertyAction;
import com.cosmos.util.ResourceBundleManager;
import com.cosmos.util.UISwitchListener;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;
import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JToolBar;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import org.jdesktop.swingx.JXFrame;

/**
 *
 * @author miro
 */
public class JBFrame
//    extends javax.swing.JFrame
    extends JXFrame
{
    private Map<String, Action> actionsMap;
    private String applicationName;
    
    public JBFrame()
        throws HeadlessException
    {
        super();
        init();
    }

    public JBFrame(String title)
        throws HeadlessException
    {
        super(title);
        init();
    }

    public JBFrame(String title, boolean exitOnClose)
    {
//        super(title);
//        if(exitOnClose)
//        {
//            setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
//        }
        super(title, exitOnClose);
        init();
    }

    private void init()
    {
        addWindowListener(new ApplicationWindowHandler());
        UIManager.addPropertyChangeListener(new UISwitchListener((JComponent)getRootPane()));
    }

    protected void prepareApplication()
    {
        try
        {
            ResourceBundle rb = getResourceBundle();
            if(rb != null)
            {
                try
                {
                    ImageIcon icon = (ImageIcon)getResourceBundle().getObject("icon.SystemLogo.Small");
                    if(icon != null)
                    {
                        setIconImage(icon.getImage());
                    }
                }
                catch(Exception ex1) {}

                try
                {
                    String applicationName = getApplicationName();
                    if(applicationName != null && (applicationName = applicationName.trim()).length() > 0)
                    {
                        String title = rb.getString("application." + applicationName + ".Title");
                        if(title != null)
                        {
                            setTitle(title);
                        }
                    }
                }
                catch(Exception ex1) {}
            }
        }
        catch(Exception ex) {}
    }

    public void setVisible(boolean visible)
    {
        prepareApplication();
        super.setVisible(visible);
    }

    public ResourceBundle getResourceBundle()
    {
        return ResourceBundleManager.getResourceBundle();
    }

    public String getApplicationName()
    {
        return applicationName;
    }

    public void setApplicationName(String applicationName)
    {
        this.applicationName = applicationName;
    }

    public void setMenuBar(Action[] actions)
    {
        if(actions != null && actions.length > 0)
            setMenuBar(Arrays.<Action>asList(actions));
    }

    public void setMenuBar(List<Action> actions)
    {
        if(actions != null && actions.size() > 0)
        {
            Map<String, Action> actionsMap = new TreeMap<String, Action>();
            for(Action action : actions)
            {
                if(action != null)
                {
                    String actionName = (String)action.getValue(PropertyAction.RESOURCE_ACTION_NAME);
                    if(actionName == null)
                        actionName = (String)action.getValue(Action.NAME);
                    actionsMap.put(actionName, action);
                }
            }
            setMenuBar(actionsMap);
        }
    }

    protected void setMenuBar(Map<String, Action> actionsMap)
    {
        if(this.actionsMap == null)
            this.actionsMap = actionsMap;
        JMenuBar menuBar = createMenuBar(actionsMap);
        if(menuBar != null)
        {
            setJMenuBar(menuBar);
        }
    }

    protected JMenuBar createMenuBar(Map<String, Action> actionsMap)
    {
        String menuBarMenus = getPropertyString("menuBar");
        if(menuBarMenus != null)
        {
            JMenuBar menuBar = new JMenuBar();
            List<JMenu> menus = getMenus(menuBarMenus, actionsMap);
            if(menus != null && menus.size() > 0)
            {
                for(JMenu menu : menus)
                {
                    menuBar.add(menu);
                }
            }

            return menuBar;
        }

        return null;
    }

    protected List<JMenu> getMenus(String menuList, Map<String, Action> actionsMap)
    {
        if(menuList != null && (menuList = menuList.trim()).length() > 0)
        {
            String[] menuKeys = menuList.split(",");
            List<JMenu> menus = new ArrayList<JMenu>(menuKeys.length);
            for(String menuKey : menuKeys)
            {
                menuKey = menuKey.trim();
                String propertyPrefix = "menu." + menuKey + ".";
                String menuActionList = getPropertyString(propertyPrefix + "Actions");
                if(menuActionList == null || (menuActionList = menuActionList.trim()).length() <= 0)
                    continue;
                List<Action> actionList = getActions(menuActionList, actionsMap);
                if(actionList == null || actionList.size() <= 0)
                    continue;

                String menuTitle = getPropertyString(propertyPrefix + "Title");
                if(menuTitle == null)
                    menuTitle = menuKey;

                JMenu menu = new JMenu(menuTitle);
                addActions(menu, actionList);
                menus.add(menu);
            }

            return menus;
        }

        return Collections.<JMenu>emptyList();
    }

    public void setToolBarPanel(Action[] actions)
    {
        if(actions != null && actions.length > 0)
            setToolBarPanel(Arrays.<Action>asList(actions));
    }

    public void setToolBarPanel(List<Action> actions)
    {
        if(actions != null && actions.size() > 0)
        {
            Map<String, Action> actionsMap = new TreeMap<String, Action>();
            for(Action action : actions)
            {
                if(action != null)
                {
                    String actionName = (String)action.getValue(PropertyAction.RESOURCE_ACTION_NAME);
                    if(actionName == null)
                        actionName = (String)action.getValue(Action.NAME);
                    actionsMap.put(actionName, action);
                }
            }
            setToolBarPanel(actionsMap);
        }
    }

    protected void setToolBarPanel(Map<String, Action> actionsMap)
    {
        if(this.actionsMap == null)
            this.actionsMap = actionsMap;
        JBPanel panel = createToolBarPanel(actionsMap);
        if(panel != null)
        {
            setToolBarPanel(panel);
        }
    }

    public void setToolBarPanel(JBPanel panel)
    {
        if(panel != null)
        {
            LayoutManager layout = getContentPane().getLayout();
            if(layout == null || !(layout instanceof BorderLayout))
            {
                getContentPane().setLayout(new BorderLayout());
            }
            getContentPane().add(panel, BorderLayout.PAGE_START);
        }
    }

    public void setMainPanel(JBPanel panel)
    {
        if(panel != null)
        {
            LayoutManager layout = getContentPane().getLayout();
            if(layout == null || !(layout instanceof BorderLayout))
            {
                getContentPane().setLayout(new BorderLayout());
            }
            getContentPane().add(panel, BorderLayout.CENTER);
        }
    }

    protected JBPanel createToolBarPanel(Map<String, Action> actionsMap)
    {
        String toolBarList = getPropertyString("toolBars");
        if(toolBarList != null)
        {
            FlowLayout layout = new FlowLayout(FlowLayout.LEFT);
            JBPanel toolBarPanel = new JBPanel(layout);
            List<JToolBar> toolBars = getToolBars(toolBarList, actionsMap);
            if(toolBars != null && toolBars.size() > 0)
            {
                for(JToolBar toolBar : toolBars)
                {
                    toolBarPanel.add(toolBar);
                }
            }

            return toolBarPanel;
        }

        return null;
    }

    protected List<JToolBar> getToolBars(String toolBarList, Map<String, Action> actionsMap)
    {
        if(toolBarList != null && (toolBarList = toolBarList.trim()).length() > 0)
        {
            String[] toolBarKeys = toolBarList.split(",");
            List<JToolBar> toolBars = new ArrayList<JToolBar>(toolBarKeys.length);
            for(String toolBarKey : toolBarKeys)
            {
                toolBarKey = toolBarKey.trim();
                String propertyPrefix = "toolBar." + toolBarKey + ".";
                String toolBarActionList = getPropertyString(propertyPrefix + "Actions");
                if(toolBarActionList == null || (toolBarActionList = toolBarActionList.trim()).length() <= 0)
                    continue;
                List<Action> actionList = getActions(toolBarActionList, actionsMap);
                if(actionList == null || actionList.size() <= 0)
                    continue;

                String toolBarTitle = getPropertyString(propertyPrefix + "Title");
                String toolBarOrientation = getPropertyString(propertyPrefix + "Orientation");
                if(toolBarTitle == null)
                    toolBarTitle = toolBarKey;
                if(toolBarOrientation == null)
                    toolBarOrientation = "HORIZONTAL";

                Object object = BeanUtil.getStaticFieldValue(JToolBar.class, toolBarOrientation);
                int orientation;
                if(object != null)
                    orientation = ((Integer)object).intValue();
                else
                    orientation = JToolBar.HORIZONTAL;
                JToolBar toolBar = new JToolBar(toolBarTitle, orientation);
                addActions(toolBar, actionList);
                toolBars.add(toolBar);
            }

            return toolBars;
        }

        return Collections.<JToolBar>emptyList();
    }

    protected List<Action> getActions(String actionNameList, Map<String, Action> actionsMap)
    {
        if(actionNameList != null && (actionNameList = actionNameList.trim()).length() > 0)
        {
            List<Action> actionList = new ArrayList<Action>(actionNameList.length());
            String[] actionNames = actionNameList.split(",");
            for(String actionName : actionNames)
            {
                if(actionName != null && (actionName = actionName.trim()).length() > 0)
                {
                    Action action = actionsMap.get(actionName);
                    if(action != null)
                        actionList.add(action);
                }
                else
                    actionList.add(null);
            }

            return actionList;
        }

        return Collections.<Action>emptyList();
    }

    protected String getPropertyString(String propertyName)
    {
        try
        {
            return getResourceBundle().getString(propertyName);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            return null;
        }
    }

    protected void addActions(JToolBar toolBar, Action[] actions)
    {
        addActions(toolBar, Arrays.<Action>asList(actions));
    }

    protected void addActions(JToolBar toolBar, List<Action> actions)
    {
        for(Action action : actions)
        {
            addAction(toolBar, action);
        }
    }

    protected JButton addAction(JToolBar toolBar, Action action)
    {
        if(action != null)
        {
            JButton button = toolBar.add(action);
            button.setText(null);
            button.setMargin(new Insets(0, 0, 0, 0));
            return button;
        }
        else
        {
            toolBar.addSeparator();
            return null;
        }
    }

    protected void addActions(JMenu menu, Action[] actions)
    {
        addActions(menu, Arrays.<Action>asList(actions));
    }

    protected void addActions(JMenu menu, List<Action> actions)
    {
        for(Action action : actions)
        {
            addAction(menu, action);
        }
    }

    protected JMenuItem addAction(JMenu menu, Action action)
    {
        if(action != null)
        {
            String actionName = (String)action.getValue(PropertyAction.RESOURCE_ACTION_NAME);
            if(actionName != null && "Customize".equals(actionName))
            {
                JMenu customizeMenu = getCustomizeMenu(action);
                menu.add(customizeMenu);
                return customizeMenu;
            }
            
            JMenuItem menuItem = menu.add(action);
            return menuItem;
        }
        else
        {
            menu.addSeparator();
            return null;
        }
    }

    protected JMenu getCustomizeMenu(Action customizeAction)
    {
        JMenu customizeMenu = new JMenu(customizeAction);

        Action action = actionsMap.get("LookAndFeel");
        if(action != null)
        {
            customizeMenu.add(getLookAndFeelMenu(action));
        }

        //action = new LanguageLocalizationActionHandler();
        //customizeMenu.add(action);
        action = actionsMap.get("LanguageLocalization");
        if(action != null)
        {
            customizeMenu.add(action);
        }

        return customizeMenu;
    }

    protected JMenu getLookAndFeelMenu(Action lookAndFeelAction)
    {
        JMenu lookAndFeelMenu = new JMenu(lookAndFeelAction);
        LookAndFeelActionHandler lafActionHandler = new LookAndFeelActionHandler();

        String currentLAF = UIManager.getLookAndFeel().getName();

        ButtonGroup group = new ButtonGroup();
        LookAndFeelInfo[] lafsInfo = UIManager.getInstalledLookAndFeels();
        for(LookAndFeelInfo lafInfo : lafsInfo)
        {
            String lafName = lafInfo.getName();
            lafMap.put(lafName, lafInfo);
            JRadioButtonMenuItem menuItem = new JRadioButtonMenuItem(lafName);
            menuItem.addActionListener(lafActionHandler);
            if(currentLAF.equals(lafName))
                menuItem.setSelected(true);
            lookAndFeelMenu.add(menuItem);
            group.add(menuItem);
        }

        return lookAndFeelMenu;
    }

    protected TreeMap<String, LookAndFeelInfo> lafMap = new TreeMap<String, LookAndFeelInfo>();

    protected class LookAndFeelActionHandler
        implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            String lafName = event.getActionCommand();
            if(!lafName.equals(UIManager.getLookAndFeel().getName()))
            {
                LookAndFeelInfo lafInfo = lafMap.get(lafName);
                try
                {
                    UIManager.setLookAndFeel(lafInfo.getClassName());
                }
                catch(Exception ex)
                {
                    ex.printStackTrace();
                }
            }
        }
    }

    /*protected class LanguageLocalizationActionHandler
        extends PropertyAction
    {
        public LanguageLocalizationActionHandler()
        {
            super("LanguageLocalization");
        }

        public void actionPerformed(ActionEvent event)
        {
            LocalizationForm form = new LocalizationForm()
            {
                public void okActionPerformed(ActionEvent event)
                {
                    Locale oldLocale = getResourceBundle().getLocale();
                    Locale newLocale = getSelectedLocale();
                    if(newLocale != null && !newLocale.equals(oldLocale))
                    {
                        ResourceBundleManager.resetResourceBundle();
                        Locale.setDefault(newLocale);
                        getResourceBundle().clearCache();
                        JBFrame frame = JBFrame.this;
                        SwingUtilities.updateComponentTreeUI(frame);
                        pack();
                        frame.invalidate();
                        frame.validate();
                        frame.repaint();
                    }
                }
            };
            form.showDialog(JBFrame.this);
        }
    }*/

    protected void applicationWindowClosed(WindowEvent event)
    {
    }

    private class ApplicationWindowHandler
        extends WindowAdapter
    {
        public void windowClosed(WindowEvent event)
        {
            applicationWindowClosed(event);
        }
    }

}
