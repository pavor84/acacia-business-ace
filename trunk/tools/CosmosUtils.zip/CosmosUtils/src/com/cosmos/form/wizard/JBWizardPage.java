package com.cosmos.form.wizard;

import com.cosmos.util.ResourceBundleManager;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.util.Collection;
import java.util.Collections;
import java.util.ResourceBundle;
import javax.swing.JWindow;
import org.netbeans.spi.wizard.Wizard;
import org.netbeans.spi.wizard.WizardPage;

/**
 *
 * @author miro
 */
public class JBWizardPage
    extends WizardPage
{
    private ResourceBundle resourceBundle;
    private String formName;
    private String formPrefix;
    private String formTitle;
    private String titleSuffix;


    public JBWizardPage()
    {
        super();
        init();
    }
    
    public JBWizardPage(String stepId, String stepDescription, boolean autoListen)
    {
        super(stepId, stepDescription, autoListen);
        init();
    }

    public JBWizardPage(String stepId, String stepDescription)
    {
        super(stepId, stepDescription);
        init();
    }

    protected JBWizardPage(boolean autoListen)
    {
        super(autoListen);
        init();
    }

    private void init()
    {
        setLayout(new BorderLayout());
    }

    public String getFormName()
    {
        if(formName != null)
            return formName;

        throw new RuntimeException("The method \"String getFormName()\" must be implemented.");
    }

    public void setFormName(String formName)
    {
        this.formName = formName;
    }

    public String getFormPrefix()
    {
        if(formPrefix == null)
        {
            formPrefix = "form." + getFormName() + ".";
        }
        return formPrefix;
    }
    
    public void setFormPrefix(String formPrefix)
    {
        this.formPrefix = formPrefix;
    }

    public ResourceBundle getResourceBundle()
    {
        try
        {
            return ResourceBundleManager.getResourceBundle();
        }
        catch(Exception ex)
        {
//            ex.printStackTrace();
        }

        if(resourceBundle == null)
        {
            resourceBundle = ResourceBundle.getBundle("com.cosmos.form.JBPanel");
        }

        return resourceBundle;
    }

    public String getResourceString(String key, String defaultValue)
    {
        try
        {
            ResourceBundle rb = getResourceBundle();
            if(rb != null)
            {
                String value = rb.getString(key);
                if(value != null)
                    return value;
            }
        }
        catch(Exception ex)
        {
//            ex.printStackTrace();
        }

        return defaultValue;
    }

    public String getResourceString(String suffixOrKey)
    {
        ResourceBundle rb = null;
        try
        {
            rb = getResourceBundle();

            if(rb != null)
            {
                try
                {
                    if(formName != null)
                        return rb.getString(getFormPrefix() + suffixOrKey);
                }
                catch(Exception ex)
                {
//                    ex.printStackTrace();
                }
                return rb.getString(suffixOrKey);
            }
        }
        catch(Exception ex)
        {
//            ex.printStackTrace();
        }

        return null;
    }

    protected String getResourceText(String key)
    {
        return getResourceText(key, null);
    }

    protected String getResourceText(String key, String defaultText)
    {
        String text = getResourceString(key + ".Text");
        if(text == null)
            return defaultText;
        return text;
    }

    public String getFormTitle()
    {
        if(formTitle == null)
        {
            formTitle =  getResourceText("Title");
        }
        return formTitle;
    }

    public void setFormTitle(String formTitle)
    {
        this.formTitle = formTitle;
    }

    public void setTitleSuffix(String titleSuffix)
    {
        this.titleSuffix = titleSuffix;
        setTitle(getTitle());
    }

    public String getTitleSuffix()
    {
        return titleSuffix;
    }

    private String getTitle()
    {
        String title = getFormTitle();
        String titleSuffix = getTitleSuffix();
        if(title == null && titleSuffix == null)
            return "";

        if(titleSuffix != null && title != null)
        {
            int size = title.length() + titleSuffix.length() + 2;
            StringBuilder sb = new StringBuilder(size);
            sb.append(title).append(": ").append(titleSuffix);
            return sb.toString();
        }

        if(title != null)
            return title;
        else
            return titleSuffix;
    }

    private void setTitle(String title)
    {
/*
        if(frame != null)
        {
            frame.setTitle(title);
        }
        if(dialog != null)
        {
            dialog.setTitle(title);
        }
 */
    }


    public void setComponent(Component component)
    {
        add(component, BorderLayout.CENTER);
    }

    public Component getComponent()
    {
        return getComponent(0);
    }

    public static Wizard createWizard(String title,
                                      Collection<JBWizardPage> contents,
                                      WizardResultProducer finisher)
    {
        JBWizardPage[] pages;
        int size;
        if(contents != null && (size = contents.size()) > 0)
            pages = new JBWizardPage[size];
        else
            pages = new JBWizardPage[0];
        return createWizard(title, contents.toArray(pages), finisher);
    }

    public static Wizard createWizard(String title,
                                      JBWizardPage[] contents,
                                      WizardResultProducer finisher)
    {
        prepareContents(contents);
        return WizardPage.createWizard(title, contents, finisher);
    }

    public static Wizard createWizard(String title,
                                      JBWizardPage[] contents)
    {
        prepareContents(contents);
        return WizardPage.createWizard(title, contents);
    }

    private static void prepareContents(JBWizardPage[] contents)
    {
        Dimension minSize = computeMinimumSize(contents);
        for(JBWizardPage wizardPage : contents)
        {
            wizardPage.setMinimumSize(minSize);
            wizardPage.setPreferredSize(minSize);
        }
    }

    private static Dimension computeMinimumSize(Component[] contents)
    {
        JWindow window = new JWindow();
        Dimension winSize = null;
        int height = 0;
        int width = 0;

        for(Component comp : contents)
        {
            window.add(comp);
            window.pack();
            winSize = window.getPreferredSize();
            window.remove(comp);
            int size;
            if((size = winSize.height) > height)
                height = size;
            if((size = winSize.width) > width)
                width = size;
        }

        window.dispose();
        window = null;

        return new Dimension(width, height);
    }

}
