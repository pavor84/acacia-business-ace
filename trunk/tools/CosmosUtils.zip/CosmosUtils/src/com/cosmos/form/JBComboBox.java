package com.cosmos.form;

import com.cosmos.bean.BeanComboBoxModel;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;

/**
 *
 * @author miro
 */
public class JBComboBox
    extends JComboBox
{
    
    public JBComboBox(BeanComboBoxModel aModel)
    {
        super(aModel);
    }

    public JBComboBox(Object ... items)
    {
        this(new BeanComboBoxModel(items));
    }
    
    public JBComboBox(Collection<?> collection)
    {
        this(new BeanComboBoxModel(collection));
    }

    public JBComboBox()
    {
        this(new BeanComboBoxModel());
    }

    public void setData(Collection<?> collection)
    {
        setData(collection, null);
    }
  
    public void setData(Collection<?> collection, Object selectedItem)
    {
        BeanComboBoxModel model = (BeanComboBoxModel)getModel();
        if(model != null)
            model.setData(collection, selectedItem);
    }

    public void addData(Collection<?> collection)
    {
        BeanComboBoxModel model = (BeanComboBoxModel)getModel();
        if(model != null)
            model.addData(collection);
    }
    
    public void addData(int atIndex, Collection<?> collection)
    {
        BeanComboBoxModel model = (BeanComboBoxModel)getModel();
        if(model != null)
            model.addData(atIndex, collection);
    }

    public List getData()
    {
        BeanComboBoxModel model = (BeanComboBoxModel)getModel();
        if(model != null)
            return model.getData();

        return Collections.emptyList();
    }

    public void setModel(ComboBoxModel aModel)
    {
        if(aModel != null)
        {
            if(!(aModel instanceof BeanComboBoxModel))
            {
                int size;
                if((size = aModel.getSize()) > 0)
                {
                    ArrayList data = new ArrayList(size);
                    for(int i = 0; i < size; i++)
                    {
                        data.add(aModel.getElementAt(i));
                    }
                    aModel = new BeanComboBoxModel(data);
                }
                else
                {
                    aModel = new BeanComboBoxModel();
                }
            }
        }
        else
        {
            aModel = new BeanComboBoxModel();
        }

        super.setModel(aModel);
    }
}
