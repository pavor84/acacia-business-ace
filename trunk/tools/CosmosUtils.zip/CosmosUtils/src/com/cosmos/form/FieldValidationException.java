package com.cosmos.form;

import java.awt.Component;

/**
 *
 * @author miro
 */
public class FieldValidationException
    extends Exception
{
    private Component field;
    private String fieldName;

    public FieldValidationException(Component field,
                                    String fieldName,
                                    String message,
                                    Throwable cause)
    {
        super(message, cause);
        this.field = field;
        this.fieldName = fieldName;
    }

    public FieldValidationException(Component field,
                                    String fieldName,
                                    String message)
    {
        super(message);
        this.field = field;
        this.fieldName = fieldName;
    }

    public Component getField()
    {
        return field;
    }

    public String getFieldName()
    {
        return fieldName;
    }
}
