package com.cosmos.form;

import java.awt.event.ActionEvent;

/**
 *
 * @author miro
 */
public class SmartActionEvent
    extends ActionEvent
{
    private boolean exitFromDialog;

    public SmartActionEvent(ActionEvent parent)
    {
        this(parent, true);
    }

    public SmartActionEvent(ActionEvent parent, boolean exitFromDialog)
    {
        super(parent.getSource(),
              parent.getID(),
              parent.getActionCommand(),
              parent.getWhen(),
              parent.getModifiers());
        this.exitFromDialog = exitFromDialog;
    }

    public boolean isExitFromDialog()
    {
        return exitFromDialog;
    }

    public void setExitFromDialog(boolean exitFromDialog)
    {
        this.exitFromDialog = exitFromDialog;
    }
}
