package com.cosmos.bean.table;

import java.util.ResourceBundle;
import javax.swing.table.TableModel;
import org.jdesktop.swingx.table.ColumnFactory;
import org.jdesktop.swingx.table.TableColumnExt;

/**
 *
 * @author miro
 */
public class BeanColumnFactory
    extends ColumnFactory
{
    private static int counter = 0;
    public void configureTableColumn(TableModel model, TableColumnExt columnExt)
    {
        if(model instanceof BeanTableModel)
        {
            BeanTableModel tableModel = (BeanTableModel)model;
            BeanTableColumn column = tableModel.getColumn(columnExt.getModelIndex());
            String title = column.getTitle();
            ResourceBundle rb = null;
            try
            {
                rb = tableModel.getResourceBundle();
            }
            catch(Exception ex)
            {
                //ex.printStackTrace();
            }
            if(rb != null)
            {
                String value = getPropertyValue(rb, column.getColumnName(), "Title");
                if(value != null)
                {
                    title = value;
                    column.setTitle(value);
                    columnExt.setTitle(value);
                }
            }
            columnExt.setHeaderValue(title);
            columnExt.setVisible(column.isVisible());
            columnExt.setEditable(column.isEditable());
            columnExt.setWidth(column.getWidth());
            columnExt.setPrototypeValue(column.getPrototypeValue());
        }
    }

    protected String getPropertyValue(ResourceBundle rb, String key, String subKey)
    {
        try
        {
            if(rb != null && key != null)
            {
                return rb.getString("tableColumn." + key + "." + subKey);
            }
        }
        catch(Exception ex) {}
        return null;
    }
}
