package com.cosmos.bean.table;

import com.cosmos.util.BeanUtil;
import com.cosmos.util.ResourceBundleManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.ResourceBundle;
import java.util.TreeMap;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author miro
 */
public class BeanTableModel<T>
    extends AbstractTableModel
{
    private boolean debug = false;

    protected ArrayList<T> dataHolder = new ArrayList<T>();
    protected ArrayList<BeanTableColumn> columnHolder = new ArrayList<BeanTableColumn>();
    protected TreeMap<String, Integer> columnIdentifiers;

    public BeanTableModel(Collection<T> data,
                          Collection<BeanTableColumn> columns)
    {
        dataHolder.addAll(data);
        columnHolder.addAll(columns);
        setColumnIdentifiers();
    }

    public BeanTableModel(BeanTableColumn ... columns)
    {
        this(Arrays.<BeanTableColumn>asList(columns));
    }

    public BeanTableModel(Collection<BeanTableColumn> columns)
    {
        columnHolder.addAll(columns);
        setColumnIdentifiers();
    }

    public BeanTableModel()
    {
    }

    public int getRowCount()
    {
        if(dataHolder != null)
            return dataHolder.size();

        return 0;
    }
  
    public int getColumnCount()
    {
        if(columnHolder != null)
            return columnHolder.size();

        return 0;
    }

    public Object getValueAt(int rowIndex, int columnIndex)
    {
        if(debug)
        {
//            System.out.println("BeanTableModel.getValueAt(" + rowIndex + ", " + columnIndex + ")");
        }
        Object bean = getRow(rowIndex);
        if(debug)
        {
//            System.out.println("BeanTableModel.getValueAt().rowValue: " + bean);
        }
        if(bean != null)
        {
            String propertyName = columnHolder.get(columnIndex).getPropertyName();
            if(debug)
            {
//                System.out.println("BeanTableModel.getValueAt().propertyName: " + propertyName);
            }
            Object value = BeanUtil.getPropertyValue(bean, propertyName);
            if(debug)
            {
//                System.out.println("BeanTableModel.getValueAt().value: " + value);
            }
            return value;
        }

        return null;
    }

    public void setValueAt(Object aValue, int rowIndex, int columnIndex)
    {
        if(debug)
        {
            System.out.println("BeanTableModel.setValueAt(" + rowIndex + ", " + columnIndex + ")");
        }
        Object bean = getRow(rowIndex);
        if(debug)
        {
            System.out.println("BeanTableModel.setValueAt().rowValue: " + bean);
        }
        if(bean != null)
        {
            String propertyName = columnHolder.get(columnIndex).getPropertyName();
            BeanUtil.setPropertyValue(bean, propertyName, aValue);
            fireTableCellUpdated(rowIndex, columnIndex);
        }
    }

    public Object getRow(int rowIndex)
    {
        if(debug)
        {
            System.out.println("BeanTableModel.getRow(" + rowIndex + ")");
        }
        if(dataHolder != null && rowIndex >= 0 && rowIndex < dataHolder.size())
        {
            Object rowValue = dataHolder.get(rowIndex);
            if(debug)
            {
                System.out.println("BeanTableModel.getRow().rowValue: " + rowValue);
            }

            return rowValue;
        }

        return null;
    }

    public int getRowIndex(T bean)
    {
        if(dataHolder != null && dataHolder.size() > 0)
        {
            return dataHolder.indexOf(bean);
        }

        return -1;
    }

    public synchronized int addRow(T bean)
    {
        int newRowIndex = getRowCount();
        insertRow(newRowIndex, bean);
        return newRowIndex;
    }

    public void setRow(int rowIndex, T bean)
    {
        if(debug)
        {
            System.out.println("BeanTableModel.setRow(" + rowIndex + ", " + bean + ")");
        }
        if(bean != null && dataHolder != null && rowIndex >= 0 && rowIndex < dataHolder.size())
        {
            dataHolder.set(rowIndex, bean);
            fireTableRowsUpdated(rowIndex, rowIndex);
        }
    }

    public void insertRow(int rowIndex, T bean)
    {
        dataHolder.add(rowIndex, bean);
        fireTableRowsInserted(rowIndex, rowIndex);
    }

    public void newRow()
    {
        // ToDo
    }

    public T removeRow(int rowIndex)
    {
        if(debug)
        {
            System.out.println("BeanTableModel.removeRow(" + rowIndex + ")");
        }
        T rowValue = dataHolder.remove(rowIndex);
        if(debug)
        {
            System.out.println("BeanTableModel.removeRow().removedRow: " + rowValue);
        }
        fireTableRowsDeleted(rowIndex, rowIndex);
        return rowValue;
    }

    public Class<?> getColumnClass(int columnIndex)
    {
        BeanTableColumn BeanTableColumn = null;

        if(columnIndex < columnHolder.size() && (columnIndex >= 0))
        {
            BeanTableColumn = columnHolder.get(columnIndex); 
        }

        if(BeanTableColumn != null)
            return BeanTableColumn.getColumnType().getColumnClass();
        else
            return super.getColumnClass(columnIndex);
    }

    public void setData(Collection<T> data, Collection<BeanTableColumn> columns)
    {
        dataHolder.clear();
        dataHolder.addAll(data);
        columnHolder.clear();
        columnHolder.addAll(columns);
        setColumnIdentifiers();
        fireTableStructureChanged();
    }

    public void setData(Collection<T> data)
    {
        dataHolder.clear();
        dataHolder.addAll(data);
        fireTableDataChanged();
    }    

    public List<T> getData()
    {
        return dataHolder;
    }

    public void clearData()
    {
        dataHolder.clear();
        fireTableDataChanged();
    }    

    public void setColumnVisibleByPropertyName(String propertyName, boolean visible)
    {
        if(propertyName != null && propertyName.trim().length() > 0)
        {
            propertyName = propertyName.trim();
            for(BeanTableColumn column : getColumns())
            {
                if(propertyName.equals(column.getPropertyName()))
                {
                    column.setVisible(visible);
                    fireTableStructureChanged();
                    return;
                }
            }
        }
    }


    public void setColumns(Collection<BeanTableColumn> columns)
    {
        columnHolder.clear();
        columnHolder.addAll(columns);
        setColumnIdentifiers();
        fireTableStructureChanged();
    }

    public List<BeanTableColumn> getColumns()
    {
        return columnHolder;
    }

    public BeanTableColumn getColumn(int columnIndex)
    {
        if(debug)
        {
            System.out.println("BeanTableModel.getColumn(" + columnIndex + ")");
        }
        if(columnIndex < columnHolder.size() && (columnIndex >= 0))
        {
            BeanTableColumn column = columnHolder.get(columnIndex);
            if(debug)
            {
                System.out.println("BeanTableModel.getColumn().column: " + column);
            }
            return column; 
        }

        throw new IllegalStateException("Invalid columnIndex: " + columnIndex + ". The columnIndex must be between 0 and " + (columnHolder.size() - 1) + ".");
    }
    
    protected void setColumnIdentifiers()
    {
        if(columnIdentifiers == null)
        {
            columnIdentifiers = new TreeMap<String, Integer>();
        }
        else
        {
            columnIdentifiers.clear();
        }
        int size = columnHolder.size();
        for(int i = 0; i < size; i++)
        {
            columnIdentifiers.put(columnHolder.get(i).getColumnName(), i);
        }
    }

    public String getColumnName(int columnIndex)
    {
        if(debug)
        {
            System.out.println("BeanTableModel.getColumnName(" + columnIndex + ")");
        }
        BeanTableColumn column = getColumn(columnIndex);
        if(debug)
        {
            if(column != null)
                System.out.println("BeanTableModel.getColumnName().name: " + column.getColumnName());
            else
                System.out.println("BeanTableModel.getColumnName().name: NULL (Try to get name from the super.)");
        }

        if(column != null)
            return column.getColumnName();
        else
            return super.getColumnName(columnIndex);
    }

    public int findColumn(String columnName)
    {
        if(debug)
        {
            System.out.println("BeanTableModel.findColumn(" + columnName + ")");
        }
        if(columnIdentifiers != null)
        {
            Integer columnIndex = columnIdentifiers.get(columnName);
            if(debug)
            {
                System.out.println("BeanTableModel.findColumn().columnIndex: " + columnIndex);
            }
            if(columnIndex != null)
                return columnIndex.intValue();
        }

        return super.findColumn(columnName);
    }

    public boolean isCellEditable(int rowIndex, int columnIndex)
    {
        if(columnHolder != null)
        {
            BeanTableColumn column = columnHolder.get(columnIndex);
            if(column != null)
            {
                return column.isEditable();
            }
        }

        return super.isCellEditable(rowIndex, columnIndex);
    }

    public ResourceBundle getResourceBundle()
    {
        return ResourceBundleManager.getResourceBundle();
    }

    public BeanTableColumn addColumn(String columnName,
                                     String propertyName,
                                     String title,
                                     ColumnType columnType)
    {
        return addColumn(columnName, propertyName, title, columnType, true);
    }

    public BeanTableColumn addColumn(String columnName,
                                     String propertyName,
                                     String title,
                                     ColumnType columnType,
                                     boolean visible)
    {
        return addColumn(columnName, propertyName, title, columnType, visible, false);
    }

    public synchronized BeanTableColumn addColumn(String columnName,
                                                  String propertyName,
                                                  String title,
                                                  ColumnType columnType,
                                                  boolean visible,
                                                  boolean key)
    {
        int modelIndex = columnHolder.size();
        BeanTableColumn column = new BeanTableColumn(modelIndex,
                columnName,
                propertyName,
                title,
                columnType,
                visible,
                key
            );
        columnHolder.add(column);
        fireTableStructureChanged();
        return column;
    }

}
