package com.cosmos.bean.table;

import org.jdesktop.swingx.table.ColumnFactory;
import org.jdesktop.swingx.table.TableColumnExt;

/**
 *
 * @author miro
 */
public class BeanTableColumn
    extends TableColumnExt
{
    static
    {
        ColumnFactory.setInstance(new BeanColumnFactory());
    }

    private String columnName;
    private String propertyName;
    private ColumnType columnType;
    private boolean key;

    public BeanTableColumn(int modelIndex,
                           String columnName,
                           String propertyName,
                           String title,
                           ColumnType columnType)
    {
        this(modelIndex, columnName, propertyName, title, columnType, true);
    }

    public BeanTableColumn(int modelIndex,
                           String columnName,
                           String propertyName,
                           String title,
                           ColumnType columnType,
                           boolean visible)
    {
        this(modelIndex, columnName, propertyName, title, columnType, visible, false);
    }

    public BeanTableColumn(int modelIndex,
                           String columnName,
                           String propertyName,
                           String title,
                           ColumnType columnType,
                           boolean visible,
                           boolean key)
    {
        super(modelIndex);
        this.columnName = columnName;
        this.propertyName = propertyName;
        this.columnType = columnType;
        this.key = key;
        setVisible(visible);
        setTitle(title);
    }

    public String getColumnName()
    {
        return columnName;
    }
    
    public void setColumnName(String columnName)
    {
        this.columnName = columnName;
    }

    public String getPropertyName()
    {
        return propertyName;
    }
    
    public void setPropertyName(String propertyName)
    {
        this.propertyName = propertyName;
    }
    
    public ColumnType getColumnType()
    {
        return columnType;
    }

    public void setColumnType(ColumnType columnType)
    {
        this.columnType = columnType;
    }

    public boolean isKey()
    {
        return key;
    }
    
    public void setKey(boolean key)
    {
        this.key = key;
    }
}
