package com.cosmos.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import javax.swing.AbstractListModel;
import javax.swing.MutableComboBoxModel;

/**
 *
 * @author Miro
 */
public class BeanComboBoxModel
    extends AbstractListModel
    implements MutableComboBoxModel,
    Serializable
{
    protected ArrayList data;
    protected Object selectedObject;
    
    public BeanComboBoxModel()
    {
        data = new ArrayList();
    }
    
    public BeanComboBoxModel(Object ... items)
    {
        this(Arrays.asList(items));
    }
    
    public BeanComboBoxModel(Collection<?> collection)
    {
        int size;
        if(collection != null && (size = collection.size()) > 0)
        {
            data = new ArrayList(size);
            data.addAll(collection);
            setSelectedItem(data.get(0));
        }
        else
        {
            data = new ArrayList();
        }
    }
    
    public void addElement(Object anObject)
    {
        data.add(anObject);
        int index = data.size() - 1;
        fireIntervalAdded(this, index, index);
        if(index == 0 && selectedObject == null && anObject != null )
        {
            setSelectedItem(anObject);
        }
    }
    
    public void removeElement(Object anObject)
    {
        int index = data.indexOf(anObject);
        if(index >= 0)
        {
            removeElementAt(index);
        }
    }
    
    public void insertElementAt(Object anObject, int index)
    {
        data.add(index, anObject);
        fireIntervalAdded(this, index, index);
    }
    
    public void removeElementAt(int index)
    {
        if(getElementAt(index) == selectedObject)
        {
            if(index == 0)
            {
                setSelectedItem(getSize() == 1 ? null : getElementAt(index + 1));
            }
            else
            {
                setSelectedItem(getElementAt(index - 1));
            }
        }

        data.remove(index);

        fireIntervalRemoved(this, index, index);
    }
    
    public void setSelectedItem(Object anObject)
    {
        setSelectedItem(anObject, false);
    }

    protected void setSelectedItem(Object anObject, boolean forceFire)
    {
        if((selectedObject != null && !selectedObject.equals(anObject)) ||
           (selectedObject == null && anObject != null))
        {
            selectedObject = anObject;
            forceFire = true;
        }
        if(forceFire)
            fireContentsChanged(this, -1, -1);
    }
    
    public Object getSelectedItem()
    {
        return selectedObject;
    }
    
    public int getSize()
    {
        return data.size();
    }
    
    public Object getElementAt(int index)
    {
        if(index >= 0 && index < data.size())
            return data.get(index);
        else
            return null;
    }
    
    public int getIndexOf(Object anObject)
    {
        return data.indexOf(anObject);
    }
    
    public void removeAllElements()
    {
        int size;
        if((size = data.size()) > 0)
        {
            data.clear();
        }
        if(size > 0)
            fireIntervalRemoved(this, 0, size - 1);
        else
            fireIntervalRemoved(this, 0, 0);

        selectedObject = null;
    }


    public void setData(Collection<?> collection)
    {
        setData(collection, null);
    }   

    public void setData(Collection<?> collection, Object selectedItem)
    {
        removeAllElements();
        int size;
        if(collection != null && (size = collection.size()) > 0)
        {
            data.addAll(collection);
            fireIntervalAdded(this, 0, size - 1);
            if(selectedItem != null)
            {
                int index;
                if((index = data.indexOf(selectedItem)) >= 0)
                {
                    setSelectedItem(data.get(index));
                    return;
                }
            }
        }
        setSelectedItem(null, true);
    }

    public void addData(Collection<?> collection)
    {
        int size;
        if(collection != null && (size = collection.size()) > 0)
        {
            int firstIndex = data.size();
            int lastIndex = firstIndex + size - 1;
            data.addAll(collection);
            fireIntervalAdded(this, firstIndex, lastIndex);
            if(selectedObject == null)
                setSelectedItem(data.get(0));
        }
    }
    
    public void addData(int atIndex, Collection<?> collection)
    {
        int size;
        if(collection != null && (size = collection.size()) > 0)
        {
            int dataSize = data.size();
            if(atIndex > dataSize)
                atIndex = dataSize;
            int firstIndex = atIndex;
            int lastIndex = firstIndex + size - 1;
            data.addAll(atIndex, collection);
            fireIntervalAdded(this, firstIndex, lastIndex);
            if(selectedObject == null)
                setSelectedItem(data.get(0));
        }
    }

    public List getData()
    {
        return data;
    }

}