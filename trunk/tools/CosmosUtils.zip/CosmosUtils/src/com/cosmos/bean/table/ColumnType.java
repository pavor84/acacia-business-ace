package com.cosmos.bean.table;

import com.cosmos.util.SystemUtils;
import java.awt.Color;
import java.util.Date;
import javax.swing.JComboBox;

/**
 *
 * @author miro
 */
public enum ColumnType
{
    STRING(String.class),
    INT(Integer.class),
    LONG(Long.class),
    DOUBLE(Double.class),
    MONEY(Double.class),
    BOOLEAN(Boolean.class),
    DATE(Date.class),
    COMBOBOX(JComboBox.class),
    NOTES(String.class),
    COLOR(Color.class),
    OBJECT(Object.class);

    private ColumnType(Class columnClass)
    {
        this.columnClass = columnClass;
    }

    public Class<?> getColumnClass()
    {
        return columnClass;
    }

    private Class columnClass;

    public String toString(Object value)
    {
        if(value != null)
        {
            if(this.equals(STRING))
            {
                return (String)value;
            }
            if(this.equals(DATE))
            {
                return SystemUtils.formatDate(value);
            }
            if(this.equals(DOUBLE))
            {
                return SystemUtils.getDecimalFormatter().format(value);
            }

            return String.valueOf(value);
        }

        return "";
    }
}
