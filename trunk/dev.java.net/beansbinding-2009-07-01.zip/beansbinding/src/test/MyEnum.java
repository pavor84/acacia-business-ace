/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author Miro
 */
public enum MyEnum {

    First,
    Second,
    Third;
}
