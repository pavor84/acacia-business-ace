/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package test;

import org.jdesktop.beansbinding.DefaultELContext;
import org.jdesktop.beansbinding.ELProperty;
import org.jdesktop.el.ELContext;
import org.jdesktop.el.ValueExpression;
import org.jdesktop.el.impl.ExpressionFactoryImpl;
import org.jdesktop.el.impl.lang.ExpressionBuilder;

/**
 *
 * @author Miro
 */
public class EnumTest {

    private MyEnum myEnum;

    public MyEnum getMyEnum() {
        return myEnum;
    }

    public void setMyEnum(MyEnum myEnum) {
        this.myEnum = myEnum;
    }

    public static void main(String[] args) {
        EnumTest test = new EnumTest();
        DefaultELContext context = new DefaultELContext();
        context.setVariable("MyEnum", MyEnum.class);

        ELProperty elp = ELProperty.create(context, "${MyEnum.First}");
        System.out.println("elp.getValue(test): " + elp.getValue(test));

        elp = ELProperty.create(context, "${MyEnum.First == myEnum}");
        System.out.println("elp.getValue(test): " + elp.getValue(test));

        test.setMyEnum(MyEnum.First);
        elp = ELProperty.create(context, "${MyEnum.First == myEnum}");
        System.out.println("elp.getValue(test): " + elp.getValue(test));

        elp = ELProperty.create(context, "${MyEnum.UnExisting}");
        System.out.println("elp.getValue(test): " + elp.getValue(test));
    }
}
