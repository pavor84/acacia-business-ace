/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package test;

import java.math.BigDecimal;
import org.jdesktop.beansbinding.ELProperty;

/**
 *
 * @author Miro
 */
public class Test {

    public static void main(String[] args) {
        FirstEntity firstEntity = new FirstEntity(BigDecimal.valueOf(100.5), BigDecimal.valueOf(10.33));
        ELProperty elProperty = ELProperty.create("${firstValue * secondValue}");
        Object value = elProperty.getValue(firstEntity);
        System.out.println("elProperty.getValue(firstEntity): " + value + ", class: " + value.getClass().getName());
    }

    public static class FirstEntity {
        private BigDecimal firstValue;
        private BigDecimal secondValue;

        public FirstEntity() {
        }

        public FirstEntity(BigDecimal firstValue) {
            this.firstValue = firstValue;
        }

        public FirstEntity(BigDecimal firstValue, BigDecimal secondValue) {
            this.firstValue = firstValue;
            this.secondValue = secondValue;
        }

        public BigDecimal getFirstValue() {
            return firstValue;
        }

        public void setFirstValue(BigDecimal firstValue) {
            this.firstValue = firstValue;
        }

        public BigDecimal getSecondValue() {
            return secondValue;
        }

        public void setSecondValue(BigDecimal secondValue) {
            this.secondValue = secondValue;
        }
    }
}
