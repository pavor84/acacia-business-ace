/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package test;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import org.jdesktop.beansbinding.DefaultELContext;
import org.jdesktop.beansbinding.ELProperty;
import org.jdesktop.el.ELContext;
import org.jdesktop.el.impl.lang.FunctionMapperImpl;

/**
 *
 * @author Miro
 */
public class FunctionTest {

    private ELContext elContext;

    public void doTest() {
        String expression = "${testMethod(now())}";
        ELProperty elProperty = create(expression);
        System.out.println("elProperty: " + elProperty);
        Object value = elProperty.getValue(this);
        System.out.println("value: " + value);
    }

    protected ELProperty create(String expression) {
        return ELProperty.create(getELContext(), expression);
    }

    protected ELContext getELContext() {
        if(elContext == null) {
            elContext = new DefaultELContext();
            FunctionMapperImpl functionMapper = (FunctionMapperImpl)elContext.getFunctionMapper();
            String prefix = "";
            String localName = "testMethod";
            Method method;
            try {
                method = this.getClass().getMethod(localName, Date.class);
            } catch(Exception ex) {
                throw new RuntimeException(ex);
            }
            functionMapper.addFunction(prefix, localName, method);

            localName = "now";
            try {
                method = this.getClass().getMethod(localName);
            } catch(Exception ex) {
                throw new RuntimeException(ex);
            }
            functionMapper.addFunction(prefix, localName, method);
        }

        return elContext;
    }

    public static String testMethod(Date time) {
        return "The time is " + time;
    }

    public static Date now() {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        System.out.println("now(): " + timestamp);
        return timestamp;
    }

    public static void main(String[] args) {
        FunctionTest test = new FunctionTest();
        test.doTest();
    }
}
