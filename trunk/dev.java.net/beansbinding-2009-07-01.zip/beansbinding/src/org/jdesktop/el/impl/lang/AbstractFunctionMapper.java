/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jdesktop.el.impl.lang;

import java.lang.reflect.Method;
import java.util.TreeMap;
import org.jdesktop.el.Function;
import org.jdesktop.el.FunctionMapper;
import org.jdesktop.el.FunctionName;

/**
 *
 * @author Miro
 */
public abstract class AbstractFunctionMapper extends TreeMap<FunctionName, Function>
        implements FunctionMapper {

    public Function resolveFunction(String prefix, String localName) {
        return resolveFunction(new FunctionName(prefix, localName));
    }

    public Function resolveFunction(FunctionName functionName) {
        return get(functionName);
    }

    public Function addFunction(String prefix, String localName, Method method) {
        return addFunction(prefix, localName, method, null);
    }

    public Function addFunction(String prefix, String localName, Method method, Object bean) {
        return addFunction(new FunctionImpl(prefix, localName, method, bean));
    }

    public Function addFunction(Function function) {
        if (function == null) {
            throw new NullPointerException("Function can not be null");
        }
        return put(function.getFunctionName(), function);
    }
}
