/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jdesktop.el.impl.lang;

import java.io.Serializable;
import java.lang.reflect.Method;
import org.jdesktop.el.Function;
import org.jdesktop.el.FunctionName;

/**
 *
 * @author Miro
 */
public class FunctionImpl implements Function, Serializable {

    private FunctionName functionName;
    private Method method;
    private Object bean;

    public FunctionImpl(String prefix, String localName, Method method, Object bean) {
        this(new FunctionName(prefix, localName), method, bean);
    }

    public FunctionImpl(FunctionName functionName, Method method, Object bean) {
        if (functionName == null) {
            throw new NullPointerException("FunctionName can not be null");
        }
        if (method == null) {
            throw new NullPointerException("Method can not be null");
        }
        this.functionName = functionName;
        this.method = method;
        this.bean = bean;
    }

    public FunctionName getFunctionName() {
        return functionName;
    }

    public Method getMethod() {
        return method;
    }

    public Object getBean() {
        return bean;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final FunctionImpl other = (FunctionImpl) obj;
        if (functionName != other.functionName && (functionName == null || !functionName.equals(other.functionName))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        if(functionName != null) {
            return functionName.hashCode();
        }

        return 0;
    }

}
