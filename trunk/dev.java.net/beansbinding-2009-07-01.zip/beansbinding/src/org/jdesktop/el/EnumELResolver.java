/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.jdesktop.el;

import java.beans.FeatureDescriptor;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author Miro
 */
public class EnumELResolver extends ELResolver {

    @Override
    public Object getValue(ELContext context, Object base, Object property) {
        if (context == null) {
            throw new NullPointerException();
        }

        if (base != null && base instanceof Class && ((Class)base).isEnum() && property instanceof String) {
            Class enumClass = (Class)base;
            Enum enumValue = Enum.valueOf(enumClass, (String)property);
            context.setPropertyResolved(true);
            return enumValue;
        }

        return null;
    }

    @Override
    public Class<?> getType(ELContext context, Object base, Object property) {
        if (context == null) {
            throw new NullPointerException();
        }

        if (isEnum(base, property)) {
            context.setPropertyResolved(true);
            return (Class)base;
        }

        return null;
    }

    @Override
    public void setValue(ELContext context, Object base, Object property, Object value) {
        if (context == null) {
            throw new NullPointerException();
        }

        if(isEnum(base, property)) {
            context.setPropertyResolved(true);
            throw new PropertyNotWritableException();
        }
    }

    @Override
    public boolean isReadOnly(ELContext context, Object base, Object property) {
        if (context == null) {
            throw new NullPointerException();
        }

        if(isEnum(base, property)) {
            context.setPropertyResolved(true);
        }

        return true;
    }

    @Override
    public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) {
        if (context == null) {
            throw new NullPointerException();
        }

        if(!isEnum(base)) {
            return null;
        }

        Class<? extends Enum> enumClass = (Class)base;
        Enum[] enums = enumClass.getEnumConstants();
        List<FeatureDescriptor> list = new ArrayList<FeatureDescriptor>(enums.length);
        for(Enum item : enums) {
            FeatureDescriptor descriptor = new FeatureDescriptor();
            String name = item.name();
            descriptor.setName(name);
            descriptor.setDisplayName(name);
            descriptor.setShortDescription("");
            descriptor.setExpert(false);
            descriptor.setHidden(false);
            descriptor.setPreferred(true);
            descriptor.setValue(TYPE, String.class);
            descriptor.setValue(RESOLVABLE_AT_DESIGN_TIME, Boolean.TRUE);

            list.add(descriptor);
        }

        return list.iterator();
    }

    @Override
    public Class<?> getCommonPropertyType(ELContext context, Object base) {
        if(isEnum(base)) {
            return String.class;
        }

        return null;
    }

    protected boolean isEnum(Object base, Object property) {
        if(isEnum(base) && property instanceof String) {
            return true;
        }

        return false;
    }

    protected boolean isEnum(Object base) {
        if (base != null && base instanceof Class && ((Class)base).isEnum()) {
            return true;
        }

        return false;
    }
}
