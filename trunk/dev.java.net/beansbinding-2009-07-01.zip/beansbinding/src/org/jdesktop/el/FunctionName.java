/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jdesktop.el;

import java.io.Serializable;
import java.util.Comparator;

/**
 *
 * @author Miro
 */
public class FunctionName implements Comparator<FunctionName>, Comparable<FunctionName>, Serializable {

    private String prefix;
    private String localName;
    private String name;

    /**
     * 
     * @param prefix
     * @param localName
     */
    public FunctionName(String prefix, String localName) {
        if (localName == null) {
            throw new NullPointerException("LocalName can not be null");
        }
        if (prefix == null) {
            prefix = "";
        }
        this.prefix = prefix;
        this.localName = localName;
        name = prefix + ":" + localName;
    }

    public String getName() {
        return name;
    }

    public String getLocalName() {
        return localName;
    }

    public String getPrefix() {
        return prefix;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final FunctionName other = (FunctionName) obj;
        if ((name == null) ? (other.name != null) : !name.equals(other.name)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        if (name != null) {
            return name.hashCode();
        }

        return 0;
    }

    public int compare(FunctionName fn1, FunctionName fn2) {
        return fn1.name.compareTo(fn2.name);
    }

    public int compareTo(FunctionName fn) {
        return compare(this, fn);
    }
}
