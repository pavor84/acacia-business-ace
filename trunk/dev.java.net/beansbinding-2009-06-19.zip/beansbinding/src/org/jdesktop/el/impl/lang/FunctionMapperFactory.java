/*
 * Copyright (C) 2007 Sun Microsystems, Inc. All rights reserved. Use is
 * subject to license terms.
 */
package org.jdesktop.el.impl.lang;


import org.jdesktop.el.ELContext;
import org.jdesktop.el.Function;
import org.jdesktop.el.FunctionMapper;

/**
 * @author Jacob Hookom [jacob@hookom.net]
 * @version $Change: 181177 $$DateTime: 2001/06/26 08:45:09 $$Author: kchung $
 */
public class FunctionMapperFactory extends AbstractFunctionMapper {

    protected FunctionMapperImpl memento = null;
    protected ELContext context;

    public FunctionMapperFactory(ELContext context) {
        if (context == null) {
            throw new NullPointerException("ELContext can not be null");
        }
        this.context = context;
    }

    /* (non-Javadoc)
     * @see javax.el.FunctionMapper#resolveFunction(java.lang.String, java.lang.String)
     */
    public Function resolveFunction(String prefix, String localName) {
        if (this.memento == null) {
            this.memento = new FunctionMapperImpl();
        }
        Function function = context.resolveFunction(prefix, localName);
        if (function != null) {
            this.memento.addFunction(function);
        }
        return function;
    }

    public FunctionMapper create() {
        return this.memento;
    }
}
