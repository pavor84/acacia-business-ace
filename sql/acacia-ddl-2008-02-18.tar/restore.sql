create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.users DROP CONSTRAINT fk_users_person_id;
ALTER TABLE ONLY public.users DROP CONSTRAINT fk_users_creator_id;
ALTER TABLE ONLY public."TestTable" DROP CONSTRAINT fk_test_id_do_id;
ALTER TABLE ONLY public.resource_bundle DROP CONSTRAINT fk_resource_bundle_enum_class_id;
ALTER TABLE ONLY public.products DROP CONSTRAINT fk_products_product_id;
ALTER TABLE ONLY public.data_objects DROP CONSTRAINT fk_do_parent_id;
ALTER TABLE ONLY public.data_objects DROP CONSTRAINT fk_do_linked_id;
ALTER TABLE ONLY public.data_objects DROP CONSTRAINT fk_data_objects_parent_data_object_id;
ALTER TABLE ONLY public.data_objects DROP CONSTRAINT fk_data_objects_linked_data_object_id;
ALTER TABLE ONLY public.data_objects DROP CONSTRAINT fk74e5117fdfc2026f;
ALTER TABLE ONLY public.data_objects DROP CONSTRAINT fk74e5117f6017f920;
ALTER TABLE ONLY public.users DROP CONSTRAINT fk6a68e08a08870b9;
ALTER TABLE ONLY public.users DROP CONSTRAINT fk6a68e0844bb6904;
ALTER TABLE ONLY public.users DROP CONSTRAINT uk_users_user_name;
ALTER TABLE ONLY public.users DROP CONSTRAINT uk_users_email_address;
ALTER TABLE ONLY public.sequence_identifiers DROP CONSTRAINT uk_seq_id_name;
ALTER TABLE ONLY public.enum_classes DROP CONSTRAINT uk_enum_classes;
ALTER TABLE ONLY public.data_object_types DROP CONSTRAINT uk_dot_data_object_type;
ALTER TABLE ONLY public.users DROP CONSTRAINT pk_users;
ALTER TABLE ONLY public."TestTable" DROP CONSTRAINT pk_test_table;
ALTER TABLE ONLY public.resource_bundle DROP CONSTRAINT pk_resource_bundle;
ALTER TABLE ONLY public.products DROP CONSTRAINT pk_products;
ALTER TABLE ONLY public.object_identifiers DROP CONSTRAINT pk_object_identifiers;
ALTER TABLE ONLY public.hello_world DROP CONSTRAINT pk_hello_world;
ALTER TABLE ONLY public.enum_classes DROP CONSTRAINT pk_enum_classes;
ALTER TABLE ONLY public.data_objects DROP CONSTRAINT pk_data_objects;
ALTER TABLE ONLY public.data_object_types DROP CONSTRAINT pk_data_object_types;
ALTER TABLE public.sequence_identifiers ALTER COLUMN seq_id_key DROP DEFAULT;
ALTER TABLE public.hello_world ALTER COLUMN hello_world_id DROP DEFAULT;
DROP SEQUENCE public.sequence_identifiers_seq_id_key_seq;
DROP SEQUENCE public.resource_bundle_seq;
DROP SEQUENCE public.hello_world_hello_world_id_seq;
DROP SEQUENCE public.enum_classes_seq;
DROP SEQUENCE public.data_objects_seq;
DROP SEQUENCE public.data_object_type_seq;
DROP FUNCTION public.plpgsql_oid_debug(functionoid oid);
DROP FUNCTION public.pldbg_wait_for_target(session integer);
DROP FUNCTION public.pldbg_wait_for_breakpoint(session integer);
DROP FUNCTION public.pldbg_step_over(session integer);
DROP FUNCTION public.pldbg_step_into(session integer);
DROP FUNCTION public.pldbg_set_global_breakpoint(session integer, func oid, linenumber integer, targetpid integer);
DROP FUNCTION public.pldbg_set_breakpoint(session integer, func oid, linenumber integer);
DROP FUNCTION public.pldbg_select_frame(session integer, frame integer);
DROP FUNCTION public.pldbg_get_variables(session integer);
DROP FUNCTION public.pldbg_get_target_info(signature text, targettype "char");
DROP FUNCTION public.pldbg_get_stack(session integer);
DROP FUNCTION public.pldbg_get_source(session integer, func oid);
DROP FUNCTION public.pldbg_get_proxy_info();
DROP FUNCTION public.pldbg_get_breakpoints(session integer);
DROP FUNCTION public.pldbg_drop_breakpoint(session integer, func oid, linenumber integer);
DROP FUNCTION public.pldbg_deposit_value(session integer, varname text, linenumber integer, value text);
DROP FUNCTION public.pldbg_create_listener();
DROP FUNCTION public.pldbg_continue(session integer);
DROP FUNCTION public.pldbg_attach_to_port(portnumber integer);
DROP FUNCTION public.pldbg_abort_target(session integer);
DROP TYPE public.var;
DROP TABLE public.users;
DROP TYPE public.targetinfo;
DROP TABLE public.sequence_identifiers;
DROP TABLE public.resource_bundle;
DROP TYPE public.proxyinfo;
DROP TABLE public.products;
DROP TABLE public.object_identifiers;
DROP TABLE public.hello_world;
DROP TYPE public.frame;
DROP TABLE public.enum_classes;
DROP TABLE public.data_objects;
DROP TABLE public.data_object_types;
DROP TYPE public.breakpoint;
DROP TABLE public."TestTable";
DROP PROCEDURAL LANGUAGE plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: PostgreSQL
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO "PostgreSQL";

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: PostgreSQL
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: PostgreSQL
--

CREATE PROCEDURAL LANGUAGE plpgsql;


ALTER PROCEDURAL LANGUAGE plpgsql OWNER TO "PostgreSQL";

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: TestTable; Type: TABLE; Schema: public; Owner: PostgreSQL; Tablespace: 
--

CREATE TABLE "TestTable" (
    test_id numeric(18,0) NOT NULL,
    test_name character varying(64)
);


ALTER TABLE public."TestTable" OWNER TO "PostgreSQL";

--
-- Name: breakpoint; Type: TYPE; Schema: public; Owner: PostgreSQL
--

CREATE TYPE breakpoint AS (
	func oid,
	linenumber integer,
	targetname text
);


ALTER TYPE public.breakpoint OWNER TO "PostgreSQL";

--
-- Name: data_object_types; Type: TABLE; Schema: public; Owner: PostgreSQL; Tablespace: 
--

CREATE TABLE data_object_types (
    data_object_type_id integer NOT NULL,
    data_object_type character varying(255) NOT NULL,
    notes text,
    small_image_uri character varying(1024),
    small_image bytea,
    medium_image_uri character varying(1024),
    medium_image bytea
);


ALTER TABLE public.data_object_types OWNER TO "PostgreSQL";

--
-- Name: data_objects; Type: TABLE; Schema: public; Owner: PostgreSQL; Tablespace: 
--

CREATE TABLE data_objects (
    data_object_id numeric(18,0) NOT NULL,
    data_object_version integer NOT NULL,
    data_object_type_id integer NOT NULL,
    creation_time timestamp with time zone NOT NULL,
    creator_id bigint NOT NULL,
    owner_id bigint NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    is_read_only boolean DEFAULT false NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    is_folder boolean DEFAULT false NOT NULL,
    is_link boolean DEFAULT false NOT NULL,
    parent_data_object_id numeric(18,0),
    linked_data_object_id numeric(18,0),
    order_position character varying(10),
    child_counter integer,
    notes text,
    small_image_uri character varying(1024),
    small_image bytea,
    medium_image_uri character varying(1024),
    medium_image bytea,
    data_object_uri character varying(1024)
);


ALTER TABLE public.data_objects OWNER TO "PostgreSQL";

--
-- Name: enum_classes; Type: TABLE; Schema: public; Owner: PostgreSQL; Tablespace: 
--

CREATE TABLE enum_classes (
    enum_class_id integer NOT NULL,
    enum_class_name character varying(255) NOT NULL
);


ALTER TABLE public.enum_classes OWNER TO "PostgreSQL";

--
-- Name: frame; Type: TYPE; Schema: public; Owner: PostgreSQL
--

CREATE TYPE frame AS (
	level integer,
	targetname text,
	func oid,
	linenumber integer,
	args text
);


ALTER TYPE public.frame OWNER TO "PostgreSQL";

--
-- Name: hello_world; Type: TABLE; Schema: public; Owner: PostgreSQL; Tablespace: 
--

CREATE TABLE hello_world (
    hello_world_id bigint NOT NULL,
    hello_world character varying(255)
);


ALTER TABLE public.hello_world OWNER TO "PostgreSQL";

--
-- Name: object_identifiers; Type: TABLE; Schema: public; Owner: PostgreSQL; Tablespace: 
--

CREATE TABLE object_identifiers (
    object_id numeric(36,0) NOT NULL,
    deleted boolean
);


ALTER TABLE public.object_identifiers OWNER TO "PostgreSQL";

--
-- Name: products; Type: TABLE; Schema: public; Owner: PostgreSQL; Tablespace: 
--

CREATE TABLE products (
    product_id numeric(18,0) NOT NULL,
    parent_id numeric(18,0),
    category_id numeric(18,0) NOT NULL,
    product_name character varying(100) NOT NULL,
    product_code character varying(50) NOT NULL,
    measure_unit_id integer NOT NULL,
    is_complex boolean DEFAULT false NOT NULL,
    is_purchased boolean DEFAULT false NOT NULL,
    is_salable boolean DEFAULT true NOT NULL,
    is_obsolete boolean DEFAULT false NOT NULL,
    pattern_format_id integer,
    product_color character varying(45),
    minimum_quantity numeric(19,4) DEFAULT 1 NOT NULL,
    maximum_quantity numeric(19,4),
    default_quantity numeric(19,4),
    purchase_price numeric(19,4) NOT NULL,
    sale_price numeric(19,4) NOT NULL,
    list_price numeric(19,4) NOT NULL,
    quantity_per_package integer DEFAULT 1 NOT NULL,
    dimension_unit_id integer,
    dimension_width numeric(7,2),
    dimension_length numeric(7,2),
    dimension_height numeric(7,2),
    weight_unit_id integer,
    weight numeric(13,3),
    delivery_time integer,
    description text,
    producer_id numeric(18,0)
);


ALTER TABLE public.products OWNER TO "PostgreSQL";

--
-- Name: proxyinfo; Type: TYPE; Schema: public; Owner: PostgreSQL
--

CREATE TYPE proxyinfo AS (
	serverversionstr text,
	serverversionnum integer,
	proxyapiver integer,
	serverprocessid integer
);


ALTER TYPE public.proxyinfo OWNER TO "PostgreSQL";

--
-- Name: resource_bundle; Type: TABLE; Schema: public; Owner: PostgreSQL; Tablespace: 
--

CREATE TABLE resource_bundle (
    resource_id integer NOT NULL,
    enum_class_id integer NOT NULL,
    enum_name character varying(64) NOT NULL
);


ALTER TABLE public.resource_bundle OWNER TO "PostgreSQL";

--
-- Name: sequence_identifiers; Type: TABLE; Schema: public; Owner: PostgreSQL; Tablespace: 
--

CREATE TABLE sequence_identifiers (
    seq_id_key bigint NOT NULL,
    seq_id_name character varying(64) NOT NULL,
    seq_id_value numeric(38,0) DEFAULT 0 NOT NULL
);


ALTER TABLE public.sequence_identifiers OWNER TO "PostgreSQL";

--
-- Name: targetinfo; Type: TYPE; Schema: public; Owner: PostgreSQL
--

CREATE TYPE targetinfo AS (
	target oid,
	schema oid,
	nargs integer,
	argtypes oidvector,
	targetname name,
	argmodes "char"[],
	argnames text[],
	targetlang oid,
	fqname text,
	returnsset boolean,
	returntype oid
);


ALTER TYPE public.targetinfo OWNER TO "PostgreSQL";

--
-- Name: users; Type: TABLE; Schema: public; Owner: PostgreSQL; Tablespace: 
--

CREATE TABLE users (
    user_id bigint NOT NULL,
    version integer NOT NULL,
    user_name character varying(32) NOT NULL,
    email_address character varying(64) NOT NULL,
    user_password character varying(64) NOT NULL,
    system_password character varying(64),
    system_password_validity date,
    is_active boolean DEFAULT true NOT NULL,
    is_new boolean DEFAULT true NOT NULL,
    creation_time time with time zone NOT NULL,
    creator_id bigint NOT NULL,
    person_id numeric(18,0),
    description text,
    small_image_uri character varying(1024),
    small_image bytea,
    medium_image_uri character varying(1024),
    medium_image bytea,
    user_uri character varying(1024),
    next_action_after_login character varying(1024)
);


ALTER TABLE public.users OWNER TO "PostgreSQL";

--
-- Name: var; Type: TYPE; Schema: public; Owner: PostgreSQL
--

CREATE TYPE var AS (
	name text,
	varclass character(1),
	linenumber integer,
	isunique boolean,
	isconst boolean,
	isnotnull boolean,
	dtype oid,
	value text
);


ALTER TYPE public.var OWNER TO "PostgreSQL";

--
-- Name: pldbg_abort_target(integer); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_abort_target(session integer) RETURNS SETOF boolean
    AS '$libdir/pldbgapi', 'pldbg_abort_target'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_abort_target(session integer) OWNER TO "PostgreSQL";

--
-- Name: pldbg_attach_to_port(integer); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_attach_to_port(portnumber integer) RETURNS integer
    AS '$libdir/pldbgapi', 'pldbg_attach_to_port'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_attach_to_port(portnumber integer) OWNER TO "PostgreSQL";

--
-- Name: pldbg_continue(integer); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_continue(session integer) RETURNS breakpoint
    AS '$libdir/pldbgapi', 'pldbg_continue'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_continue(session integer) OWNER TO "PostgreSQL";

--
-- Name: pldbg_create_listener(); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_create_listener() RETURNS integer
    AS '$libdir/pldbgapi', 'pldbg_create_listener'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_create_listener() OWNER TO "PostgreSQL";

--
-- Name: pldbg_deposit_value(integer, text, integer, text); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_deposit_value(session integer, varname text, linenumber integer, value text) RETURNS boolean
    AS '$libdir/pldbgapi', 'pldbg_deposit_value'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_deposit_value(session integer, varname text, linenumber integer, value text) OWNER TO "PostgreSQL";

--
-- Name: pldbg_drop_breakpoint(integer, oid, integer); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_drop_breakpoint(session integer, func oid, linenumber integer) RETURNS boolean
    AS '$libdir/pldbgapi', 'pldbg_drop_breakpoint'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_drop_breakpoint(session integer, func oid, linenumber integer) OWNER TO "PostgreSQL";

--
-- Name: pldbg_get_breakpoints(integer); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_get_breakpoints(session integer) RETURNS SETOF breakpoint
    AS '$libdir/pldbgapi', 'pldbg_get_breakpoints'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_get_breakpoints(session integer) OWNER TO "PostgreSQL";

--
-- Name: pldbg_get_proxy_info(); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_get_proxy_info() RETURNS proxyinfo
    AS '$libdir/pldbgapi', 'pldbg_get_proxy_info'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_get_proxy_info() OWNER TO "PostgreSQL";

--
-- Name: pldbg_get_source(integer, oid); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_get_source(session integer, func oid) RETURNS text
    AS '$libdir/pldbgapi', 'pldbg_get_source'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_get_source(session integer, func oid) OWNER TO "PostgreSQL";

--
-- Name: pldbg_get_stack(integer); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_get_stack(session integer) RETURNS SETOF frame
    AS '$libdir/pldbgapi', 'pldbg_get_stack'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_get_stack(session integer) OWNER TO "PostgreSQL";

--
-- Name: pldbg_get_target_info(text, "char"); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_get_target_info(signature text, targettype "char") RETURNS targetinfo
    AS '$libdir/targetinfo', 'pldbg_get_target_info'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_get_target_info(signature text, targettype "char") OWNER TO "PostgreSQL";

--
-- Name: pldbg_get_variables(integer); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_get_variables(session integer) RETURNS SETOF var
    AS '$libdir/pldbgapi', 'pldbg_get_variables'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_get_variables(session integer) OWNER TO "PostgreSQL";

--
-- Name: pldbg_select_frame(integer, integer); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_select_frame(session integer, frame integer) RETURNS breakpoint
    AS '$libdir/pldbgapi', 'pldbg_select_frame'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_select_frame(session integer, frame integer) OWNER TO "PostgreSQL";

--
-- Name: pldbg_set_breakpoint(integer, oid, integer); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_set_breakpoint(session integer, func oid, linenumber integer) RETURNS boolean
    AS '$libdir/pldbgapi', 'pldbg_set_breakpoint'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_set_breakpoint(session integer, func oid, linenumber integer) OWNER TO "PostgreSQL";

--
-- Name: pldbg_set_global_breakpoint(integer, oid, integer, integer); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_set_global_breakpoint(session integer, func oid, linenumber integer, targetpid integer) RETURNS boolean
    AS '$libdir/pldbgapi', 'pldbg_set_global_breakpoint'
    LANGUAGE c;


ALTER FUNCTION public.pldbg_set_global_breakpoint(session integer, func oid, linenumber integer, targetpid integer) OWNER TO "PostgreSQL";

--
-- Name: pldbg_step_into(integer); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_step_into(session integer) RETURNS breakpoint
    AS '$libdir/pldbgapi', 'pldbg_step_into'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_step_into(session integer) OWNER TO "PostgreSQL";

--
-- Name: pldbg_step_over(integer); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_step_over(session integer) RETURNS breakpoint
    AS '$libdir/pldbgapi', 'pldbg_step_over'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_step_over(session integer) OWNER TO "PostgreSQL";

--
-- Name: pldbg_wait_for_breakpoint(integer); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_wait_for_breakpoint(session integer) RETURNS breakpoint
    AS '$libdir/pldbgapi', 'pldbg_wait_for_breakpoint'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_wait_for_breakpoint(session integer) OWNER TO "PostgreSQL";

--
-- Name: pldbg_wait_for_target(integer); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION pldbg_wait_for_target(session integer) RETURNS integer
    AS '$libdir/pldbgapi', 'pldbg_wait_for_target'
    LANGUAGE c STRICT;


ALTER FUNCTION public.pldbg_wait_for_target(session integer) OWNER TO "PostgreSQL";

--
-- Name: plpgsql_oid_debug(oid); Type: FUNCTION; Schema: public; Owner: PostgreSQL
--

CREATE FUNCTION plpgsql_oid_debug(functionoid oid) RETURNS integer
    AS '$libdir/plugins/plugin_debugger', 'plpgsql_oid_debug'
    LANGUAGE c STRICT;


ALTER FUNCTION public.plpgsql_oid_debug(functionoid oid) OWNER TO "PostgreSQL";

--
-- Name: data_object_type_seq; Type: SEQUENCE; Schema: public; Owner: PostgreSQL
--

CREATE SEQUENCE data_object_type_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.data_object_type_seq OWNER TO "PostgreSQL";

--
-- Name: data_object_type_seq; Type: SEQUENCE SET; Schema: public; Owner: PostgreSQL
--

SELECT pg_catalog.setval('data_object_type_seq', 36, true);


--
-- Name: data_objects_seq; Type: SEQUENCE; Schema: public; Owner: PostgreSQL
--

CREATE SEQUENCE data_objects_seq
    INCREMENT BY 1
    MAXVALUE 999999999999999999
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.data_objects_seq OWNER TO "PostgreSQL";

--
-- Name: data_objects_seq; Type: SEQUENCE SET; Schema: public; Owner: PostgreSQL
--

SELECT pg_catalog.setval('data_objects_seq', 2, true);


--
-- Name: enum_classes_seq; Type: SEQUENCE; Schema: public; Owner: PostgreSQL
--

CREATE SEQUENCE enum_classes_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.enum_classes_seq OWNER TO "PostgreSQL";

--
-- Name: enum_classes_seq; Type: SEQUENCE SET; Schema: public; Owner: PostgreSQL
--

SELECT pg_catalog.setval('enum_classes_seq', 1, true);


--
-- Name: hello_world_hello_world_id_seq; Type: SEQUENCE; Schema: public; Owner: PostgreSQL
--

CREATE SEQUENCE hello_world_hello_world_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.hello_world_hello_world_id_seq OWNER TO "PostgreSQL";

--
-- Name: hello_world_hello_world_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PostgreSQL
--

ALTER SEQUENCE hello_world_hello_world_id_seq OWNED BY hello_world.hello_world_id;


--
-- Name: hello_world_hello_world_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PostgreSQL
--

SELECT pg_catalog.setval('hello_world_hello_world_id_seq', 1, false);


--
-- Name: resource_bundle_seq; Type: SEQUENCE; Schema: public; Owner: PostgreSQL
--

CREATE SEQUENCE resource_bundle_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.resource_bundle_seq OWNER TO "PostgreSQL";

--
-- Name: resource_bundle_seq; Type: SEQUENCE SET; Schema: public; Owner: PostgreSQL
--

SELECT pg_catalog.setval('resource_bundle_seq', 18, true);


--
-- Name: sequence_identifiers_seq_id_key_seq; Type: SEQUENCE; Schema: public; Owner: PostgreSQL
--

CREATE SEQUENCE sequence_identifiers_seq_id_key_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sequence_identifiers_seq_id_key_seq OWNER TO "PostgreSQL";

--
-- Name: sequence_identifiers_seq_id_key_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PostgreSQL
--

ALTER SEQUENCE sequence_identifiers_seq_id_key_seq OWNED BY sequence_identifiers.seq_id_key;


--
-- Name: sequence_identifiers_seq_id_key_seq; Type: SEQUENCE SET; Schema: public; Owner: PostgreSQL
--

SELECT pg_catalog.setval('sequence_identifiers_seq_id_key_seq', 1, false);


--
-- Name: hello_world_id; Type: DEFAULT; Schema: public; Owner: PostgreSQL
--

ALTER TABLE hello_world ALTER COLUMN hello_world_id SET DEFAULT nextval('hello_world_hello_world_id_seq'::regclass);


--
-- Name: seq_id_key; Type: DEFAULT; Schema: public; Owner: PostgreSQL
--

ALTER TABLE sequence_identifiers ALTER COLUMN seq_id_key SET DEFAULT nextval('sequence_identifiers_seq_id_key_seq'::regclass);


--
-- Data for Name: TestTable; Type: TABLE DATA; Schema: public; Owner: PostgreSQL
--

COPY "TestTable" (test_id, test_name) FROM stdin;
\.
copy "testtable" (test_id, test_name)  from '$$PATH$$/1872.dat' ;
--
-- Data for Name: data_object_types; Type: TABLE DATA; Schema: public; Owner: PostgreSQL
--

COPY data_object_types (data_object_type_id, data_object_type, notes, small_image_uri, small_image, medium_image_uri, medium_image) FROM stdin;
\.
copy data_object_types (data_object_type_id, data_object_type, notes, small_image_uri, small_image, medium_image_uri, medium_image)  from '$$PATH$$/1866.dat' ;
--
-- Data for Name: data_objects; Type: TABLE DATA; Schema: public; Owner: PostgreSQL
--

COPY data_objects (data_object_id, data_object_version, data_object_type_id, creation_time, creator_id, owner_id, is_deleted, is_read_only, is_system, is_folder, is_link, parent_data_object_id, linked_data_object_id, order_position, child_counter, notes, small_image_uri, small_image, medium_image_uri, medium_image, data_object_uri) FROM stdin;
\.
copy data_objects (data_object_id, data_object_version, data_object_type_id, creation_time, creator_id, owner_id, is_deleted, is_read_only, is_system, is_folder, is_link, parent_data_object_id, linked_data_object_id, order_position, child_counter, notes, small_image_uri, small_image, medium_image_uri, medium_image, data_object_uri)  from '$$PATH$$/1867.dat' ;
--
-- Data for Name: enum_classes; Type: TABLE DATA; Schema: public; Owner: PostgreSQL
--

COPY enum_classes (enum_class_id, enum_class_name) FROM stdin;
\.
copy enum_classes (enum_class_id, enum_class_name)  from '$$PATH$$/1875.dat' ;
--
-- Data for Name: hello_world; Type: TABLE DATA; Schema: public; Owner: PostgreSQL
--

COPY hello_world (hello_world_id, hello_world) FROM stdin;
\.
copy hello_world (hello_world_id, hello_world)  from '$$PATH$$/1868.dat' ;
--
-- Data for Name: object_identifiers; Type: TABLE DATA; Schema: public; Owner: PostgreSQL
--

COPY object_identifiers (object_id, deleted) FROM stdin;
\.
copy object_identifiers (object_id, deleted)  from '$$PATH$$/1869.dat' ;
--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: PostgreSQL
--

COPY products (product_id, parent_id, category_id, product_name, product_code, measure_unit_id, is_complex, is_purchased, is_salable, is_obsolete, pattern_format_id, product_color, minimum_quantity, maximum_quantity, default_quantity, purchase_price, sale_price, list_price, quantity_per_package, dimension_unit_id, dimension_width, dimension_length, dimension_height, weight_unit_id, weight, delivery_time, description, producer_id) FROM stdin;
\.
copy products (product_id, parent_id, category_id, product_name, product_code, measure_unit_id, is_complex, is_purchased, is_salable, is_obsolete, pattern_format_id, product_color, minimum_quantity, maximum_quantity, default_quantity, purchase_price, sale_price, list_price, quantity_per_package, dimension_unit_id, dimension_width, dimension_length, dimension_height, weight_unit_id, weight, delivery_time, description, producer_id)  from '$$PATH$$/1873.dat' ;
--
-- Data for Name: resource_bundle; Type: TABLE DATA; Schema: public; Owner: PostgreSQL
--

COPY resource_bundle (resource_id, enum_class_id, enum_name) FROM stdin;
\.
copy resource_bundle (resource_id, enum_class_id, enum_name)  from '$$PATH$$/1874.dat' ;
--
-- Data for Name: sequence_identifiers; Type: TABLE DATA; Schema: public; Owner: PostgreSQL
--

COPY sequence_identifiers (seq_id_key, seq_id_name, seq_id_value) FROM stdin;
\.
copy sequence_identifiers (seq_id_key, seq_id_name, seq_id_value)  from '$$PATH$$/1871.dat' ;
--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: PostgreSQL
--

COPY users (user_id, version, user_name, email_address, user_password, system_password, system_password_validity, is_active, is_new, creation_time, creator_id, person_id, description, small_image_uri, small_image, medium_image_uri, medium_image, user_uri, next_action_after_login) FROM stdin;
\.
copy users (user_id, version, user_name, email_address, user_password, system_password, system_password_validity, is_active, is_new, creation_time, creator_id, person_id, description, small_image_uri, small_image, medium_image_uri, medium_image, user_uri, next_action_after_login)  from '$$PATH$$/1870.dat' ;
--
-- Name: pk_data_object_types; Type: CONSTRAINT; Schema: public; Owner: PostgreSQL; Tablespace: 
--

ALTER TABLE ONLY data_object_types
    ADD CONSTRAINT pk_data_object_types PRIMARY KEY (data_object_type_id);


--
-- Name: pk_data_objects; Type: CONSTRAINT; Schema: public; Owner: PostgreSQL; Tablespace: 
--

ALTER TABLE ONLY data_objects
    ADD CONSTRAINT pk_data_objects PRIMARY KEY (data_object_id);


--
-- Name: pk_enum_classes; Type: CONSTRAINT; Schema: public; Owner: PostgreSQL; Tablespace: 
--

ALTER TABLE ONLY enum_classes
    ADD CONSTRAINT pk_enum_classes PRIMARY KEY (enum_class_id);


--
-- Name: pk_hello_world; Type: CONSTRAINT; Schema: public; Owner: PostgreSQL; Tablespace: 
--

ALTER TABLE ONLY hello_world
    ADD CONSTRAINT pk_hello_world PRIMARY KEY (hello_world_id);


--
-- Name: pk_object_identifiers; Type: CONSTRAINT; Schema: public; Owner: PostgreSQL; Tablespace: 
--

ALTER TABLE ONLY object_identifiers
    ADD CONSTRAINT pk_object_identifiers PRIMARY KEY (object_id);


--
-- Name: pk_products; Type: CONSTRAINT; Schema: public; Owner: PostgreSQL; Tablespace: 
--

ALTER TABLE ONLY products
    ADD CONSTRAINT pk_products PRIMARY KEY (product_id);


--
-- Name: pk_resource_bundle; Type: CONSTRAINT; Schema: public; Owner: PostgreSQL; Tablespace: 
--

ALTER TABLE ONLY resource_bundle
    ADD CONSTRAINT pk_resource_bundle PRIMARY KEY (resource_id);


--
-- Name: pk_test_table; Type: CONSTRAINT; Schema: public; Owner: PostgreSQL; Tablespace: 
--

ALTER TABLE ONLY "TestTable"
    ADD CONSTRAINT pk_test_table PRIMARY KEY (test_id);


--
-- Name: pk_users; Type: CONSTRAINT; Schema: public; Owner: PostgreSQL; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT pk_users PRIMARY KEY (user_id);


--
-- Name: uk_dot_data_object_type; Type: CONSTRAINT; Schema: public; Owner: PostgreSQL; Tablespace: 
--

ALTER TABLE ONLY data_object_types
    ADD CONSTRAINT uk_dot_data_object_type UNIQUE (data_object_type);


--
-- Name: uk_enum_classes; Type: CONSTRAINT; Schema: public; Owner: PostgreSQL; Tablespace: 
--

ALTER TABLE ONLY enum_classes
    ADD CONSTRAINT uk_enum_classes UNIQUE (enum_class_name);


--
-- Name: uk_seq_id_name; Type: CONSTRAINT; Schema: public; Owner: PostgreSQL; Tablespace: 
--

ALTER TABLE ONLY sequence_identifiers
    ADD CONSTRAINT uk_seq_id_name UNIQUE (seq_id_name);


--
-- Name: uk_users_email_address; Type: CONSTRAINT; Schema: public; Owner: PostgreSQL; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT uk_users_email_address UNIQUE (email_address);


--
-- Name: uk_users_user_name; Type: CONSTRAINT; Schema: public; Owner: PostgreSQL; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT uk_users_user_name UNIQUE (user_name);


--
-- Name: fk6a68e0844bb6904; Type: FK CONSTRAINT; Schema: public; Owner: PostgreSQL
--

ALTER TABLE ONLY users
    ADD CONSTRAINT fk6a68e0844bb6904 FOREIGN KEY (creator_id) REFERENCES users(user_id);


--
-- Name: fk6a68e08a08870b9; Type: FK CONSTRAINT; Schema: public; Owner: PostgreSQL
--

ALTER TABLE ONLY users
    ADD CONSTRAINT fk6a68e08a08870b9 FOREIGN KEY (person_id) REFERENCES data_objects(data_object_id);


--
-- Name: fk74e5117f6017f920; Type: FK CONSTRAINT; Schema: public; Owner: PostgreSQL
--

ALTER TABLE ONLY data_objects
    ADD CONSTRAINT fk74e5117f6017f920 FOREIGN KEY (linked_data_object_id) REFERENCES data_objects(data_object_id);


--
-- Name: fk74e5117fdfc2026f; Type: FK CONSTRAINT; Schema: public; Owner: PostgreSQL
--

ALTER TABLE ONLY data_objects
    ADD CONSTRAINT fk74e5117fdfc2026f FOREIGN KEY (parent_data_object_id) REFERENCES data_objects(data_object_id);


--
-- Name: fk_data_objects_linked_data_object_id; Type: FK CONSTRAINT; Schema: public; Owner: PostgreSQL
--

ALTER TABLE ONLY data_objects
    ADD CONSTRAINT fk_data_objects_linked_data_object_id FOREIGN KEY (linked_data_object_id) REFERENCES data_objects(data_object_id);


--
-- Name: fk_data_objects_parent_data_object_id; Type: FK CONSTRAINT; Schema: public; Owner: PostgreSQL
--

ALTER TABLE ONLY data_objects
    ADD CONSTRAINT fk_data_objects_parent_data_object_id FOREIGN KEY (parent_data_object_id) REFERENCES data_objects(data_object_id);


--
-- Name: fk_do_linked_id; Type: FK CONSTRAINT; Schema: public; Owner: PostgreSQL
--

ALTER TABLE ONLY data_objects
    ADD CONSTRAINT fk_do_linked_id FOREIGN KEY (linked_data_object_id) REFERENCES data_objects(data_object_id);


--
-- Name: fk_do_parent_id; Type: FK CONSTRAINT; Schema: public; Owner: PostgreSQL
--

ALTER TABLE ONLY data_objects
    ADD CONSTRAINT fk_do_parent_id FOREIGN KEY (parent_data_object_id) REFERENCES data_objects(data_object_id);


--
-- Name: fk_products_product_id; Type: FK CONSTRAINT; Schema: public; Owner: PostgreSQL
--

ALTER TABLE ONLY products
    ADD CONSTRAINT fk_products_product_id FOREIGN KEY (product_id) REFERENCES data_objects(data_object_id);


--
-- Name: fk_resource_bundle_enum_class_id; Type: FK CONSTRAINT; Schema: public; Owner: PostgreSQL
--

ALTER TABLE ONLY resource_bundle
    ADD CONSTRAINT fk_resource_bundle_enum_class_id FOREIGN KEY (enum_class_id) REFERENCES enum_classes(enum_class_id);


--
-- Name: fk_test_id_do_id; Type: FK CONSTRAINT; Schema: public; Owner: PostgreSQL
--

ALTER TABLE ONLY "TestTable"
    ADD CONSTRAINT fk_test_id_do_id FOREIGN KEY (test_id) REFERENCES data_objects(data_object_id);


--
-- Name: fk_users_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: PostgreSQL
--

ALTER TABLE ONLY users
    ADD CONSTRAINT fk_users_creator_id FOREIGN KEY (creator_id) REFERENCES users(user_id);


--
-- Name: fk_users_person_id; Type: FK CONSTRAINT; Schema: public; Owner: PostgreSQL
--

ALTER TABLE ONLY users
    ADD CONSTRAINT fk_users_person_id FOREIGN KEY (person_id) REFERENCES data_objects(data_object_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: PostgreSQL
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM "PostgreSQL";
GRANT ALL ON SCHEMA public TO "PostgreSQL";
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

